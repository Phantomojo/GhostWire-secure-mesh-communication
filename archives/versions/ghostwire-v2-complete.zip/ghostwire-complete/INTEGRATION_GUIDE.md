# Ghostwire — Fix Package & Strategic Brief

## What's in this package

| File | What it fixes |
|------|--------------|
| `src/controllers/identity_fixed.rs` | Unlock/lock endpoints with brute-force protection + audit logging |
| `src/web_patch.rs` | 7 annotated changes to apply to `src/web.rs` |
| `src/core/stealth_tcp_handshake_fix.rs` | HMAC-based stealth handshake (no more static magic bytes) |
| `src/jwt_and_headers.rs` | Persistent JWT secret + security headers middleware |

---

## Apply order

1. **`web_patch.rs`** — read all 7 changes, apply to `src/web.rs`
2. **`identity_fixed.rs`** — replace `src/controllers/identity.rs`
3. **`stealth_tcp_handshake_fix.rs`** — apply to `src/core/stealth_tcp.rs`
4. **`jwt_and_headers.rs`** — add functions to `src/web.rs` or a new `src/middleware.rs`

After applying, run:
```bash
cargo clippy --all-features 2>&1 | grep "^error"
cargo test
```

---

## What was NOT changed (still on your TODO)

- `obfs4` — still alpha/non-functional. Add a startup warning:
  ```rust
  tracing::warn!("⚠️  obfs4 transport is ALPHA and not functional — DPI evasion is inactive");
  ```
- Dead code: `obfs4_state` field in `MeshTransport` — remove it
- `cargo audit` — run this and fix what comes up
- `deny.toml` for `cargo-deny` — set up supply-chain policy
- GitHub Actions CI — add `cargo audit` + `cargo deny` + `cargo clippy --deny warnings`

---

## Competitive landscape — what exists and where Ghostwire sits

### Closest existing projects

**Veilid** (Cult of the Dead Cow, 2023)
- Written in Rust, same crypto choices (XChaCha20, X25519, Blake3, Argon2)
- "IPFS + Tor but faster" — fully distributed, no IP exposure
- Has Flutter bindings, runs on mobile, WASM, Linux, macOS, Windows
- **The most technically credible competitor** in this space
- Ghostwire differentiator: your Ubuntu philosophy / cypherpunk manifesto framing,
  local-first with offline Bluetooth/mesh, and Indra's Net multi-protocol vision

**Briar**
- Tor + Bluetooth + WiFi direct, works fully offline
- Java/Android-first, battle-tested in activist contexts
- No desktop-class UX, no PQ crypto
- Ghostwire differentiator: Rust, PQ crypto, better desktop UX, libp2p mesh

**Session**
- Oxen blockchain for routing, no phone number, onion routing
- Well-funded, polished apps on all platforms
- Blockchain dependency is ideological and technical baggage
- Ghostwire differentiator: no blockchain, purer P2P, fully local-first

**SimpleX Chat**
- No user IDs at all — not even random ones
- Uses relay servers (by design, for delivery guarantees)
- Ghostwire differentiator: fully serverless mesh, no relays needed

**I2P / Invisible Internet Project**
- Mature garlic routing network, 55k+ nodes
- Not a messenger — it's a transport layer
- Complex to run for normal users
- Ghostwire differentiator: integrated UX, lower barrier to entry

**Meshtastic**
- LoRa radio mesh, true off-grid hardware
- No internet dependency at all
- Hardware required, very low bandwidth
- Ghostwire differentiator: software-only, higher bandwidth, internet-capable

---

## What you haven't thought of (or haven't built yet)

### 1. Traffic analysis resistance — the gap nobody fully solves
Your `stealth_tcp` module fixes fingerprinting, but doesn't address *traffic analysis*:
an adversary watching timing and packet sizes can still infer who's talking to whom
even if they can't read content.

**What to add:**
- **Cover traffic / chaff**: periodically send dummy encrypted packets when idle.
  Briar does this; most others don't.
- **Constant-rate padding**: pad all messages to fixed 512-byte blocks before
  encryption. Eliminates message length as a signal.
- These are in your `armor.rs` (`TrafficArmor`) — wire it up properly.

### 2. Forward secrecy for stored messages
Your Double Ratchet in `crypto_machine.rs` gives forward secrecy for live sessions.
But what about messages stored in `sled`?

**What to add:**
- Encrypt the sled database with a key derived from the identity password + a
  separate storage key that rotates periodically.
- Implement *message expiry* — auto-delete stored messages after N days.
- This is what makes "sealed sender" meaningful: even if the device is seized,
  old messages aren't recoverable.

### 3. The "disaster mode" in `disaster.rs` — finish it
You have a `disaster.rs` module. This is one of Ghostwire's most unique features
— the ability to function when infrastructure collapses. But it's mostly stub.

**What to add:**
- Automatic fallback to Bluetooth when IP mesh fails (you have `bluetooth.rs`)
- QR-code-based key exchange for bootstrapping when DHT is unreachable
- Message store-and-forward: hold encrypted messages for offline peers and
  deliver when they reconnect (your `mailbox.rs` stub does this — finish it)

### 4. Federated trust / web of trust — missing entirely
Currently identity is self-sovereign with no verification. That's correct for
privacy, but creates a Sybil attack surface for the mesh.

**What to add:**
- **TOFU (Trust On First Use)** with key pinning — once you've seen a peer's
  key, flag changes prominently (like SSH)
- **Social graph attestation** — let peers vouch for each other's keys without
  a CA. This is what Briar's "trust through contact" model does.
- Your `reputation.rs` stub is the right place for this.

### 5. The Kenyan / African ISP context — you're ignoring your home field
Kenyan ISPs have specific properties you should design for:
- **Safaricom throttles certain ports** — your StealthTCP fix helps, but also
  run on port 443 (HTTPS-mimicking)
- **M-Pesa integrations** are how money moves here — if Ghostwire ever has a
  monetization layer (node incentives), M-Pesa APIs > crypto wallets for
  Kenyan users
- **Low-data modes**: consider a compressed message format for users on 3G.
  Protocol Buffers or MessagePack instead of JSON for wire format.
- **Meshtastic / LoRa bridges**: rural Kenya has poor coverage. A Ghostwire
  gateway that bridges IP mesh ↔ LoRa mesh for rural reach would be unique
  and genuinely valuable.

### 6. The identity recovery gap
Your `identity/recovery.rs` exists but the UX for it is unclear. If a user
forgets their password or loses their device, they lose everything.

**What to add:**
- Shamir Secret Sharing (`shamir_secret_sharing` is already in your Cargo.toml!)
  — split the identity key into N shares, give M to trusted contacts.
  Recovery requires M-of-N contacts to cooperate.
- This is a genuinely novel UX in the privacy app space. Most apps just say
  "you're on your own."

### 7. The API versioning and deprecation gap
You have `API_VERSIONING.md` but the actual implementation is ad-hoc. Routes
like `/v2/profile/lock` pointing to `IdentityController::setup` (the stub)
show the versioning is more aspirational than real.

**What to add:**
- Consistent versioning in all route handlers
- A `Deprecation` response header on any route being phased out
- OpenAPI spec generation with `utoipa` (already on your TODO)

### 8. You have `web3/` directory — what's in it?
Looking at the file tree you have a `web3` directory with no content shown.
If you're planning blockchain integration: don't. The philosophical argument
for Ghostwire is *no centralized dependencies*, and blockchains introduce
new consensus dependencies and economic incentives that work against that.
If you want peer incentives for running relay nodes, look at how Nym
(mixnet) handles this with a simpler stake mechanism, or just accept that
node operators are volunteers like Tor.

---

## The one-line version

Ghostwire's unique position: **Veilid without the framework complexity,
Briar with a better UX, Session without a blockchain, and designed for
the Global South first.**

That's a real gap in the market. Lock down the security basics in this
patch, finish disaster mode, add Shamir recovery, and you have something
nobody else has.
