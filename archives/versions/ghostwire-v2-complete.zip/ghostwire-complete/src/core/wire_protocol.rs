//! wire_protocol.rs — Compact binary wire format for constrained networks
//!
//! Context: Ghostwire targets Global South users first. Many Kenyan users
//! are on Safaricom 3G with metered data. JSON over HTTP is wasteful.
//!
//! This module provides a compact binary framing using MessagePack (via rmp-serde)
//! for peer-to-peer messages, cutting wire size by 50-70% vs. JSON.
//!
//! Frame layout (binary):
//!   [4 bytes magic "GWF\x01"][2 bytes kind][4 bytes payload len][payload]
//!
//! All frames are encrypted BEFORE this framing in the encryption layer.
//! The framing is for the raw transport layer only.

use anyhow::Result;
use serde::{Deserialize, Serialize};

/// Magic bytes for frame identification
pub const FRAME_MAGIC: [u8; 4] = *b"GWF\x01";

/// Message kinds on the wire
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, num_derive::FromPrimitive)]
#[repr(u16)]
pub enum FrameKind {
    /// Encrypted chat message
    Message = 0x0001,
    /// Peer discovery announcement
    Announce = 0x0002,
    /// DHT store request
    DhtPut = 0x0003,
    /// DHT fetch request
    DhtGet = 0x0004,
    /// DHT fetch response
    DhtValue = 0x0005,
    /// Route establishment
    RouteSetup = 0x0010,
    /// Routed payload (onion packet)
    RoutedPayload = 0x0011,
    /// Mailbox deposit
    MailboxDeposit = 0x0020,
    /// Mailbox drain request
    MailboxDrain = 0x0021,
    /// Ping / keepalive
    Ping = 0x00F0,
    /// Pong
    Pong = 0x00F1,
    /// Protocol version negotiation
    Handshake = 0x00FF,
}

/// A raw wire frame
#[derive(Debug, Clone)]
pub struct Frame {
    pub kind: FrameKind,
    pub payload: Vec<u8>,
}

impl Frame {
    pub fn new(kind: FrameKind, payload: Vec<u8>) -> Self {
        Self { kind, payload }
    }

    /// Serialize a typed message into a frame using MessagePack
    pub fn encode<T: Serialize>(kind: FrameKind, msg: &T) -> Result<Self> {
        let payload = rmp_serde::to_vec_named(msg)
            .map_err(|e| anyhow::anyhow!("MessagePack encode failed: {}", e))?;
        Ok(Self { kind, payload })
    }

    /// Deserialize the frame payload using MessagePack
    pub fn decode<T: for<'de> Deserialize<'de>>(&self) -> Result<T> {
        rmp_serde::from_slice(&self.payload)
            .map_err(|e| anyhow::anyhow!("MessagePack decode failed: {}", e))
    }

    /// Encode frame to raw bytes for the wire
    pub fn to_bytes(&self) -> Vec<u8> {
        let kind_bytes = (self.kind as u16).to_be_bytes();
        let len_bytes = (self.payload.len() as u32).to_be_bytes();

        let mut buf = Vec::with_capacity(10 + self.payload.len());
        buf.extend_from_slice(&FRAME_MAGIC);
        buf.extend_from_slice(&kind_bytes);
        buf.extend_from_slice(&len_bytes);
        buf.extend_from_slice(&self.payload);
        buf
    }

    /// Parse a frame from raw bytes. Returns (frame, bytes_consumed).
    pub fn from_bytes(buf: &[u8]) -> Result<(Self, usize)> {
        const HEADER_LEN: usize = 10; // magic(4) + kind(2) + len(4)

        if buf.len() < HEADER_LEN {
            anyhow::bail!("Buffer too short for frame header: {} bytes", buf.len());
        }

        // Verify magic
        if &buf[..4] != &FRAME_MAGIC {
            anyhow::bail!(
                "Invalid frame magic: {:?} (expected {:?})",
                &buf[..4],
                FRAME_MAGIC
            );
        }

        let kind_u16 = u16::from_be_bytes([buf[4], buf[5]]);
        let kind = num_traits::FromPrimitive::from_u16(kind_u16)
            .ok_or_else(|| anyhow::anyhow!("Unknown frame kind: 0x{:04X}", kind_u16))?;

        let payload_len = u32::from_be_bytes([buf[6], buf[7], buf[8], buf[9]]) as usize;

        if buf.len() < HEADER_LEN + payload_len {
            anyhow::bail!(
                "Buffer too short for payload: need {} + {}, have {}",
                HEADER_LEN,
                payload_len,
                buf.len()
            );
        }

        let payload = buf[HEADER_LEN..HEADER_LEN + payload_len].to_vec();
        Ok((Frame { kind, payload }, HEADER_LEN + payload_len))
    }
}

/// Wire-format chat message (compact vs. full Message struct)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WireMessage {
    /// Sender's node ID (32 bytes)
    #[serde(with = "serde_bytes")]
    pub from: Vec<u8>,
    /// Recipient's node ID or group ID (32 bytes)
    #[serde(with = "serde_bytes")]
    pub to: Vec<u8>,
    /// Encrypted payload (padded to block boundary)
    #[serde(with = "serde_bytes")]
    pub payload: Vec<u8>,
    /// Message UUID (16 bytes, compact)
    #[serde(with = "serde_bytes")]
    pub id: Vec<u8>,
    /// Unix timestamp (u32 — good until 2106)
    pub ts: u32,
    /// Sequence number for ordering
    pub seq: u32,
}

/// Wire-format peer announcement
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WireAnnounce {
    /// Node ID (32 bytes)
    #[serde(with = "serde_bytes")]
    pub node_id: Vec<u8>,
    /// Ed25519 public key (32 bytes)
    #[serde(with = "serde_bytes")]
    pub ed_pub: Vec<u8>,
    /// X25519 public key (32 bytes)
    #[serde(with = "serde_bytes")]
    pub x_pub: Vec<u8>,
    /// Supported crypto kinds (bitmask)
    pub crypto_mask: u8,
    /// Supported transports (bitmask: bit0=TCP, bit1=UDP, bit2=BT, bit3=LoRa)
    pub transport_mask: u8,
    /// Timestamp
    pub ts: u32,
    /// Ed25519 signature over all above fields
    #[serde(with = "serde_bytes")]
    pub sig: Vec<u8>,
}

/// Wire-format handshake (protocol negotiation)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WireHandshake {
    /// Protocol version (currently 1)
    pub version: u8,
    /// Crypto suites this node supports (list of CryptoKind values)
    pub crypto_suites: Vec<u8>,
    /// Transport capabilities bitmask
    pub capabilities: u16,
    /// Node ID
    #[serde(with = "serde_bytes")]
    pub node_id: Vec<u8>,
}

// ── Frame stream parser ───────────────────────────────────────────────────────

/// Parses a stream of bytes into frames, handling partial reads.
///
/// Usage:
/// ```rust
/// let mut parser = FrameParser::new();
/// loop {
///     let bytes = socket.read().await?;
///     for frame in parser.feed(&bytes)? {
///         handle_frame(frame).await;
///     }
/// }
/// ```
pub struct FrameParser {
    buf: Vec<u8>,
}

impl FrameParser {
    pub fn new() -> Self {
        Self { buf: Vec::with_capacity(4096) }
    }

    /// Feed new bytes and return any complete frames parsed
    pub fn feed(&mut self, data: &[u8]) -> Result<Vec<Frame>> {
        self.buf.extend_from_slice(data);
        let mut frames = Vec::new();

        loop {
            match Frame::from_bytes(&self.buf) {
                Ok((frame, consumed)) => {
                    frames.push(frame);
                    self.buf.drain(..consumed);
                }
                Err(e) => {
                    // "Buffer too short" is expected — wait for more data
                    let msg = e.to_string();
                    if msg.contains("too short") {
                        break;
                    }
                    // Any other error (bad magic, unknown kind) — clear buffer
                    self.buf.clear();
                    return Err(e);
                }
            }
        }

        Ok(frames)
    }

    /// How many bytes are buffered waiting for more data
    pub fn pending_bytes(&self) -> usize {
        self.buf.len()
    }
}

impl Default for FrameParser {
    fn default() -> Self {
        Self::new()
    }
}

// ── Size comparison (for README/docs) ────────────────────────────────────────

/// Compare JSON vs. MessagePack size for a typical message.
/// Run with: cargo test wire_size_comparison -- --nocapture
#[cfg(test)]
mod size_tests {
    use super::*;

    #[test]
    fn wire_size_comparison() {
        let msg = WireMessage {
            from: vec![0xAA; 32],
            to: vec![0xBB; 32],
            payload: vec![0xCC; 512], // padded message
            id: vec![0xDD; 16],
            ts: 1_700_000_000u32,
            seq: 42,
        };

        let json_size = serde_json::to_vec(&msg).unwrap().len();
        let frame = Frame::encode(FrameKind::Message, &msg).unwrap();
        let wire_size = frame.to_bytes().len();

        println!("JSON size:         {} bytes", json_size);
        println!("MsgPack+frame:     {} bytes", wire_size);
        println!("Savings:           {:.1}%", (1.0 - wire_size as f64 / json_size as f64) * 100.0);

        assert!(wire_size < json_size, "Wire format should be smaller than JSON");
    }

    #[test]
    fn frame_roundtrip() {
        let msg = WireHandshake {
            version: 1,
            crypto_suites: vec![0, 1],
            capabilities: 0b0000_0011,
            node_id: vec![0xEE; 32],
        };

        let frame = Frame::encode(FrameKind::Handshake, &msg).unwrap();
        let bytes = frame.to_bytes();

        let (parsed, consumed) = Frame::from_bytes(&bytes).unwrap();
        assert_eq!(consumed, bytes.len());
        assert_eq!(parsed.kind, FrameKind::Handshake);

        let recovered: WireHandshake = parsed.decode().unwrap();
        assert_eq!(recovered.version, 1);
        assert_eq!(recovered.node_id, msg.node_id);
    }

    #[test]
    fn frame_parser_handles_partial_reads() {
        let msg = WirePing { ts: 12345 };
        let frame = Frame::encode(FrameKind::Ping, &msg).unwrap();
        let bytes = frame.to_bytes();

        let mut parser = FrameParser::new();

        // Feed in two halves
        let half = bytes.len() / 2;
        let frames1 = parser.feed(&bytes[..half]).unwrap();
        assert!(frames1.is_empty(), "Partial frame should not parse yet");

        let frames2 = parser.feed(&bytes[half..]).unwrap();
        assert_eq!(frames2.len(), 1, "Complete frame should parse");
        assert_eq!(frames2[0].kind, FrameKind::Ping);
    }
}

#[derive(Debug, Serialize, Deserialize)]
struct WirePing { ts: u32 }

// ── Cargo.toml deps needed ────────────────────────────────────────────────────
// rmp-serde = "1.1"
// num-traits = "0.2"
// num-derive = "0.4"
// serde_bytes = "0.11"
// ─────────────────────────────────────────────────────────────────────────────
