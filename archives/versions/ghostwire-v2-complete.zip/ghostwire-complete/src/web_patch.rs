// web_appstate_patch.rs
// ─────────────────────────────────────────────────────────────────────────────
// This file shows the EXACT changes to make to src/web.rs
// Search for each "CHANGE:" marker and apply the diff.
// ─────────────────────────────────────────────────────────────────────────────

// ═══════════════════════════════════════════════════════════════
// CHANGE 1: AppState struct — add two new fields
// ═══════════════════════════════════════════════════════════════
//
// BEFORE:
//   pub struct AppState {
//       pub core: Arc<RwLock<Arc<Core>>>,
//       pub config: StartupConfig,
//       pub full_config: crate::config::Config,
//   }
//
// AFTER:
//   pub struct AppState {
//       pub core: Arc<RwLock<Arc<Core>>>,
//       pub config: StartupConfig,
//       pub full_config: crate::config::Config,
//       pub failed_attempt_tracker: Arc<crate::core::security_v2::FailedAttemptTracker>,
//       pub audit_logger: Arc<crate::core::security_v2::AuditLogger>,
//   }

// ═══════════════════════════════════════════════════════════════
// CHANGE 2: AppState construction — add two new fields
// ═══════════════════════════════════════════════════════════════
//
// BEFORE:
//   let app_state = Arc::new(AppState {
//       core: Arc::new(RwLock::new(initial_core)),
//       config: StartupConfig { bootstrap_nodes, sim_addr, mesh_host },
//       full_config: config,
//   });
//
// AFTER:
//   let app_state = Arc::new(AppState {
//       core: Arc::new(RwLock::new(initial_core)),
//       config: StartupConfig { bootstrap_nodes, sim_addr, mesh_host },
//       full_config: config,
//       failed_attempt_tracker: Arc::new(crate::core::security_v2::FailedAttemptTracker::default()),
//       audit_logger: Arc::new(crate::core::security_v2::AuditLogger::default()),
//   });

// ═══════════════════════════════════════════════════════════════
// CHANGE 3: Route wiring — replace stub lock/unlock with real handlers
// ═══════════════════════════════════════════════════════════════
//
// BEFORE (in the Router construction):
//   .route("/v2/profile/lock",   post(IdentityController::setup))
//   .route("/v2/profile/unlock", post(IdentityController::setup))
//
// AFTER:
//   .route("/v2/profile/lock",   post(IdentityController::lock_profile))
//   .route("/v2/profile/unlock", post(IdentityController::unlock_profile))
//   .route("/v2/security/audit", get(IdentityController::get_audit_log))

// ═══════════════════════════════════════════════════════════════
// CHANGE 4: JWT secret — make it stable across restarts
// ═══════════════════════════════════════════════════════════════
//
// PROBLEM: Current code generates JWT_SECRET randomly on each startup.
//          All existing sessions are invalidated on every daemon restart.
//
// SOLUTION: Derive the JWT secret from a persisted random seed stored
//           alongside the sled database, so it survives restarts.
//
// Replace the lazy_static! block with:
//
//   fn load_or_create_jwt_secret(data_dir: &std::path::Path) -> String {
//       let path = data_dir.join(".jwt_seed");
//       if let Ok(bytes) = std::fs::read(&path) {
//           if bytes.len() == 64 {
//               return hex::encode(bytes);
//           }
//       }
//       // Generate fresh seed
//       use ring::rand::{SecureRandom, SystemRandom};
//       let rng = SystemRandom::new();
//       let mut seed = [0u8; 64];
//       rng.fill(&mut seed).expect("RNG failed");
//       // Restrict permissions: owner read-only
//       use std::io::Write;
//       let mut f = std::fs::OpenOptions::new()
//           .write(true)
//           .create(true)
//           .truncate(true)
//           .open(&path)
//           .expect("Cannot write JWT seed");
//       #[cfg(unix)]
//       {
//           use std::os::unix::fs::OpenOptionsExt;
//           std::fs::OpenOptions::new()
//               .write(true).create(true).truncate(true)
//               .mode(0o600)
//               .open(&path)
//               .expect("Cannot write JWT seed")
//               .write_all(&seed)
//               .expect("Write failed");
//       }
//       #[cfg(not(unix))]
//       f.write_all(&seed).expect("Write failed");
//       hex::encode(seed)
//   }
//
//   // Call during start_web_server():
//   let jwt_secret = load_or_create_jwt_secret(&config.data_dir);
//   // Pass jwt_secret into AppState and use it in JWT encode/decode
//   // instead of the global JWT_SECRET lazy_static.

// ═══════════════════════════════════════════════════════════════
// CHANGE 5: Security headers middleware — add to Axum Router
// ═══════════════════════════════════════════════════════════════
//
// Add this function to web.rs:
//
//   use axum::middleware::Next;
//   use axum::response::Response;
//   use axum::http::Request;
//
//   pub async fn security_headers<B>(req: Request<B>, next: Next<B>) -> Response {
//       let mut res = next.run(req).await;
//       let headers = res.headers_mut();
//       headers.insert("X-Content-Type-Options",  "nosniff".parse().unwrap());
//       headers.insert("X-Frame-Options",          "DENY".parse().unwrap());
//       headers.insert("X-XSS-Protection",         "1; mode=block".parse().unwrap());
//       headers.insert("Referrer-Policy",           "no-referrer".parse().unwrap());
//       headers.insert("Permissions-Policy",        "geolocation=(), microphone=(), camera=()".parse().unwrap());
//       res
//   }
//
// Then add .layer(middleware::from_fn(security_headers)) to your Router.

// ═══════════════════════════════════════════════════════════════
// CHANGE 6: Unlock rate limiter — replace commented-out governor
// ═══════════════════════════════════════════════════════════════
//
// The FailedAttemptTracker in the identity controller (Change 1-3) 
// handles per-IP and per-profile rate limiting without relying on
// tower_governor middleware, which was causing frontend init burst issues.
//
// You can safely remove the commented-out governor imports in web.rs.
// The new approach is request-level, not middleware-level, so it
// doesn't interfere with the frontend asset serving burst.

// ═══════════════════════════════════════════════════════════════
// CHANGE 7: ConnectInfo extractor — needed for IP tracking
// ═══════════════════════════════════════════════════════════════
//
// The unlock_profile handler uses ConnectInfo<SocketAddr>.
// Make sure the Axum listener is built with into_make_service_with_connect_info:
//
// BEFORE:
//   axum::serve(listener, app).await?;
//
// AFTER:
//   axum::serve(listener, app.into_make_service_with_connect_info::<SocketAddr>()).await?;

// ─────────────────────────────────────────────────────────────────────────────
// That's all 7 changes. The actual full file is too large to reproduce here —
// apply these as targeted edits to your existing src/web.rs.
// Each change is self-contained and won't affect unrelated code.
// ─────────────────────────────────────────────────────────────────────────────
