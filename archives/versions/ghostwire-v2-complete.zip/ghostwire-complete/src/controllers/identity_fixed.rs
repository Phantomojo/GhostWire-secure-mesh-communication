// identity_fixed.rs — Drop-in replacement for controllers/identity.rs
// Changes:
//   - /api/v2/profile/unlock  → brute-force protected via FailedAttemptTracker + AuditLogger
//   - /api/v2/profile/lock    → audit logged
//   - AppState gains failed_attempt_tracker + audit_logger fields
//   - All unwrap() in hot paths replaced with proper error handling

use crate::api_v2_types::*;
use crate::core::security_v2::{
    AuditLogger, EntityType, FailedAttemptTracker, SecurityAuditRecord, ThreatLevel,
};
use crate::web::AppState;
use axum::extract::ConnectInfo;
use axum::http::StatusCode;
use axum::{extract::State, response::IntoResponse, Json};
use base64::{engine::general_purpose, Engine as _};
use serde::{Deserialize, Serialize};
use std::net::SocketAddr;
use std::sync::Arc;

// ── AppState extension ──────────────────────────────────────────────────────
// Add these two fields to the AppState struct in web.rs:
//
//   pub failed_attempt_tracker: Arc<FailedAttemptTracker>,
//   pub audit_logger:           Arc<AuditLogger>,
//
// And in start_web_server(), initialise them:
//
//   let app_state = Arc::new(AppState {
//       core: ...,
//       config: ...,
//       full_config: ...,
//       failed_attempt_tracker: Arc::new(FailedAttemptTracker::default()),
//       audit_logger:           Arc::new(AuditLogger::default()),
//   });

// ── Request / Response types ─────────────────────────────────────────────────

#[derive(Deserialize)]
pub struct SetupRequest {
    pub nickname: String,
    pub password: String,
}

#[derive(Deserialize)]
pub struct UnlockRequest {
    pub profile: String,
    pub password: String,
}

#[derive(Serialize)]
struct LockoutResponse {
    locked_out: bool,
    retry_after_secs: u64,
}

// ── Controller ───────────────────────────────────────────────────────────────

pub struct IdentityController;

impl IdentityController {
    // ── GET /api/v2/profile ─────────────────────────────────────────────────

    pub async fn get_profile(State(state): State<Arc<AppState>>) -> impl IntoResponse {
        #[derive(Serialize)]
        struct ProfileResponse {
            id: String,
            did: String,
            username: String,
            nickname: String,
            bio: String,
            public_key: String,
            key_id: String,
            created_at: String,
            dht_published: bool,
            security_score: u8,
            setup_complete: bool,
        }

        let core = state.core.read().await;
        let metadata = core.get_metadata().await;
        let security_score = core
            .security_manager
            .clone()
            .calculate_security_score()
            .await;

        let profile = ProfileResponse {
            id: core.get_identity_id().await,
            did: core.get_did().await,
            username: metadata.nickname.clone(),
            nickname: metadata.nickname,
            bio: metadata.bio,
            public_key: general_purpose::STANDARD.encode(core.get_public_key()),
            key_id: core.get_key_id(),
            created_at: chrono::Utc::now().to_rfc3339(),
            dht_published: false,
            security_score,
            setup_complete: metadata.setup_complete,
        };

        Json(ApiV2Response::success(profile).with_links("/api/v2/profile".to_string()))
    }

    // ── POST /api/v2/profile/unlock ─────────────────────────────────────────
    // Protected by: FailedAttemptTracker (5 attempts → 5 min lockout) + AuditLogger

    pub async fn unlock_profile(
        ConnectInfo(addr): ConnectInfo<SocketAddr>,
        State(state): State<Arc<AppState>>,
        Json(req): Json<UnlockRequest>,
    ) -> impl IntoResponse {
        let ip_key = addr.ip().to_string();
        let profile_key = format!("profile:{}", req.profile);

        // Check IP-level lockout
        if state
            .failed_attempt_tracker
            .is_locked_out(&ip_key)
            .await
        {
            state.audit_logger.log_event(&SecurityAuditRecord {
                event_type: "UNLOCK_REJECTED_LOCKOUT".to_string(),
                entity_type: EntityType::IP,
                entity_id: ip_key.clone(),
                threat_level: ThreatLevel::High,
                timestamp: now_secs(),
                description: format!(
                    "Unlock attempt blocked — IP {} is locked out",
                    ip_key
                ),
            });

            return (
                StatusCode::TOO_MANY_REQUESTS,
                Json(ApiV2Response::<LockoutResponse>::success(LockoutResponse {
                    locked_out: true,
                    retry_after_secs: 300,
                })),
            )
                .into_response();
        }

        // Check profile-level lockout
        if state
            .failed_attempt_tracker
            .is_locked_out(&profile_key)
            .await
        {
            state.audit_logger.log_event(&SecurityAuditRecord {
                event_type: "UNLOCK_REJECTED_LOCKOUT".to_string(),
                entity_type: EntityType::Node,
                entity_id: req.profile.clone(),
                threat_level: ThreatLevel::High,
                timestamp: now_secs(),
                description: format!(
                    "Unlock attempt blocked — profile '{}' is locked out",
                    req.profile
                ),
            });

            return (
                StatusCode::TOO_MANY_REQUESTS,
                Json(ApiV2Response::<LockoutResponse>::success(LockoutResponse {
                    locked_out: true,
                    retry_after_secs: 300,
                })),
            )
                .into_response();
        }

        // Attempt unlock
        let core = state.core.read().await;
        match core.unlock(&req.password).await {
            Ok(_) => {
                // Success — clear both counters
                state.failed_attempt_tracker.reset(&ip_key).await;
                state.failed_attempt_tracker.reset(&profile_key).await;

                state.audit_logger.log_event(&SecurityAuditRecord {
                    event_type: "UNLOCK_SUCCESS".to_string(),
                    entity_type: EntityType::Node,
                    entity_id: req.profile.clone(),
                    threat_level: ThreatLevel::Low,
                    timestamp: now_secs(),
                    description: format!(
                        "Profile '{}' unlocked from {}",
                        req.profile, ip_key
                    ),
                });

                Json(ApiV2Response::success(serde_json::json!({
                    "status": "unlocked",
                    "profile": req.profile,
                })))
                .into_response()
            }
            Err(e) => {
                // Failure — record against both IP and profile
                state
                    .failed_attempt_tracker
                    .record_failure(&ip_key)
                    .await;
                state
                    .failed_attempt_tracker
                    .record_failure(&profile_key)
                    .await;

                state.audit_logger.log_event(&SecurityAuditRecord {
                    event_type: "UNLOCK_FAILED".to_string(),
                    entity_type: EntityType::Node,
                    entity_id: req.profile.clone(),
                    threat_level: ThreatLevel::Medium,
                    timestamp: now_secs(),
                    description: format!(
                        "Failed unlock attempt for profile '{}' from {}: {}",
                        req.profile, ip_key, e
                    ),
                });

                (
                    StatusCode::UNAUTHORIZED,
                    Json(ApiV2Response::<()>::error(
                        StandardErrorCode::InvalidCredentials.as_str(),
                        "Invalid password",
                    )),
                )
                    .into_response()
            }
        }
    }

    // ── POST /api/v2/profile/lock ────────────────────────────────────────────

    pub async fn lock_profile(
        ConnectInfo(addr): ConnectInfo<SocketAddr>,
        State(state): State<Arc<AppState>>,
    ) -> impl IntoResponse {
        let core = state.core.read().await;
        match core.lock().await {
            Ok(_) => {
                state.audit_logger.log_event(&SecurityAuditRecord {
                    event_type: "PROFILE_LOCKED".to_string(),
                    entity_type: EntityType::Node,
                    entity_id: core.get_identity_id().await,
                    threat_level: ThreatLevel::Low,
                    timestamp: now_secs(),
                    description: format!("Profile locked from {}", addr.ip()),
                });

                Json(ApiV2Response::success(serde_json::json!({ "status": "locked" })))
                    .into_response()
            }
            Err(e) => (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(ApiV2Response::<()>::error(
                    StandardErrorCode::InternalError.as_str(),
                    format!("Failed to lock: {}", e),
                )),
            )
                .into_response(),
        }
    }

    // ── POST /api/identity/setup ─────────────────────────────────────────────

    pub async fn setup(
        State(state): State<Arc<AppState>>,
        Json(req): Json<SetupRequest>,
    ) -> impl IntoResponse {
        if req.password.len() < 8 {
            return (
                StatusCode::BAD_REQUEST,
                Json(ApiV2Response::<()>::error(
                    StandardErrorCode::InvalidInput.as_str(),
                    "Password must be at least 8 characters",
                )),
            )
                .into_response();
        }

        let core = state.core.read().await;

        if core.is_locked().await {
            if let Err(e) = core.unlock("ghostwire").await {
                tracing::error!(target: "identity_setup", "❌ Failed to unlock: {}", e);
                return (
                    StatusCode::UNAUTHORIZED,
                    Json(ApiV2Response::<()>::error(
                        StandardErrorCode::InvalidCredentials.as_str(),
                        "Failed to unlock identity for setup",
                    )),
                )
                    .into_response();
            }
        }

        core.update_metadata(Some(req.nickname.clone()), None, None, Some(true))
            .await;

        if let Err(e) = core.save_to_disk(&req.password).await {
            return (
                StatusCode::INTERNAL_SERVER_ERROR,
                Json(ApiV2Response::<()>::error(
                    StandardErrorCode::InternalError.as_str(),
                    format!("Failed to secure identity: {}", e),
                )),
            )
                .into_response();
        }

        state.audit_logger.log_event(&SecurityAuditRecord {
            event_type: "IDENTITY_SETUP".to_string(),
            entity_type: EntityType::Node,
            entity_id: req.nickname.clone(),
            threat_level: ThreatLevel::Low,
            timestamp: now_secs(),
            description: format!("Identity setup completed for '{}'", req.nickname),
        });

        Json(ApiV2Response::success(serde_json::json!({
            "status": "identity_secured",
            "nickname": req.nickname
        })))
        .into_response()
    }

    // ── GET /api/v2/security/audit ───────────────────────────────────────────

    pub async fn get_audit_log(State(state): State<Arc<AppState>>) -> impl IntoResponse {
        let events = state.audit_logger.get_recent_events(100).await;
        Json(ApiV2Response::success(events))
    }

    // ── Other existing endpoints (unchanged) ─────────────────────────────────

    pub async fn update_username(
        State(state): State<Arc<AppState>>,
        Json(req): Json<serde_json::Value>,
    ) -> impl IntoResponse {
        #[derive(Serialize)]
        struct UsernameUpdateResponse {
            username: String,
            updated_at: String,
        }

        let username = req.get("username").and_then(|v| v.as_str()).unwrap_or("");

        if username.is_empty() || username.len() > 32 {
            return Json(ApiV2Response::<()>::error(
                "INVALID_USERNAME",
                "Username must be 1-32 characters",
            ))
            .into_response();
        }

        state
            .core
            .read()
            .await
            .update_metadata(Some(username.to_string()), None, None, None)
            .await;

        Json(ApiV2Response::success(UsernameUpdateResponse {
            username: username.to_string(),
            updated_at: chrono::Utc::now().to_rfc3339(),
        }))
        .into_response()
    }

    pub async fn update_metadata(
        State(state): State<Arc<AppState>>,
        Json(req): Json<serde_json::Value>,
    ) -> impl IntoResponse {
        let nickname = req
            .get("nickname")
            .and_then(|v| v.as_str().map(|s| s.to_string()));
        let bio = req
            .get("bio")
            .and_then(|v| v.as_str().map(|s| s.to_string()));
        let avatar_url = req
            .get("avatar_url")
            .and_then(|v| v.as_str().map(|s| s.to_string()));

        state
            .core
            .read()
            .await
            .update_metadata(nickname, bio, avatar_url, None)
            .await;

        Json(ApiV2Response::success(serde_json::json!({
            "status": "updated",
            "timestamp": chrono::Utc::now().to_rfc3339()
        })))
    }

    pub async fn get_public_key(State(state): State<Arc<AppState>>) -> impl IntoResponse {
        #[derive(Serialize)]
        struct PublicKeyResponse {
            key_id: String,
            algorithm: String,
            public_key: String,
            created_at: String,
        }

        let core = state.core.read().await;
        Json(ApiV2Response::success(PublicKeyResponse {
            key_id: core.get_key_id(),
            algorithm: "Ed25519".to_string(),
            public_key: general_purpose::STANDARD.encode(core.get_public_key()),
            created_at: chrono::Utc::now().to_rfc3339(),
        }))
    }

    pub async fn report_error(Json(req): Json<ErrorReportRequest>) -> impl IntoResponse {
        eprintln!("[REMOTE ERROR REPORT] {}", req.error);
        Json(ApiV2Response::success(
            serde_json::json!({ "status": "reported" }),
        ))
    }

    pub async fn get_tutorial() -> impl IntoResponse {
        Json(ApiV2Response::success(
            crate::core::tutorial::get_tutorial_steps(),
        ))
    }
}

#[derive(Deserialize)]
pub struct ErrorReportRequest {
    pub error: String,
}

// ── Helpers ──────────────────────────────────────────────────────────────────

fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}
