# GHOSTWIRE — AGENT INSTRUCTIONS
# Complete Integration & Implementation Guide
# Version: 2.0 | Updated: March 2026
# Author: phantomojo (Michael) | Head of Security, RVC

---

## WHAT THIS PACKAGE IS

This ZIP contains the complete Ghostwire codebase with:
1. **Bug fixes** for all critical security gaps identified in the audit
2. **New modules** scaffolded and ready for integration
3. **Veilid-inspired features** adapted for Ghostwire's architecture
4. **Strategic notes** explaining design decisions

The existing codebase lives in `/ghostwire/src/`. New modules are in `/ghostwire-complete/src/`.

---

## YOUR JOB AS THE INTEGRATING AGENT

Read this entire file before touching any code. Then follow the phases in order.

---

## PHASE 0 — ENVIRONMENT SETUP

```bash
# Verify Rust toolchain
rustup show
cargo --version  # should be >= 1.75

# Install required tools
cargo install cargo-audit
cargo install cargo-deny

# From the ghostwire/ directory:
cargo check 2>&1 | grep "^error" | head -20
```

If `cargo check` has errors before you start, document them and fix them first.
Do NOT attempt to integrate new modules into a codebase that doesn't compile.

---

## PHASE 1 — APPLY CRITICAL SECURITY FIXES

These are the highest-priority changes. Apply them first. Test after each one.

### 1.1 — AppState: add security fields

File: `ghostwire/src/web.rs`

Find the `AppState` struct:
```rust
pub struct AppState {
    pub core: Arc<RwLock<Arc<Core>>>,
    pub config: StartupConfig,
    pub full_config: crate::config::Config,
}
```

Replace with:
```rust
pub struct AppState {
    pub core: Arc<RwLock<Arc<Core>>>,
    pub config: StartupConfig,
    pub full_config: crate::config::Config,
    pub failed_attempt_tracker: Arc<crate::core::security_v2::FailedAttemptTracker>,
    pub audit_logger: Arc<crate::core::security_v2::AuditLogger>,
    pub jwt_secret: String,
}
```

### 1.2 — AppState construction: wire the new fields

In `start_web_server()`, find the `AppState { ... }` construction and add:
```rust
let jwt_secret = load_or_create_jwt_secret(&config.data_dir);
// ...
let app_state = Arc::new(AppState {
    core: Arc::new(RwLock::new(initial_core)),
    config: StartupConfig { bootstrap_nodes, sim_addr, mesh_host },
    full_config: config,
    failed_attempt_tracker: Arc::new(crate::core::security_v2::FailedAttemptTracker::default()),
    audit_logger: Arc::new(crate::core::security_v2::AuditLogger::default()),
    jwt_secret,
});
```

### 1.3 — Add jwt_and_headers.rs

Copy `ghostwire-complete/src/jwt_and_headers.rs` to `ghostwire/src/jwt_and_headers.rs`.

Add to `ghostwire/src/lib.rs` or `main.rs`:
```rust
mod jwt_and_headers;
use jwt_and_headers::{load_or_create_jwt_secret, security_headers};
```

Add to the Axum Router in `web.rs`:
```rust
use axum::middleware;
// ...
let app = Router::new()
    // ...existing routes...
    .layer(middleware::from_fn(security_headers));
```

### 1.4 — Replace identity controller with fixed version

Copy `ghostwire-complete/src/controllers/identity_fixed.rs`
to `ghostwire/src/controllers/identity.rs` (overwrite).

Update `ghostwire/src/controllers/mod.rs` to ensure `IdentityController` is exported.

### 1.5 — Fix unlock/lock routes

In `web.rs`, find and replace:
```rust
// BEFORE (broken stubs):
.route("/v2/profile/lock",   post(IdentityController::setup))
.route("/v2/profile/unlock", post(IdentityController::setup))

// AFTER (real handlers):
.route("/v2/profile/lock",   post(IdentityController::lock_profile))
.route("/v2/profile/unlock", post(IdentityController::unlock_profile))
.route("/v2/security/audit", get(IdentityController::get_audit_log))
```

### 1.6 — Fix StealthTCP magic bytes

Copy `ghostwire-complete/src/core/stealth_tcp_handshake_fix.rs` — read it carefully.

In `ghostwire/src/core/stealth_tcp.rs`:
- DELETE: `const MAGIC_BYTES: &[u8; 5] = b"GWSTH";`
- DELETE: `const STEALTH_VERSION: u8 = 0x01;`
- DELETE the `perform_stealth_handshake()` method
- DELETE the `perform_challenge_response()` method
- ADD the two new methods: `initiate_stealth_handshake()` and `respond_stealth_handshake()`

Update call sites in `stealth_tcp.rs`:
- On TCP accept (server side): call `respond_stealth_handshake(stream).await?`
- On TCP connect (client side): call `initiate_stealth_handshake(stream).await?`

### 1.7 — Add ConnectInfo to Axum serve

In `web.rs`, find:
```rust
axum::serve(listener, app).await?;
```
Replace with:
```rust
axum::serve(
    listener,
    app.into_make_service_with_connect_info::<std::net::SocketAddr>()
).await?;
```

### 1.8 — Remove dead code

In `ghostwire/src/core/stealth_tcp.rs` or wherever `MeshTransport` is defined,
remove or comment out the `obfs4_state` field flagged in TODO #4.

### 1.9 — Add obfs4 startup warning

In `main.rs`, near startup logging:
```rust
tracing::warn!(
    "⚠️  obfs4 transport is ALPHA and NOT functional. \
     DPI evasion is inactive. Do not rely on it for operational security."
);
```

**After Phase 1**: Run `cargo build`. Fix any compile errors. Do NOT proceed until it builds.

---

## PHASE 2 — INTEGRATE NEW CORE MODULES

Add these new files to `ghostwire/src/core/`:

| Source | Destination | Notes |
|--------|------------|-------|
| `ghostwire-complete/src/core/mailbox.rs` | `ghostwire/src/core/mailbox.rs` | Replaces stub |
| `ghostwire-complete/src/core/traffic_armor.rs` | `ghostwire/src/core/traffic_armor.rs` | Replaces stub in armor.rs |
| `ghostwire-complete/src/core/encrypted_store.rs` | `ghostwire/src/core/encrypted_store.rs` | New |
| `ghostwire-complete/src/core/disaster.rs` | `ghostwire/src/core/disaster.rs` | Replaces stub |
| `ghostwire-complete/src/core/reputation.rs` | `ghostwire/src/core/reputation.rs` | Replaces stub |
| `ghostwire-complete/src/core/typed_crypto.rs` | `ghostwire/src/core/typed_crypto.rs` | New |
| `ghostwire-complete/src/core/wire_protocol.rs` | `ghostwire/src/core/wire_protocol.rs` | New |
| `ghostwire-complete/src/core/recovery_shamir.rs` | `ghostwire/src/core/recovery_shamir.rs` | New |
| `ghostwire-complete/src/core/routing/private_routing.rs` | `ghostwire/src/core/routing/private_routing.rs` | New |

### Update `ghostwire/src/core/mod.rs`

Add these module declarations:
```rust
pub mod encrypted_store;
pub mod typed_crypto;
pub mod wire_protocol;
pub mod recovery_shamir;
pub mod traffic_armor;
pub mod routing {
    pub mod private_routing;
}
```

### Cargo.toml additions needed

Add to `ghostwire/Cargo.toml` under `[dependencies]`:
```toml
# New for v2 modules
blake3 = "1.5"
rmp-serde = "1.1"
num-traits = "0.2"
num-derive = "0.4"
serde_bytes = "0.11"
```

`blake3` replaces some usages of `sha2` for non-standard contexts.
Everything else already exists in the dependency tree.

### Wire `TrustStore` into `Core`

In `ghostwire/src/core/mod.rs`, in the `Core` struct, add:
```rust
pub trust_store: Arc<crate::core::reputation::TrustStore>,
```

In `Core::new()`, initialize it:
```rust
trust_store: Arc::new(crate::core::reputation::TrustStore::new()),
```

In `mesh.rs`, wherever a peer's public key is first seen, call:
```rust
core.trust_store.verify_or_pin(&peer_id_str, &pub_key_bytes).await?;
```

### Wire `DisasterManager` into `Core`

```rust
// In Core struct:
pub disaster_manager: Arc<crate::core::disaster::DisasterManager>,

// In Core::new():
let (disaster_tx, mut disaster_rx) = tokio::sync::mpsc::channel(64);
let disaster_manager = Arc::new(crate::core::disaster::DisasterManager::new(disaster_tx));
disaster_manager.clone().start_monitor();
```

### Wire `TrafficArmor` into message send path

In `mesh.rs` or wherever messages are sent to peers:
```rust
// Before encrypting a message:
let (cover_tx, cover_rx) = tokio::sync::mpsc::channel(32);
let armor = crate::core::traffic_armor::TrafficArmor::new(Some(cover_tx));
let frame = armor.wrap(plaintext).await?;
// Encrypt frame.data instead of raw plaintext
```

---

## PHASE 3 — SECURITY HARDENING

### 3.1 — Run cargo audit

```bash
cd ghostwire/
cargo audit
```

Fix any HIGH or CRITICAL vulnerabilities. For MEDIUM, document them in `docs/AUDIT_REPORT.md`.

### 3.2 — Create deny.toml

Create `ghostwire/deny.toml`:
```toml
[advisories]
vulnerability = "deny"
unmaintained = "warn"
yanked = "deny"

[licenses]
unlicensed = "deny"
allow = [
    "MIT",
    "Apache-2.0",
    "Apache-2.0 WITH LLVM-exception",
    "BSD-2-Clause",
    "BSD-3-Clause",
    "ISC",
    "Unicode-DFS-2016",
    "MPL-2.0",
    "AGPL-3.0",
]
copyleft = "warn"

[bans]
multiple-versions = "warn"
```

Then run: `cargo deny check`

### 3.3 — Fix unwrap() in crypto paths

Run:
```bash
grep -rn "\.unwrap()" ghostwire/src/core/ | grep -v "test\|#\[" | head -30
```

For each `.unwrap()` in non-test crypto code, replace with:
```rust
// BEFORE:
let result = some_operation().unwrap();

// AFTER:
let result = some_operation()
    .map_err(|e| anyhow::anyhow!("Operation failed: {}", e))?;
```

Priority files: `encryption.rs`, `crypto_machine.rs`, `identity/core_identity.rs`

### 3.4 — Encrypted sled storage migration

Wherever `sled` is currently used for storing messages or sensitive data,
wrap it with `EncryptedStore`:

```rust
// BEFORE:
let db = sled::open(&config.data_dir)?;
db.insert("key", value)?;

// AFTER:
let db = Arc::new(sled::open(&config.data_dir)?);
let store = EncryptedStore::open(db, &profile_password, "messages").await?;
store.put("key", &value, None).await?;
```

---

## PHASE 4 — API ADDITIONS

### New endpoints to add in `web.rs`

```rust
// Recovery / Shamir
.route("/v2/recovery/setup",     post(RecoveryController::setup_shares))
.route("/v2/recovery/my-shares", get(RecoveryController::list_my_shares))
.route("/v2/recovery/reconstruct", post(RecoveryController::reconstruct_key))

// Trust / Reputation
.route("/v2/trust/:peer_id",     get(TrustController::get_trust))
.route("/v2/trust/:peer_id/verify", post(TrustController::mark_verified))
.route("/v2/trust/:peer_id/block", post(TrustController::block_peer))
.route("/v2/trust",              get(TrustController::list_peers))

// Disaster mode
.route("/v2/network/status",     get(DisasterController::status))
.route("/v2/network/qr-contact", get(DisasterController::generate_contact_qr))
.route("/v2/network/scan-qr",    post(DisasterController::scan_contact_qr))

// Security audit log
.route("/v2/security/audit",     get(IdentityController::get_audit_log))
```

Create stub controllers in `ghostwire/src/controllers/`:
- `recovery.rs` — calls `recovery_shamir.rs` functions
- `trust.rs` — calls `reputation.rs` TrustStore methods
- `disaster_ctrl.rs` — calls `disaster.rs` DisasterManager

---

## PHASE 5 — TESTING

### Unit tests

```bash
cargo test --all 2>&1 | tail -30
```

All tests in the new modules should pass. Key test suites:
- `mailbox.rs`: seal/open roundtrip, inbox size limit
- `traffic_armor.rs`: pad/unpad roundtrip, cover frame handling
- `encrypted_store.rs`: put/get, expiry, key hashing
- `disaster.rs`: queue/mark-delivered, QR encode/decode
- `reputation.rs`: TOFU pin, key change detection, block
- `typed_crypto.rs`: NodeId, wire roundtrip, XOR distance
- `wire_protocol.rs`: frame roundtrip, partial read handling, size comparison

### Integration smoke test

```bash
# Start the daemon
cargo run -- --config ghostwire.toml.example

# In another terminal:
curl -s http://localhost:8080/api/v2/health | jq .

# Test unlock with wrong password (should eventually lock out):
for i in {1..6}; do
  curl -s -X POST http://localhost:8080/api/v2/profile/unlock \
    -H "Content-Type: application/json" \
    -d '{"profile":"default","password":"wrong"}' | jq .
  sleep 0.5
done
# 6th attempt should return 429 Too Many Requests
```

---

## PHASE 6 — WHAT REMAINS (FUTURE AGENTS)

The following features are designed but not yet fully implemented.
A future agent should pick up where this one leaves off.

### 6.1 — obfs4 transport (HIGH PRIORITY)
**File:** `ghostwire/src/core/obfs4_transport.rs`
**Status:** Alpha stub with no real traffic obfuscation
**Task:** Integrate the `obfs4` crate's actual scrambling. The crate is alpha;
consider using the `ptv2` pluggable transport protocol instead if it matures.
**Reference:** Tor Project's obfs4 spec at https://gitlab.com/yawning/obfs4

### 6.2 — Private routing integration (MEDIUM PRIORITY)
**File:** `ghostwire/src/core/routing/private_routing.rs` (newly scaffolded)
**Status:** Core logic written; not wired into mesh.rs
**Task:**
1. In `mesh.rs`, when sending a message to a peer: if privacy mode is on,
   build a compiled route using `build_route()`, wrap with `wrap_onion()`,
   and send via libp2p gossipsub as a `RoutedPayload` frame.
2. Add a relay handler: when receiving a `RoutedPayload`, call `peel_onion_layer()`
   and forward to the next hop.
3. Integrate with `RouteCache` to reuse routes.

### 6.3 — Shamir recovery UX (MEDIUM PRIORITY)
**File:** `ghostwire/src/core/recovery_shamir.rs` (newly scaffolded)
**Status:** Core crypto written; controller stubs needed
**Task:**
1. Implement `RecoveryController` in `src/controllers/recovery.rs`
2. Add WebUI flow: "Set up recovery" → pick M/N → select guardian peers →
   route encrypted shares to each guardian via the mesh
3. Add WebUI flow: "Recover account" → request shares from guardians →
   combine → re-encrypt with new password

### 6.4 — Bluetooth LE transport (LOW PRIORITY)
**File:** `ghostwire/src/core/bluetooth.rs`
**Status:** Stub; btleplug is in Cargo.toml
**Task:** Implement peer discovery and message exchange via BLE.
**Reference:** btleplug docs at https://docs.rs/btleplug

### 6.5 — LoRa bridge (LOW PRIORITY, HIGH IMPACT)
**Status:** Not started
**Task:** Create a bridge process that relays Ghostwire mesh messages to/from
a LoRa radio (e.g. LILYGO T-Beam or RAK WisBlock) via serial port.
**Why:** Rural Kenya connectivity; genuine differentiator.
**Reference:** `serialport` crate (already in Cargo.toml as optional)

### 6.6 — OpenAPI / Swagger docs (LOW PRIORITY)
**Task:** Add `utoipa` crate, annotate all API endpoints with `#[utoipa::path]`,
generate the spec at `/api/docs`.
**Cargo.toml:** `utoipa = { version = "4", features = ["axum_extras"] }`

### 6.7 — GitHub Actions CI (LOW PRIORITY)
Create `.github/workflows/security.yml`:
```yaml
name: Security
on: [push, pull_request]
jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: rustsec/audit-check@v1
        with:
          token: ${{ secrets.GITHUB_TOKEN }}
  deny:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: EmbarkStudios/cargo-deny-action@v1
  clippy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: cargo clippy -- -D warnings
```

---

## WHAT WE BORROWED FROM VEILID (AND HOW)

| Veilid Concept | Our Implementation | File |
|---------------|-------------------|------|
| Typed cryptographic keys (VLD0 tag) | `CryptoKind` enum, `TypedPublicKey` wire format | `typed_crypto.rs` |
| TableStore (encrypted KV) | `EncryptedStore` with Argon2 key derivation | `encrypted_store.rs` |
| Multi-writer DHT "leave notes" | `MailboxStore` — offline delivery via DHT | `mailbox.rs` |
| Safety Route + Private Route | `CompiledRoute` with `wrap_onion()` / `peel_onion_layer()` | `routing/private_routing.rs` |
| No special nodes (all equal) | Kept: libp2p has no designated special nodes | `mesh.rs` (existing) |
| Node ID = hash of public key | `NodeId::from_ed25519_pub()` via BLAKE3 | `typed_crypto.rs` |
| Cryptosystem migration support | `CryptoKind` versioning allows future GW1 migration | `typed_crypto.rs` |

**What Veilid does that we don't (yet):**
- Their BlockStore (BitTorrent-style content distribution)
- Platform-native secret storage (macOS Keychain, Android Keystore)
  → We use Argon2-derived keys in sled instead
- Flutter/Dart bindings for mobile
  → We use Tauri for cross-platform

**Where we go further than Veilid:**
- Message padding (they don't do this — flagged in their IEEE CSR 2024 paper)
- Cover traffic scheduler (they don't have this)
- Shamir recovery with social graph (novel in this space)
- Disaster mode with transport fallback chain
- QR-based air-gap key exchange
- LoRa bridge (planned)

---

## ARCHITECTURE DIAGRAM

```
┌─────────────────────────────────────────────────────────┐
│                    GHOSTWIRE v2.0                       │
├─────────────────────────────────────────────────────────┤
│  WebUI (React/Tauri)  │  CLI  │  Android (future)       │
├───────────────────────┴───────┴─────────────────────────┤
│  Axum API (web.rs) + Security headers + JWT             │
│  Controllers: identity | profiles | peers | recovery    │
│  Rate limiting: FailedAttemptTracker (per-IP + per-user)│
├─────────────────────────────────────────────────────────┤
│  Core (mod.rs)                                          │
│  ┌──────────────┐ ┌──────────────┐ ┌─────────────────┐ │
│  │ CryptoMachine│ │EncryptionMgr │ │  TrustStore     │ │
│  │ (DblRatchet) │ │(X25519+ChaCha│ │  (TOFU+WoT)     │ │
│  │              │ │  +ML-KEM)    │ │                 │ │
│  └──────────────┘ └──────────────┘ └─────────────────┘ │
│  ┌──────────────┐ ┌──────────────┐ ┌─────────────────┐ │
│  │ TrafficArmor │ │MailboxStore  │ │ DisasterManager │ │
│  │(Pad+Cover)   │ │(Offline dlvr)│ │ (Fallback chain)│ │
│  └──────────────┘ └──────────────┘ └─────────────────┘ │
│  ┌──────────────┐ ┌──────────────┐ ┌─────────────────┐ │
│  │EncryptedStore│ │ Private Rting│ │ ShamirRecovery  │ │
│  │(Argon2+sled) │ │ (Onion hops) │ │ (M-of-N shares) │ │
│  └──────────────┘ └──────────────┘ └─────────────────┘ │
├─────────────────────────────────────────────────────────┤
│  Transport layer                                        │
│  libp2p mesh  │ StealthTCP │ obfs4(alpha) │ Bluetooth   │
│  (Kad+Gossip) │ (HMAC HS)  │             │ (stub)      │
│               │            │             │             │
│  mDNS local   │            │             │ QR AirGap   │
│  (LAN fallbk) │            │             │ LoRa(future)│
└─────────────────────────────────────────────────────────┘
```

---

## IDENTITY MANIFESTO (from Michael)

Ghostwire is built on Ubuntu: *I am because we are.*
Privacy is not individualism — it is the foundation of community.
A person should be able to speak freely, organise freely, and connect freely
without being monitored, monetised, or manipulated.

The cypherpunk lineage (Zimmermann, Assange, Snowden) showed us what happens
when communications are naked to power. Ghostwire is the answer for those
who cannot afford to be naked.

Build it right. Build it for the people it will protect most.

---

## CONTACT

- GitHub: phantomojo
- Project: Ghostwire / Indra's Net vision
- Role: Head of Security, RVC
- Stack: Rust + libp2p + React + Tauri
