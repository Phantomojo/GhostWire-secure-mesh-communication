//! mesh_health.rs — Live mesh health dashboard data
//!
//! Aggregates data from:
//!   - NetworkMonitor (latency, packet loss, reachability) — already exists
//!   - MeshManager (peer count, topology) — already exists
//!   - DisasterManager (network state, fallback chain) — Wave 2
//!   - PeerAddressCache (connection quality) — Wave 4
//!   - EncryptedStore / BlockStore stats — Wave 2/3
//!
//! Exposes:
//!   GET /api/v2/system/mesh-health   — full snapshot
//!   WS  /api/ws                      — real-time via CoreEvent stream
//!
//! The frontend uses this to render a force-directed network graph
//! showing live node positions, edge weights as connection quality,
//! and latency heatmaps.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Complete mesh health snapshot — returned by the API endpoint
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MeshHealthSnapshot {
    pub timestamp: u64,
    pub network_state: NetworkStateInfo,
    pub peers: Vec<PeerHealthInfo>,
    pub routing: RoutingHealthInfo,
    pub storage: StorageHealthInfo,
    pub security: SecurityHealthInfo,
    pub performance: PerformanceInfo,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NetworkStateInfo {
    /// "full_mesh" | "local_only" | "bluetooth_only" | "air_gap"
    pub state: String,
    pub internet_reachable: bool,
    pub lan_reachable: bool,
    pub active_transport: String,
    pub uptime_secs: u64,
    pub bootstrap_nodes_reachable: u32,
    pub latency_ms: u32,
    pub packet_loss_pct: f32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PeerHealthInfo {
    pub node_id: String,
    pub nickname: Option<String>,
    pub connection_state: String,
    pub is_online: bool,
    pub latency_ms: Option<u32>,
    pub signal_strength: f32,
    pub last_seen_secs_ago: u64,
    pub messages_exchanged: u64,
    pub trust_level: String,
    pub discovery_method: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoutingHealthInfo {
    pub routing_table_size: usize,
    pub subnet_distribution: HashMap<String, usize>,
    pub active_routes: usize,
    pub sphinx_sessions: usize,
    pub messages_routed_total: u64,
    pub mixing_queue_depth: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StorageHealthInfo {
    pub message_count: u64,
    pub ark_entry_count: usize,
    pub ark_collection_count: usize,
    pub block_store_count: usize,
    pub mailbox_pending: usize,
    pub encrypted_store_namespaces: usize,
    pub db_size_bytes: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityHealthInfo {
    pub failed_unlock_attempts_24h: u32,
    pub blocked_peers: u32,
    pub sybil_rejections_24h: u32,
    pub audit_events_24h: u32,
    pub identity_locked: bool,
    pub trust_score_avg: f32,
    pub last_key_rotation_days_ago: Option<u32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PerformanceInfo {
    pub messages_per_minute: f32,
    pub avg_message_latency_ms: u32,
    pub session_cache_hit_rate: f32,
    pub dedup_cache_size: usize,
    pub peer_cache_size: usize,
    pub ws_subscriber_count: usize,
    pub event_bus_overflow_count: u64,
}

/// Build a MeshHealthSnapshot from all available Core subsystems.
/// Called by the /v2/system/mesh-health endpoint.
pub async fn build_snapshot(
    core: &crate::core::Core,
    ws_subscriber_count: usize,
) -> MeshHealthSnapshot {
    let now = now_secs();

    // Network state from NetworkMonitor
    let metrics = core.monitor.get_metrics().await;
    let network_state = NetworkStateInfo {
        state: "full_mesh".to_string(), // Wire: core.disaster_mgr.current_state()
        internet_reachable: metrics.is_internet_reachable,
        lan_reachable: local_ip_address::local_ip().is_ok(),
        active_transport: "stealth_tcp".to_string(), // Wire from config
        uptime_secs: 0, // Wire: startup timestamp
        bootstrap_nodes_reachable: 0, // Wire: check default bootstraps
        latency_ms: metrics.latency_ms,
        packet_loss_pct: metrics.packet_loss_ratio * 100.0,
    };

    // Peer info from social graph
    let peer_count = core.get_peer_count();
    let peers = vec![]; // Wire: core.social_graph.list_peers(PeerFilter::All).await

    // Routing health
    let routing = RoutingHealthInfo {
        routing_table_size: peer_count,
        subnet_distribution: HashMap::new(), // Wire: core.routing_table.subnet_distribution()
        active_routes: 0,
        sphinx_sessions: 0,
        messages_routed_total: 0,
        mixing_queue_depth: 0,
    };

    // Storage health
    let storage = StorageHealthInfo {
        message_count: 0, // Wire: core.message_store.count()
        ark_entry_count: 0, // Wire: core.knowledge_ark.stats().await.total_entries
        ark_collection_count: 0,
        block_store_count: 0, // Wire: core.block_store.block_count().await
        mailbox_pending: 0, // Wire: core.mailbox_store.get_pending()?.len()
        encrypted_store_namespaces: 0,
        db_size_bytes: 0,
    };

    // Security health
    let security = SecurityHealthInfo {
        failed_unlock_attempts_24h: 0, // Wire: audit_logger recent events
        blocked_peers: 0, // Wire: trust_store blocked count
        sybil_rejections_24h: 0,
        audit_events_24h: 0,
        identity_locked: core.is_locked().await,
        trust_score_avg: 0.0,
        last_key_rotation_days_ago: None,
    };

    // Performance metrics
    let performance = PerformanceInfo {
        messages_per_minute: 0.0,
        avg_message_latency_ms: metrics.latency_ms,
        session_cache_hit_rate: 0.0,
        dedup_cache_size: 0, // Wire: core.message_dedup.len()
        peer_cache_size: 0, // Wire: core.peer_cache.len()
        ws_subscriber_count,
        event_bus_overflow_count: 0,
    };

    MeshHealthSnapshot {
        timestamp: now,
        network_state,
        peers,
        routing,
        storage,
        security,
        performance,
    }
}

fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

// ── Frontend D3.js integration notes ─────────────────────────────────────────
//
// The WebUI MeshVisualizer.tsx should consume this data.
// Current MeshVisualizer.tsx uses mock data — wire it to this endpoint.
//
// Recommended approach:
//
// 1. On mount: fetch GET /api/v2/system/mesh-health → initial snapshot
// 2. Subscribe to WS /api/ws for real-time updates
//    Listen for: { type: "core_event", payload: { "NetworkUpdate": { active_peers, latency_ms } } }
// 3. D3.js force simulation:
//    - Nodes = peers, center node = us
//    - Edge weight = signal_strength (thicker = better)
//    - Node color = trust_level (verified=teal, trusted=blue, unknown=gray)
//    - Node size = messages_exchanged (more active = bigger)
//    - Blinking animation = is_online
//
// WebSocket event for topology changes:
// The existing CoreEvent::PeerConnected / PeerDisconnected already flow
// through the WS handler — the frontend just needs to update the D3 graph.
//
// Refresh cadence:
//   - Full snapshot: every 30 seconds (poll)
//   - Incremental updates: real-time via WS events
