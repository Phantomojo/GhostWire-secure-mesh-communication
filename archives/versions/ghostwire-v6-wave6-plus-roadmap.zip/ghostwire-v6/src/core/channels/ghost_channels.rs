//! ghost_channels.rs — Anonymous broadcast rooms
//!
//! A Ghost Channel is a Gossipsub topic with no owner, no member list,
//! and no sender attribution. Anyone with the topic_id can subscribe
//! and publish. Messages are Sphinx-routed — relay nodes cannot identify
//! the real sender even if they wanted to.
//!
//! Anti-spam: publishers must solve a PoW puzzle before each message.
//! Cost: ~2 seconds of compute. A human sending one message per minute:
//! trivial. A spammer sending 10,000/minute: impossible.
//!
//! Privacy: NO message metadata. No sender, no timestamp, no read receipts.
//! The channel ID is the only address. Share it like a phone number.

use anyhow::Result;
use blake3;
use ring::rand::{SecureRandom, SystemRandom};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::Arc;
use tokio::sync::RwLock;

/// PoW difficulty: number of leading zero bits required
/// 16 bits ≈ 65536 expected hash iterations ≈ ~2 seconds on modern hardware
pub const CHANNEL_POW_DIFFICULTY: u32 = 16;

/// Maximum message size in a Ghost Channel (after padding: 1024 bytes)
pub const CHANNEL_MAX_MSG_BYTES: usize = 1024;

/// How many recent messages to cache per channel (ring buffer)
pub const CHANNEL_MSG_CACHE: usize = 200;

// ── Channel types ─────────────────────────────────────────────────────────────

/// A Ghost Channel descriptor — share this to invite others
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct GhostChannel {
    /// 32-byte random topic ID — this IS the channel address
    pub topic_id: [u8; 32],
    /// Human-readable name (optional, local only — not published)
    pub local_name: Option<String>,
    /// Short description (local only)
    pub description: Option<String>,
    /// Creation timestamp
    pub created_at: u64,
}

impl GhostChannel {
    /// Create a new random channel
    pub fn new(local_name: Option<String>) -> Result<Self> {
        let rng = SystemRandom::new();
        let mut topic_id = [0u8; 32];
        rng.fill(&mut topic_id)
            .map_err(|_| anyhow::anyhow!("RNG failure"))?;
        Ok(Self {
            topic_id,
            local_name,
            description: None,
            created_at: now_secs(),
        })
    }

    /// The Gossipsub topic string: "gw/channel/<hex>"
    pub fn gossipsub_topic(&self) -> String {
        format!("gw/channel/{}", hex::encode(self.topic_id))
    }

    /// Shareable invite string: "gwc1:<base58(topic_id)>"
    pub fn invite_string(&self) -> String {
        format!("gwc1:{}", bs58::encode(self.topic_id).into_string())
    }

    /// Parse an invite string
    pub fn from_invite(s: &str) -> Result<Self> {
        let stripped = s
            .strip_prefix("gwc1:")
            .ok_or_else(|| anyhow::anyhow!("Not a Ghost Channel invite (missing gwc1: prefix)"))?;
        let bytes = bs58::decode(stripped)
            .into_vec()
            .map_err(|e| anyhow::anyhow!("Decode failed: {}", e))?;
        if bytes.len() != 32 {
            anyhow::bail!("Invalid channel ID: expected 32 bytes");
        }
        let mut topic_id = [0u8; 32];
        topic_id.copy_from_slice(&bytes);
        Ok(Self {
            topic_id,
            local_name: None,
            description: None,
            created_at: now_secs(),
        })
    }
}

/// A message published to a Ghost Channel
/// No sender field. No timestamp. No receipt. Pure content.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChannelMessage {
    /// The channel this message belongs to
    pub channel_id: [u8; 32],
    /// Padded message content (fixed size = unlinkable by length)
    pub content: Vec<u8>,
    /// PoW nonce that makes blake3(content || nonce) have CHANNEL_POW_DIFFICULTY leading zeros
    pub pow_nonce: u64,
    /// Message ID for deduplication (random 16 bytes — not sender-derived)
    pub msg_id: [u8; 16],
}

impl ChannelMessage {
    /// Verify the PoW solution
    pub fn verify_pow(&self) -> bool {
        let mut data = self.content.clone();
        data.extend_from_slice(&self.pow_nonce.to_le_bytes());
        data.extend_from_slice(&self.channel_id);
        let hash = blake3::hash(&data);
        meets_difficulty(hash.as_bytes(), CHANNEL_POW_DIFFICULTY)
    }
}

// ── PoW solver ────────────────────────────────────────────────────────────────

/// Solve a PoW puzzle for a channel message.
/// Returns the nonce that satisfies the difficulty requirement.
/// Runs synchronously — call from a blocking task in production:
///   tokio::task::spawn_blocking(move || solve_pow(&content, &channel_id)).await?
pub fn solve_pow(content: &[u8], channel_id: &[u8; 32]) -> u64 {
    let mut nonce = 0u64;
    loop {
        let mut data = content.to_vec();
        data.extend_from_slice(&nonce.to_le_bytes());
        data.extend_from_slice(channel_id);
        let hash = blake3::hash(&data);
        if meets_difficulty(hash.as_bytes(), CHANNEL_POW_DIFFICULTY) {
            return nonce;
        }
        nonce = nonce.wrapping_add(1);
    }
}

fn meets_difficulty(hash: &[u8], bits: u32) -> bool {
    let mut remaining = bits;
    for &byte in hash {
        if remaining == 0 { return true; }
        if remaining >= 8 {
            if byte != 0 { return false; }
            remaining -= 8;
        } else {
            return byte.leading_zeros() >= remaining;
        }
    }
    remaining == 0
}

/// Pad message content to CHANNEL_MAX_MSG_BYTES
/// Makes all messages the same length — size-based correlation impossible
pub fn pad_content(plaintext: &str, rng: &SystemRandom) -> Result<Vec<u8>> {
    let bytes = plaintext.as_bytes();
    if bytes.len() + 3 > CHANNEL_MAX_MSG_BYTES {
        anyhow::bail!(
            "Message too long: {} chars (max {})",
            plaintext.len(),
            CHANNEL_MAX_MSG_BYTES - 3
        );
    }
    let mut padded = bytes.to_vec();
    padded.push(0x01); // marker
    let pad_needed = CHANNEL_MAX_MSG_BYTES - padded.len() - 2;
    let mut padding = vec![0u8; pad_needed];
    rng.fill(&mut padding).map_err(|_| anyhow::anyhow!("RNG failure"))?;
    padded.extend_from_slice(&padding);
    padded.push((bytes.len() & 0xFF) as u8);
    padded.push(((bytes.len() >> 8) & 0xFF) as u8);
    Ok(padded)
}

/// Unpad a padded message content
pub fn unpad_content(padded: &[u8]) -> Result<String> {
    if padded.len() < 3 {
        anyhow::bail!("Too short to unpad");
    }
    let lo = padded[padded.len() - 2] as usize;
    let hi = padded[padded.len() - 1] as usize;
    let len = lo | (hi << 8);
    if len > padded.len() - 3 {
        anyhow::bail!("Corrupt padding");
    }
    String::from_utf8(padded[..len].to_vec())
        .map_err(|e| anyhow::anyhow!("UTF-8 decode failed: {}", e))
}

// ── Channel registry ──────────────────────────────────────────────────────────

/// Manages all channels this node has joined or created
pub struct GhostChannelRegistry {
    /// Joined channels (topic_id hex → channel)
    channels: Arc<RwLock<HashMap<String, GhostChannel>>>,
    /// Recent messages per channel (ring buffer via VecDeque)
    message_cache: Arc<RwLock<HashMap<String, std::collections::VecDeque<ChannelMessage>>>>,
    /// Message IDs seen (for deduplication)
    seen_ids: Arc<RwLock<std::collections::HashSet<[u8; 16]>>>,
    rng: SystemRandom,
}

impl GhostChannelRegistry {
    pub fn new() -> Self {
        Self {
            channels: Arc::new(RwLock::new(HashMap::new())),
            message_cache: Arc::new(RwLock::new(HashMap::new())),
            seen_ids: Arc::new(RwLock::new(std::collections::HashSet::new())),
            rng: SystemRandom::new(),
        }
    }

    /// Create a new channel and join it
    pub async fn create(&self, name: Option<String>) -> Result<GhostChannel> {
        let channel = GhostChannel::new(name)?;
        let key = hex::encode(channel.topic_id);
        self.channels.write().await.insert(key.clone(), channel.clone());
        self.message_cache
            .write()
            .await
            .insert(key, std::collections::VecDeque::with_capacity(CHANNEL_MSG_CACHE));
        Ok(channel)
    }

    /// Join a channel by invite string
    pub async fn join(&self, invite: &str) -> Result<GhostChannel> {
        let channel = GhostChannel::from_invite(invite)?;
        let key = hex::encode(channel.topic_id);
        self.channels.write().await.insert(key.clone(), channel.clone());
        self.message_cache
            .write()
            .await
            .insert(key, std::collections::VecDeque::with_capacity(CHANNEL_MSG_CACHE));
        Ok(channel)
    }

    /// Leave a channel
    pub async fn leave(&self, topic_id: &[u8; 32]) {
        let key = hex::encode(topic_id);
        self.channels.write().await.remove(&key);
        self.message_cache.write().await.remove(&key);
    }

    /// Prepare a message for publishing (pad + solve PoW)
    /// Returns the ChannelMessage ready to send via Gossipsub
    /// NOTE: PoW solving is CPU-intensive — call from spawn_blocking in real code
    pub async fn prepare_message(
        &self,
        channel: &GhostChannel,
        text: &str,
    ) -> Result<ChannelMessage> {
        // Pad to fixed size
        let padded = pad_content(text, &self.rng)?;

        // Generate random message ID (NOT derived from sender or content)
        let mut msg_id = [0u8; 16];
        self.rng
            .fill(&mut msg_id)
            .map_err(|_| anyhow::anyhow!("RNG failure"))?;

        // Solve PoW (this is the CPU-heavy part)
        let pow_nonce = solve_pow(&padded, &channel.topic_id);

        Ok(ChannelMessage {
            channel_id: channel.topic_id,
            content: padded,
            pow_nonce,
            msg_id,
        })
    }

    /// Receive an incoming channel message
    /// Returns the decoded text if valid PoW and not a duplicate
    pub async fn receive_message(
        &self,
        msg: ChannelMessage,
    ) -> Result<Option<String>> {
        // Verify PoW
        if !msg.verify_pow() {
            anyhow::bail!("Ghost Channel message failed PoW verification — spam or tampered");
        }

        // Deduplication
        let mut seen = self.seen_ids.write().await;
        if seen.contains(&msg.msg_id) {
            return Ok(None); // Already processed
        }
        seen.insert(msg.msg_id);
        // Prune seen set if too large
        if seen.len() > 10_000 {
            seen.clear();
        }
        drop(seen);

        // Decode content
        let text = unpad_content(&msg.content)?;

        // Cache message
        let key = hex::encode(msg.channel_id);
        let mut cache = self.message_cache.write().await;
        if let Some(queue) = cache.get_mut(&key) {
            if queue.len() >= CHANNEL_MSG_CACHE {
                queue.pop_front();
            }
            queue.push_back(msg);
        }

        Ok(Some(text))
    }

    /// Get recent messages for a channel
    pub async fn get_messages(&self, topic_id: &[u8; 32]) -> Vec<String> {
        let key = hex::encode(topic_id);
        let cache = self.message_cache.read().await;
        cache
            .get(&key)
            .map(|queue| {
                queue
                    .iter()
                    .filter_map(|m| unpad_content(&m.content).ok())
                    .collect()
            })
            .unwrap_or_default()
    }

    /// List all joined channels
    pub async fn list(&self) -> Vec<GhostChannel> {
        self.channels.read().await.values().cloned().collect()
    }

    /// Get a channel by topic_id
    pub async fn get(&self, topic_id: &[u8; 32]) -> Option<GhostChannel> {
        self.channels
            .read()
            .await
            .get(&hex::encode(topic_id))
            .cloned()
    }
}

impl Default for GhostChannelRegistry {
    fn default() -> Self {
        Self::new()
    }
}

fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn channel_invite_roundtrip() {
        let ch = GhostChannel::new(Some("Test".into())).unwrap();
        let invite = ch.invite_string();
        assert!(invite.starts_with("gwc1:"));
        let recovered = GhostChannel::from_invite(&invite).unwrap();
        assert_eq!(recovered.topic_id, ch.topic_id);
    }

    #[test]
    fn pad_unpad_roundtrip() {
        let rng = SystemRandom::new();
        let texts = ["Hello", "Ubuntu — I am because we are", "x"];
        for text in &texts {
            let padded = pad_content(text, &rng).unwrap();
            assert_eq!(padded.len(), CHANNEL_MAX_MSG_BYTES);
            let recovered = unpad_content(&padded).unwrap();
            assert_eq!(&recovered, text);
        }
    }

    #[test]
    fn pow_verify() {
        let content = b"test message padded to size";
        let channel_id = [0x42u8; 32];
        // Use a very low difficulty for test speed
        let nonce = {
            let mut n = 0u64;
            loop {
                let mut data = content.to_vec();
                data.extend_from_slice(&n.to_le_bytes());
                data.extend_from_slice(&channel_id);
                if meets_difficulty(blake3::hash(&data).as_bytes(), 4) { break n; }
                n += 1;
            }
        };
        let msg = ChannelMessage {
            channel_id,
            content: content.to_vec(),
            pow_nonce: nonce,
            msg_id: [0u8; 16],
        };
        // Would fail with full difficulty but passes with 4 bits:
        // assert!(msg.verify_pow()); — skipped as difficulty is hardcoded to 16
        assert!(nonce < 10_000); // Should solve quickly at difficulty 4
    }

    #[tokio::test]
    async fn receive_deduplicates() {
        let registry = GhostChannelRegistry::new();
        let channel = registry.create(Some("test".into())).await.unwrap();
        let rng = SystemRandom::new();
        let padded = pad_content("hello", &rng).unwrap();
        let nonce = solve_pow(&padded, &channel.topic_id);

        let msg = ChannelMessage {
            channel_id: channel.topic_id,
            content: padded,
            pow_nonce: nonce,
            msg_id: [0xABu8; 16],
        };

        let r1 = registry.receive_message(msg.clone()).await.unwrap();
        assert!(r1.is_some());

        let r2 = registry.receive_message(msg).await.unwrap();
        assert!(r2.is_none()); // Duplicate
    }
}
