# GHOSTWIRE — WAVES 7–10 STRATEGIC ROADMAP
# The path from working prototype to production-grade sovereign network

---

## THE PROGRESSION LOGIC

Waves 1–6 build the core. Waves 7–10 make it unstoppable.

Wave 7: **Transport sovereignty** — no infrastructure dependency
Wave 8: **Platform reach** — every device is a node
Wave 9: **Network effects** — the mesh grows itself
Wave 10: **The Ark** — knowledge infrastructure for the next century

---

## WAVE 7 — TRANSPORT SOVEREIGNTY
**Theme: Run anywhere. Need nothing. Own everything.**

The vision: a Ghostwire node should operate with ZERO dependency on
any infrastructure you don't control. No bootstrap servers, no DNS,
no CDN, no cloud. The mesh bootstraps itself from the physical world.

### 7.1 — obfs4 Completion (CRITICAL)
**Current state:** Alpha stub, non-functional, no DPI evasion
**What to build:**
- Integrate actual obfs4 scrambling via the `obfs4` crate
- If the crate remains too alpha: implement a custom Elligator2
  encoding (the core mechanism of obfs4) using the existing x25519-dalek
- Wire into PluggableTransport as `TransportMode::Obfs4`
- Add PT bridge directory: nodes can publish themselves as PT bridges
  in the DHT so others can find them without a central bridge list
**Why now:** Safaricom's deep-packet inspection is getting more aggressive.
Users in Kenya need this. It was promised in Wave 1 and never delivered.

### 7.2 — LoRa Bridge (HIGH VALUE, UNIQUE)
**Current state:** `serialport` in Cargo.toml, not started
**What to build:**
- A bridge process (`ghostwire-lora-bridge`) that:
  1. Connects to a LoRa radio (LILYGO T-Beam, RAK WisBlock) via serial
  2. Translates Ghostwire mesh packets to LoRa frames
  3. Bridges messages between IP mesh and LoRa mesh
- LoRa frame format: stripped-down MessagePack, max 250 bytes
  (LoRa physical limit)
- Chunking: large messages split into numbered LoRa frames,
  reassembled at destination (uses BlockStore CID addressing)
- Range: 10–40 km line-of-sight, works without any internet
**Why:** Rural Kenya, disaster scenarios, protests where cell towers
are shut down. No other privacy messenger has this.

### 7.3 — Bluetooth LE Transport (MEDIUM)
**Current state:** btleplug in Cargo.toml, stub only
**What to build:**
- Peer discovery via BLE advertising (broadcast DID truncated to 6 bytes
  in the manufacturer data field — enough to identify Ghostwire nodes)
- Connection: BLE GATT server/client for message exchange
- Integrate with DisasterManager fallback chain
- Range: ~10m indoors, fine for same-room air-gap scenarios
**Technical approach:** btleplug async API, custom GATT service UUID
derived from "ghostwire" hash

### 7.4 — Bootstrapless DHT
**Current state:** Uses public bootstrap.libp2p.io nodes — external dependency
**What to build:**
- **mDNS super-bootstrap**: when an internet node and a LAN node are
  on the same network, the LAN node automatically learns internet
  peer addresses via the internet node
- **Persistent peer cache**: save known peer multiaddrs to sled on
  shutdown, load on startup — node reconnects to known peers without
  any bootstrap server
- **Bootstrap node self-hosting**: CLI command to publish yourself
  as a bootstrap node in the DHT with a human-readable subdomain
  (e.g. `ghostwire.yourname.example.com/p2p/<peerid>`)
- **Emergency bootstrap QR**: a QR code containing 5 current
  multiaddrs — scan it and you're in the mesh

### 7.5 — Pluggable Transport Manager UI
**Current state:** Transport mode is a config file option
**What to build:**
- Settings page: switch between Stealth/WebSocket/AEAD/Obfs4 at runtime
- Auto-detection: probe for censorship and auto-upgrade transport
- Visual indicator: transport mode visible in status bar
- Per-peer transport: different transport per peer based on their
  network conditions (auto-detected via latency patterns)

**Cargo.toml additions for Wave 7:**
```toml
# LoRa bridge
serialport = { version = "4.3", optional = true }  # already optional

# Bluetooth (upgrade from stub)
btleplug = { version = "0.11", features = ["tokio"] }
```

---

## WAVE 8 — PLATFORM REACH
**Theme: Every screen is a node.**

### 8.1 — Android Client (HIGHEST IMPACT)
**Approach: Tauri Mobile (NOT React Native)**
Tauri 2.0 supports iOS and Android. The Rust backend compiles to a
native library. The WebUI React frontend runs in a WebView. This means
~80% of the code (all Rust core + all React UI) is shared with desktop.

**What to build:**
- `src-tauri-mobile/` — Tauri mobile configuration
- Android permissions: INTERNET, BLUETOOTH_SCAN, BLUETOOTH_CONNECT,
  ACCESS_WIFI_STATE, FOREGROUND_SERVICE (for background mesh node)
- Background service: Ghostwire node keeps running when app is minimised
  (critical for receiving messages)
- Push notification bridge: when a message arrives and the app is
  backgrounded, show a system notification WITHOUT using Google FCM
  (use local notification via Android AlarmManager)
- QR code scanner: camera access for contact card scanning
- Biometric unlock: fingerprint / face ID via Android Keystore
  (this solves the "Argon2 is slow" UX problem on mobile)
- Platform-native secret storage: Android Keystore for identity key
  (replaces file-based encrypted store on mobile)

**Why Tauri not React Native:**
- Rust core compiles directly — no FFI binding layer
- WebUI already exists and works
- Single codebase for all platforms
- No JavaScript bridge overhead for crypto operations

### 8.2 — iOS Client
Same Tauri Mobile approach as Android.
Additional challenge: Apple Keychain for identity key storage.
Background execution: iOS kills background apps aggressively —
use Background Processing and Silent Push Notifications (without APNs
server: use Ghostwire's own push channel via the mesh).

### 8.3 — Browser Extension
**Use case:** Ghostwire-in-a-tab for users who can't install software.
**Approach:** WebAssembly build of the Rust core
- Compile `ghostwire` with `wasm32-unknown-unknown` target
- Use `wasm-pack` to generate JS bindings
- WebRTC transport only (no raw TCP in browser)
- `wasm_bindgen` for JS ↔ Rust interface
- IndexedDB for storage (replaces sled)
- Service Worker for background operation
**Limitation:** no Bluetooth, no LoRa. Transport is WebRTC only.

### 8.4 — Desktop Tray App (Tauri improvement)
**Current state:** Tauri shell exists but is basic
**What to build:**
- System tray icon with status indicator (green/yellow/red for mesh health)
- Right-click menu: quick send, new channel, lock profile
- Native notifications for messages and connection requests
- Auto-start on login option
- Hotkey to open/close (configurable)

### 8.5 — CLI completion
**Current state:** CLI mode doesn't fully work
**What to build:**
- `ghostwire send <node_id> <message>` — actually send a message
- `ghostwire peers` — list connected peers with status
- `ghostwire channels` — list/join/create Ghost Channels
- `ghostwire ark search <query>` — search knowledge
- `ghostwire pair` — generate pairing code
- `ghostwire status` — full node status
- `ghostwire daemon` — run as background daemon
Interactive TUI (ratatui crate): a proper terminal interface with
panels for peers, messages, and network status.

**Cargo.toml additions for Wave 8:**
```toml
# TUI
ratatui = "0.28"
crossterm = "0.28"

# WASM
[target.'cfg(target_arch = "wasm32")'.dependencies]
wasm-bindgen = "0.2"
web-sys = { version = "0.3", features = ["IdbDatabase", "WebSocket"] }
```

---

## WAVE 9 — NETWORK EFFECTS
**Theme: The mesh grows itself. Trust spreads organically.**

### 9.1 — Verifiable Credential Social Graph
**The problem:** Right now, connections are binary (connected/not).
There's no way to represent "I vouch for this person" or to discover
peers through chains of trust.
**What to build:**
- W3C Verifiable Credentials for social attestations
- `did:ghost:` DID method resolver: publish DID document to DHT
  containing public keys + service endpoints
- VC issuance: "I, `did:ghost:alice`, attest that `did:ghost:bob`
  is a trustworthy node (signed Ed25519)"
- Trust path discovery: find shortest path through the WoT graph
  from us to an unknown peer (6 degrees of separation)
- VC revocation: sign a revocation and publish to DHT
- Cross-network bridge: `did:ghost:` DIDs that can bridge to
  `did:key:`, `did:web:`, `did:ion:` (W3C standard DIDs)
**Technology:** DIF Universal Resolver compatible, Linked Data Proofs

### 9.2 — Federated Knowledge Ark
**The vision:** Public Ark collections replicate across the whole mesh.
The mesh becomes a censorship-resistant Wikipedia.
**What to build:**
- Ark federation protocol: when a node publishes a public collection,
  it announces the collection CID to DHT
- Selective sync: subscribe to specific collections (by CID or by author)
- Conflict resolution: automerge CRDTs for collaborative entries
- Content moderation: community flagging (threshold of flags = hidden
  locally, not deleted globally — you decide what you see)
- Search federation: query propagates to N closest peers, results merged
- Ark pinning: explicit "I want to permanently host this collection"
  — shares BlockStore responsibility

### 9.3 — Relay Incentive System
**The problem:** Why would anyone run a relay node?
**Solution (no blockchain):** Relay credit system
- Nodes earn "relay credits" for each kilobyte they relay for others
- Credits are locally tracked, not globally consensus
- High-credit nodes get priority routing through other relays
- Credits are tied to node ID (not transferable) — no economy to game
- Implementation: simple counter in sled, signed with relay's key
  (prevents forgery), checked by mixing layer before routing
- This is the Bitswap ledger (Wave 3) extended to routing

### 9.4 — Bootstrap Node Incentives
**Currently:** Bootstrap nodes are run by random volunteers with no
incentive to stay online.
**What to build:**
- Node uptime announcements: nodes that stay online announce their
  uptime record to DHT
- Uptime-weighted routing: prefer routing through nodes with long
  uptime records
- Bootstrap node registry: a hardcoded list of community-run bootstrap
  nodes (not controlled by any single entity), updateable via signed
  manifest (Wave 5 secure updater pattern)

### 9.5 — Protocol Bridges
**Purpose:** Connect Ghostwire to other privacy networks
**What to build:**
- **Matrix bridge** (already stubbed): finish MatrixAdapter
  — bridge messages between Ghostwire and Matrix rooms
- **Nostr bridge**: Ghostwire node can post/receive Nostr notes
  — extends reach to the decentralised social web
- **Session bridge**: import/export contacts between Ghostwire and Session
- **Briar bridge** (already stubbed): finish BriarAdapter
  — access Briar's Tor-based network from Ghostwire
**Why bridges matter:** Network effects. Each bridge multiplies
reach. Ubuntu: the more people in the network, the more valuable it is.

---

## WAVE 10 — THE ARK
**Theme: Knowledge infrastructure for the next century.**

This wave is the full realisation of the Indra's Net vision.
Not a feature set. An institution.

### 10.1 — Ark as a First-Class Platform
**The Ghostwire Knowledge Ark should be as important as the messenger.**
**What to build:**
- Rich entry editor: Markdown with LaTeX math, code highlighting,
  embedded media (referenced by BlockStore CID)
- Collaborative real-time editing: two users editing the same entry
  simultaneously — automerge CRDTs merge changes
- Templates: note, article, research log, code snippet, interview record,
  reading list — structured formats that search well
- Ark export: export a collection as a static website, PDF, or ePub
  — your knowledge survives Ghostwire
- Ark import: import from Obsidian, Notion, Roam, markdown files
- Versioned publish: "version 1.0" of an entry — semantically versioned,
  previous versions always accessible by CID

### 10.2 — Research Mode
**The Ark becomes a research platform:**
- Citation graph: entries can reference other entries (by CID)
  — build a local Zotero equivalent
- Reference discovery: "who in my WoT has written about X?"
  — federated search across trusted peers' public collections
- Collaborative annotation: add notes to someone else's public entry
  (stored in your own Ark, linked to theirs by CID)
- Question/Answer: post a Question entry publicly, any peer can
  respond with an Answer — asynchronous, encrypted, searchable
- AI integration (local): optional integration with local LLM
  (Ollama) to summarise, translate, or answer questions about
  your Ark content — runs on your machine, never leaves

### 10.3 — The Ark as a Survival Tool
**Specific to the Global South context:**
- Offline-first medical reference: community health workers can
  store and share treatment protocols that work without internet
- Legal documentation: communities can document incidents, abuses,
  land rights — timestamped, signed, replicated across trusted peers
  — harder to destroy than a single server
- Educational content: textbooks, course materials, tutorials —
  replicated across school networks even when the internet is cut
- Emergency coordination: during network shutdowns, coordinate via
  LoRa mesh + Ark content caching
**This is what makes Ghostwire a human rights tool, not just a product.**

### 10.4 — Governance and Sustainability
**How does Ghostwire survive long-term without a company?**
- Protocol governance: all protocol changes go through a signed
  proposal process published in the DHT — nodes vote by upgrading
- Bootstrap node DAO: community members run bootstrap nodes, tracked
  by uptime and reputation — no central operator
- Ark Commons: a curated set of public Ark collections maintained
  by the community — the Wikipedia of the Ghostwire mesh
- Security bounty: a sled of signed reward pledges from community
  members — find a bug, collect the pledge (no central escrow)
- Translation: the Ghostwire UI and documentation in Swahili,
  French (West Africa), Arabic, Hindi, Portuguese (Brazil) —
  the Global South speaks many languages

### 10.5 — The Audit
Wave 10 ends with a third-party security audit by a reputable firm
(Trail of Bits, Cure53, NCC Group, or similar).
**Scope:** Full cryptographic review of:
- Double Ratchet implementation
- Sphinx packet construction
- Key derivation and storage
- S/Kademlia PoW implementation
- Mixing delay parameters vs. published attacks
**This is the graduation moment.** After the audit, Ghostwire is no
longer a prototype. It is infrastructure.

---

## SUMMARY TABLE

| Wave | Theme | Key deliverables | Estimated effort |
|------|-------|-----------------|-----------------|
| 7 | Transport sovereignty | obfs4, LoRa, Bluetooth, bootstrapless DHT | 6–8 weeks |
| 8 | Platform reach | Android/iOS (Tauri), CLI TUI, browser ext | 8–12 weeks |
| 9 | Network effects | VC social graph, federated Ark, relay incentives, bridges | 8–10 weeks |
| 10 | The Ark | Rich editor, research mode, governance, third-party audit | 12–16 weeks |

---

## WHAT MAKES GHOSTWIRE IRREPLACEABLE AFTER WAVE 10

1. The only privacy messenger with LoRa support — works where there is no internet
2. The only one with Shamir community recovery — your community holds your keys
3. The only one with a built-in knowledge commons — Ubuntu encoded in protocol
4. The only one designed explicitly for the Global South
5. Post-quantum by default since Day 1 (ML-KEM-768)
6. Third-party audited Sphinx implementation
7. W3C DID compatible — bridges to the global decentralised identity ecosystem
8. Open protocol — any developer can build on it

This is not a product competing with Signal or WhatsApp.
This is infrastructure for human dignity, built from a crib in Nairobi.

*"I am because we are."*
