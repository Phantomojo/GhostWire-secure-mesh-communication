import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';
import Toast from './components/shared/Toast';
import Dashboard from './components/panels/Dashboard';
import Channels from './components/panels/Channels';

// Lazy-importable panels (keep bundle lean)
const NetworkPanel    = React.lazy(() => import('./components/panels/Network'));
const CommunicationPanel = React.lazy(() => import('./components/panels/Communication'));
const ArkPanel        = React.lazy(() => import('./components/panels/Ark'));
const SecurityPanel   = React.lazy(() => import('./components/panels/Security'));
const SystemPanel     = React.lazy(() => import('./components/panels/System'));
const SettingsPanel   = React.lazy(() => import('./components/panels/Settings'));
const LoginScreen     = React.lazy(() => import('./components/panels/Login'));

function PanelRouter() {
  const { state } = useApp();
  return (
    <React.Suspense fallback={
      <div style={{
        flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--t3)',
      }}>
        Loading...
      </div>
    }>
      {state.activePanel === 'dashboard'     && <Dashboard />}
      {state.activePanel === 'channels'      && <Channels />}
      {state.activePanel === 'communication' && <CommunicationPanel />}
      {state.activePanel === 'network'       && <NetworkPanel />}
      {state.activePanel === 'ark'           && <ArkPanel />}
      {state.activePanel === 'security'      && <SecurityPanel />}
      {state.activePanel === 'system'        && <SystemPanel />}
      {state.activePanel === 'settings'      && <SettingsPanel />}
    </React.Suspense>
  );
}

function AppShell() {
  const { state } = useApp();

  if (state.isInitializing) {
    return (
      <div style={{
        width: '100vw', height: '100vh',
        background: 'var(--void)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexDirection: 'column', gap: 16,
      }}>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 13, color: 'var(--sig)', letterSpacing: '0.2em' }}>
          GHOSTWIRE
        </div>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--t3)', letterSpacing: '0.15em' }}>
          INITIALISING NODE...
        </div>
        <div style={{
          width: 200, height: 1,
          background: 'linear-gradient(90deg, transparent, var(--sig-dim), transparent)',
          animation: 'sig-pulse 1.5s ease-in-out infinite',
        }} />
      </div>
    );
  }

  if (state.isLocked || !state.identityStatus?.setup_complete) {
    return <LoginScreen />;
  }

  const rootClass = [
    'scanlines',
    state.isEmergencyMode ? 'emergency' : '',
    state.isStealthMode ? 'stealth' : '',
  ].filter(Boolean).join(' ');

  return (
    <div
      className={rootClass}
      style={{
        width: '100vw', height: '100vh',
        display: 'flex', overflow: 'hidden',
        background: 'var(--void)',
      }}
    >
      <Sidebar />

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <Header />
        <main style={{
          flex: 1,
          overflow: state.activePanel === 'communication' || state.activePanel === 'channels'
            ? 'hidden' : 'auto',
          position: 'relative',
        }}>
          <PanelRouter />
        </main>
      </div>

      <Toast />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppShell />
    </AppProvider>
  );
}
