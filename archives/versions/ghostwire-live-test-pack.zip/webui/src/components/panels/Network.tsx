import React from 'react';
import { useApp } from '../../context/AppContext';

export default function NetworkPanel() {
  return (
    <div style={{ padding: 20, fontFamily: 'var(--mono)', color: 'var(--t2)' }} className="animate-in">
      <div style={{ fontSize: 10, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--t3)', marginBottom: 12 }}>
        Network
      </div>
      <div style={{ color: 'var(--t3)', fontSize: 11 }}>
        Panel wiring in progress — API methods in services/api.ts are ready.
      </div>
    </div>
  );
}
