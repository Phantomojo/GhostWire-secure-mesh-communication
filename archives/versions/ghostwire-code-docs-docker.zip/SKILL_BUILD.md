# SKILL_BUILD.md — How to build GhostWire

## Quick Build

```bash
cd ghostwire/
cargo build --release
```

**Binary location:** `target/release/ghostwire` (≈20 MB)

## Expected Output

```
warning: `ghostwire` (lib) generated 64 warnings
Finished `release` profile [optimized] target(s) in 2m 08s
```

**Warnings are normal.** Expected: 60-70 warnings about unused code.

## Build Errors

If you see errors:

1. **Check QWEN_REMAINING_FIXES.md** — known issues and fixes
2. **Check Cargo.toml** — all dependencies present
3. **Clean rebuild:**
   ```bash
   cargo clean && cargo build --release
   ```

## Verify Build

```bash
./target/release/ghostwire --version
./target/release/ghostwire help
```

Expected: Version info and help text.

## Deploy to Node

```bash
# Copy to remote node
scp target/release/ghostwire user@node:~/ghostwire-live-test/

# Start on remote
ssh user@node "cd ~/ghostwire-live-test && ./ghostwire --port 8080 --mesh &"

# Verify
curl http://node:8080/api/v2/profile
```

## Build Time Expectations

- **Clean build:** 5-7 minutes
- **Incremental:** 1-2 minutes
- **With rust-analyzer running:** Add 50%

## Common Issues

| Issue | Fix |
|-------|-----|
| `num_bigint` not found | Run `cargo update` |
| `libc` errors | Ensure `libc = "0.2"` in Cargo.toml |
| WebUI embed errors | Rebuild webui first: `cd webui && npm run build` |

## Next Steps After Build

1. **Test CLI:** See `SKILL_TESTING.md`
2. **Run live test:** See `SKILL_TESTING.md`
3. **Debug issues:** See `SKILL_DEBUG.md`
