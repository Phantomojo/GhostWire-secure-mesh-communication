# SKILL_DEBUG.md — Diagnosing Mesh Failures

## Quick Diagnostics

```bash
# Run full diagnostic
./test-backend-cli.sh
```

## Common Issues

### 1. Backend Not Starting

**Symptoms:**
```
./ghostwire: command not found
# or
Error: Address already in use
```

**Fix:**
```bash
# Check if already running
ps aux | grep ghostwire | grep -v grep

# Kill existing process
pkill -f ghostwire

# Check port
netstat -tlnp | grep 8080

# Start fresh
./ghostwire --port 8080 --mesh &
```

### 2. Peer Discovery Failing

**Symptoms:**
- Peer count stays at 0 after 60 seconds
- mDNS shows no services

**Diagnosis:**
```bash
# Check mDNS
avahi-browse -a -t 2>/dev/null | grep -i ghostwire

# Check network
ip addr show | grep "inet "

# Check firewall
sudo ufw status
```

**Fix:**
```bash
# Manual peer connection
curl -X POST http://localhost:8080/api/v2/peers/connect \
  -H "Content-Type: application/json" \
  -d "{\"peer_id\": \"<PEER_ID>\", \"address\": \"/ip4/<PEER_IP>/tcp/4001\"}"
```

### 3. API Not Responding

**Symptoms:**
```
curl: (7) Failed to connect to localhost port 8080
```

**Diagnosis:**
```bash
# Check process
ps aux | grep ghostwire

# Check port
netstat -tlnp | grep 8080

# Check logs
tail -50 /tmp/ghostwire-*.log
```

**Fix:**
```bash
# Restart backend
pkill -f ghostwire
cd ~/ghostwire-live-test
./ghostwire --port 8080 --mesh &

# Wait 5 seconds
sleep 5

# Verify
curl http://localhost:8080/api/v2/profile
```

### 4. Messages Not Delivered

**Symptoms:**
- Send returns success
- Recipient never receives

**Diagnosis:**
```bash
# Check sender logs
tail -50 /tmp/ghostwire-omen.log | grep -i message

# Check recipient logs
ssh peer "tail -50 /tmp/ghostwire.log | grep -i message"

# Check WebSocket
# Browser: F12 → Network → WS → Messages
```

**Fix:**
```bash
# Verify peer connection
curl "http://localhost:8080/api/v2/peers?page=1&per_page=20" | jq '.data[] | {id, status}'

# Check encryption keys
curl http://localhost:8080/api/v2/profile | jq '.data.public_key'
```

### 5. WebSocket Not Connecting

**Symptoms:**
- TUI shows "Disconnected"
- No live events

**Diagnosis:**
```bash
# Check WebSocket endpoint
curl -i -N -H "Connection: Upgrade" -H "Upgrade: websocket" \
  -H "Sec-WebSocket-Key: SGVsbG8sIHdvcmxkIQ==" \
  -H "Sec-WebSocket-Version: 13" \
  http://localhost:8080/api/ws
```

**Expected:** `HTTP/1.1 101 Switching Protocols`

**Fix:**
```bash
# Check backend logs for WebSocket errors
tail -50 /tmp/ghostwire-*.log | grep -i websocket

# Restart backend
pkill -f ghostwire && ./ghostwire --port 8080 --mesh &
```

### 6. High CPU/Memory Usage

**Symptoms:**
- CPU > 50% sustained
- Memory > 500 MB

**Diagnosis:**
```bash
# Check process stats
ps aux | grep ghostwire

# Check mesh size
curl "http://localhost:8080/api/v2/peers?page=1&per_page=20" | jq '.data | length'

# Check message queue
curl http://localhost:8080/api/v2/system/mesh-health | jq '.queue_depth'
```

**Fix:**
```bash
# Reduce mesh size
# Edit ghostwire.toml: max_peers = 50

# Clear message cache
curl -X POST http://localhost:8080/api/v2/messages/clear

# Restart with profiling
RUST_LOG=debug ./ghostwire --port 8080 --mesh &
```

## Log Locations

| Node | Log File |
|------|----------|
| omen | `/tmp/ghostwire-omen.log` |
| stratsytem | `/tmp/ghostwire-strat.log` |
| dragonfly-1 | `/tmp/ghostwire.log` |

## Useful Commands

```bash
# Watch peer count
watch -n 2 "curl -s 'http://localhost:8080/api/v2/peers?page=1&per_page=20' | jq '.data | length'"

# Watch for errors
tail -f /tmp/ghostwire-*.log | grep -i error

# Check node identity
curl -s http://localhost:8080/api/v2/profile | jq '.data | {id, nickname, did}'

# Test all endpoints
for endpoint in "/api/v2/profile" "/api/v2/peers?page=1&per_page=20" "/api/v2/system/mesh-health"; do
  echo -n "$endpoint: "
  curl -s -o /dev/null -w "%{http_code}" "http://localhost:8080$endpoint"
  echo
done
```

## When All Else Fails

```bash
# Full reset
pkill -f ghostwire
rm -rf ~/.ghostwire/*.lock
sleep 2

# Start with debug logging
RUST_LOG=ghostwire=debug ./ghostwire --port 8080 --mesh &

# Watch for startup errors
tail -f /tmp/ghostwire-*.log
```

## Getting Help

1. Check logs first
2. Run `test-backend-cli.sh`
3. Check known issues in `QWEN_REMAINING_FIXES.md`
4. Provide: logs, node IDs, error messages
