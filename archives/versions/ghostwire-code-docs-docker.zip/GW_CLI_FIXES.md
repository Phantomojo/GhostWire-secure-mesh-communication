# 🐛 GW-CLI BUILD ERRORS — ACTION PLAN

**Generated:** March 18, 2026  
**Source:** `cargo check` on gw-cli extracted from dragonfly-1

---

## 📊 ERROR SUMMARY

**Total Errors:** 15  
**Warnings:** 1 (unused variable)

### **Error Types:**

| Type | Count | Meaning |
|------|-------|---------|
| `Serialize` trait missing | 10 | Backend structs don't implement Serialize |
| `mismatched types` | 4 | API response shapes don't match |
| `self` parameter error | 1 | Syntax error in method |

---

## 🔍 DETAILED ERRORS

### **1. Serialize Trait Missing (10 errors)**

The CLI expects these structs to be serializable, but they're not:

```
error[E0277]: the trait bound `NodeStatus: serde::Serialize` is not satisfied
error[E0277]: the trait bound `IdentityStatus: serde::Serialize` is not satisfied
error[E0277]: the trait bound `MeshHealth: serde::Serialize` is not satisfied
error[E0277]: the trait bound `Peer: serde::Serialize` is not satisfied
error[E0277]: the trait bound `Profile: serde::Serialize` is not satisfied
error[E0277]: the trait bound `Channel: serde::Serialize` is not satisfied
error[E0277]: the trait bound `ArkSearchResult: serde::Serialize` is not satisfied
error[E0277]: the trait bound `SecurityDashboard: serde::Serialize` is not satisfied
```

**FIX:** Add `#[derive(Serialize)]` to these structs in backend:
- `NodeStatus` — in `api_v2_types.rs` or `system.rs`
- `IdentityStatus` — in `identity/mod.rs`
- `MeshHealth` / `MeshHealthV2` — in `mesh_health.rs`
- `Peer` — in `reputation.rs` or `mesh.rs`
- `Profile` — in `profiles.rs` or `identity.rs`
- `Channel` — in `ghost_channels.rs`
- `ArkSearchResult` — in `knowledge_ark.rs`
- `SecurityDashboard` — in `security_v2.rs`

---

### **2. Mismatched Types (4 errors)**

```
error[E0308]: mismatched types
```

**Likely causes:**
- API returns `Option<T>` but CLI expects `T`
- Field names don't match between backend and CLI
- Array vs Vec mismatch

**FIX:** Compare CLI `api.rs` definitions with backend response types.

---

### **3. Self Parameter Error (1 error)**

```
error: `self` parameter is only allowed in associated functions
```

**Location:** Likely in `commands.rs` or `api.rs`

**FIX:** Remove `self` from non-method function.

---

## 🎯 PRIORITY FIXES (In Order)

### **Critical (Blocks CLI Build)**

1. **Add Serialize derives to backend structs**
   - File: `ghostwire/src/core/api_v2_types.rs` (or wherever structs are)
   - Add: `#[derive(Serialize, Deserialize)]` to all response types

2. **Fix type mismatches**
   - Compare `gw-cli/src/api.rs` with backend response types
   - Ensure field names and types match exactly

3. **Fix self parameter**
   - Find and remove erroneous `self` keyword

---

## 📋 QUICK FIX SCRIPT

Run this on backend to add Serialize derives:

```bash
# Find and fix structs in ghostwire/src/core/
grep -r "pub struct NodeStatus" src/
grep -r "pub struct IdentityStatus" src/
grep -r "pub struct MeshHealth" src/
grep -r "pub struct Peer" src/
grep -r "pub struct Profile" src/
grep -r "pub struct Channel" src/
grep -r "pub struct ArkSearchResult" src/
grep -r "pub struct SecurityDashboard" src/

# Add #[derive(Serialize)] above each struct
```

---

## 🎯 EXPECTED OUTCOME AFTER FIXES

**CLI Commands That Will Work:**

```bash
gw identity show      # ✅ NodeStatus, IdentityStatus
gw net health         # ✅ MeshHealth
gw peers              # ✅ Peer
gw security status    # ✅ SecurityDashboard
gw channels list      # ✅ Channel
gw ark search         # ✅ ArkSearchResult
```

---

## 📝 LESSON

The CLI was built with **correct API client code** but the backend structs are missing:
1. Serialize derives (for JSON responses)
2. Consistent field names
3. Proper type definitions

**This is easier than expected!** Just need to add derives and ensure type consistency.

---

## 🚀 NEXT STEPS

1. **Find all struct definitions** in backend
2. **Add Serialize/Deserialize derives**
3. **Rebuild CLI**
4. **Test with `gw --help`**
5. **Test with `gw identity show`**

**Estimated time:** 30-45 minutes

---

**Bottom line:** The CLI code is correct. The backend just needs to export the right types with Serialize traits. This is a quick fix!
