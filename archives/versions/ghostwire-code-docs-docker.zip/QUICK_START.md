# 🎯 GHOSTWIRE LIVE TEST — QUICK START

## ✅ SETUP STATUS: **READY**

---

## 🖥️ MACHINE SETUP

### **PC-A (omen)**
- **Tailscale IP:** `100.88.234.14`
- **Binary:** `/home/ph/ghostwire-live-test/ghostwire` (20 MB)
- **Start Script:** `/home/ph/ghostwire-live-test/start-pc-a.sh`
- **Web UI:** `http://localhost:8080`
- **Mesh Port:** `4001`

### **PC-B (stratsytem)**
- **Tailscale IP:** `100.105.58.61`
- **Binary:** `~/ghostwire-live-test/ghostwire` (20 MB)
- **Start Script:** `~/ghostwire-live-test/start-pc-b.sh`
- **Web UI:** `http://localhost:8080`
- **Mesh Port:** `4001`

---

## 🚀 START PROCEDURE

### **Step 1: Start PC-A (omen)**
```bash
# On omen (you're already here)
/home/ph/ghostwire-live-test/start-pc-a.sh
```

**Watch for:**
```
🔑 Identity UNLOCKED
🚀 GhostWire API server starting on http://0.0.0.0:8080
📡 Mesh network initialized on port 4001
```

**Note the Node ID** from terminal (e.g., `id_abc123`)

---

### **Step 2: Start PC-B (stratsytem)**
```bash
# From omen, SSH to stratsytem
ssh stratsytem
# Then run:
~/ghostwire-live-test/start-pc-b.sh
```

**Watch for:** Same output as PC-A

**Note the Node ID**

---

### **Step 3: Open Web UIs**

**PC-A Browser:** `http://localhost:8080`
**PC-B Browser:** `http://localhost:8080` (via SSH tunnel or direct)

---

### **Step 4: Create Profiles**

**On BOTH browsers:**
1. Login screen appears
2. Enter nickname: "PC-A" or "PC-B"
3. Click "Create Profile"
4. Dashboard loads

---

### **Step 5: Verify Peer Discovery**

**Wait 10-30 seconds**

**Check Dashboard on BOTH:**
- Peer count: **1**
- Trust level: **First Contact**
- Status: **Online** (green dot)

---

### **Step 6: Test Messaging**

**PC-A:**
1. Click "Communication"
2. Select "PC-B" from peer list
3. Type: `Hello from PC-A`
4. Send

**PC-B:**
1. Click "Communication"
2. Should see message arrive
3. Reply: `Received on PC-B`

**PC-A:**
- Should see reply

---

## 🛑 STOP PROCEDURE

**On BOTH machines:**
```bash
# Press Ctrl+C in terminal
```

---

## 🔧 TROUBLESHOOTING

| Problem | Solution |
|---------|----------|
| No peer discovery | Wait 60s, check mDNS |
| Web UI blank | Check browser console (F12) |
| Messages fail | Check WebSocket in DevTools |
| Port in use | `sudo lsof -i :8080` |

---

## 📊 SUCCESS CHECKLIST

- [ ] Both nodes start without errors
- [ ] Both Web UIs load
- [ ] Peer count shows 1 on both
- [ ] Message PC-A → PC-B works
- [ ] Message PC-B → PC-A works
- [ ] Messages show "⬢ E2E" badge

---

## 📞 EMERGENCY

If test fails:
1. Check terminal for panic messages
2. Check browser console for errors
3. Verify Tailscale: `tailscale ping <other-ip>`

---

**🎊 READY TO START!**

**Begin with Step 1 on PC-A (omen).**
