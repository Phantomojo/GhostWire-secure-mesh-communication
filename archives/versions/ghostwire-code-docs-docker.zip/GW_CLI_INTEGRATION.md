# ✅ GW-CLI INTEGRATION PLAN

**Key Finding:** The gw-cli defines its **own types** for API responses. These need to match what the backend actually returns.

---

## 🎯 SOLUTION

The backend returns responses in this format:

```json
{
  "version": "2.0",
  "timestamp": "2026-03-18T...",
  "request_id": "uuid",
  "data": { ...actual data... },
  "links": { "self": "/api/v2/..." }
}
```

The gw-cli `Envelope<T>` and `V2Envelope<T>` types are **correct** and match this!

---

## 📋 REQUIRED FIXES

### **1. Backend: Add Serialize to Response Types**

The backend structs that go into `data` field need `Serialize`:

**File: `ghostwire/src/core/api_v2_types.rs`** (or wherever defined)

Add to each struct:
```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProfileV2 {
    pub id: String,
    pub did: String,
    // ... etc
}
```

**Structs needing Serialize:**
- `ProfileV2` (or whatever the profile struct is called)
- `PeerV2` / `PeerInfo`
- `MeshHealthV2`
- `SecurityDashboardV2`
- `ChannelV2`
- `ArkEntryV2`

### **2. GW-CLI: Ensure Type Compatibility**

The gw-cli types in `api.rs` must be able to deserialize the backend's JSON.

**Check these match:**
- Field names (case-sensitive!)
- Field types (String vs Option<String>, etc.)
- Nested structure

---

## 🚀 QUICK TEST

```bash
# Test if backend Profile matches gw-cli Profile
curl -s http://127.0.0.1:8080/api/v2/profile | python3 -c "
import sys, json
d = json.load(sys.stdin)
profile = d['data']
required_fields = ['id', 'did', 'username', 'nickname', 'bio', 'public_key', 'security_score']
missing = [f for f in required_fields if f not in profile]
if missing:
    print('Missing fields:', missing)
    sys.exit(1)
else:
    print('✅ All required fields present')
    print('Profile structure matches gw-cli expectations')
"
```

---

## 🎯 BUILD STRATEGY

**Option A: Fix Backend Types (Recommended)**

1. Find all `V2` response structs in backend
2. Add `#[derive(Serialize)]` to each
3. Rebuild backend
4. Rebuild gw-cli

**Option B: Make GW-CLI Tolerant**

1. Add `#[serde(default)]` to all gw-cli struct fields
2. This makes missing fields default to None/empty
3. Less strict but more forgiving

---

## 📊 CURRENT BACKEND RESPONSES

Test each endpoint:

```bash
# Profile
curl http://localhost:8080/api/v2/profile | jq '.data | keys'

# Peers  
curl "http://localhost:8080/api/v2/peers?page=1&per_page=20" | jq '.data[0] | keys'

# Messages
curl http://localhost:8080/api/messages | jq '.[0] | keys'

# Compare with gw-cli/src/api.rs struct definitions
```

---

## ✅ NEXT STEPS

1. **Run field comparison** (command above)
2. **Add Serialize derives** to backend structs
3. **Rebuild both**
4. **Test `gw identity show`**

**Estimated time:** 30 minutes

---

**The architecture is sound. Just need to ensure type compatibility!**
