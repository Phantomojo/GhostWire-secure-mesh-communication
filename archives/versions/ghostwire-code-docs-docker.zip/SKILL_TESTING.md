# SKILL_TESTING.md — How to Run a Two-Node Live Test

## Prerequisites

- ✅ GhostWire binary built (`cargo build --release`)
- ✅ Two machines on same network (or via Tailscale)
- ✅ SSH access to both machines
- ✅ Ports 8080 (API) and 4001 (mesh) open

## Test Sequence

### Step 1: Start Node A

```bash
# Machine A (omen)
cd ~/ghostwire-live-test
./ghostwire --port 8080 --mesh &

# Verify
curl http://localhost:8080/api/v2/profile | jq '.data.id'
# Save this: NODE_A_ID
```

### Step 2: Start Node B

```bash
# Machine B (dragonfly-1)
cd ~/ghostwire-live-test
./ghostwire --port 8080 --mesh &

# Verify
curl http://localhost:8080/api/v2/profile | jq '.data.id'
# Save this: NODE_B_ID
```

### Step 3: Wait for mDNS Discovery (30-60 seconds)

```bash
# Check peer count on Node A
curl "http://localhost:8080/api/v2/peers?page=1&per_page=20" | jq '.data | length'

# Should show: 1 (Node B discovered)
```

### Step 4: Manual Connection (if mDNS fails)

```bash
# From Node B, connect to Node A
curl -X POST http://localhost:8080/api/v2/peers/connect \
  -H "Content-Type: application/json" \
  -d "{
    \"peer_id\": \"<NODE_A_ID>\",
    \"address\": \"/ip4/<NODE_A_IP>/tcp/4001\"
  }"
```

### Step 5: Test Messaging

```bash
# From Node A, send message to Node B
curl -X POST http://localhost:8080/api/send_message \
  -H "Content-Type: application/json" \
  -d "{
    \"recipient\": \"<NODE_B_ID>\",
    \"content\": \"test message\"
  }"

# Check messages on Node B
curl http://localhost:8080/api/messages | jq '.[] | select(.content=="test message")'
```

### Step 6: Verify Encryption

Messages should show:
- ✅ `encrypted: true`
- ✅ `e2e_badge: "⬢ E2E"`

## Expected Results

| Metric | Expected |
|--------|----------|
| Peer discovery time | < 60 seconds |
| Message delivery | < 2 seconds |
| Encryption | All messages encrypted |
| Peer count | 1 on both nodes |

## Troubleshooting

### No Peer Discovery

```bash
# Check mDNS
avahi-browse -a -t | grep ghostwire

# Check firewall
sudo ufw status

# Manual connect (see Step 4)
```

### Messages Not Delivered

```bash
# Check WebSocket connection
# F12 in browser → Network → WS

# Check backend logs
tail -50 /tmp/ghostwire-*.log | grep -i message
```

### Connection Refused

```bash
# Verify backend running
ps aux | grep ghostwire

# Check port
netstat -tlnp | grep 8080

# Restart backend
pkill -f ghostwire
./ghostwire --port 8080 --mesh &
```

## CLI Testing

```bash
# Test CLI commands
gw identity show
gw peers list
gw net scan
gw net health
```

## Success Criteria

- [ ] Both nodes running
- [ ] Peer count = 1 on both
- [ ] Messages send/receive successfully
- [ ] Messages show E2E encryption
- [ ] No errors in backend logs

## Next Steps

- **Debug issues:** See `SKILL_DEBUG.md`
- **Test channels:** See `SKILL_CHANNELS.md`
- **Test Ark:** See `SKILL_ARK.md`
