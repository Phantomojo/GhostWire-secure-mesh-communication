# GhostWire Developer Quick Reference

**Version:** 1.0  
**Last Updated:** March 2026

---

## 🚀 Quick Commands

### Build & Run
```bash
# Build release
cd ghostwire && cargo build --release

# Run with defaults
./target/release/ghostwire --port 8080 --mesh-port 4001

# Run with debug logging
RUST_LOG=debug ./ghostwire --port 8080

# Run with specific features
cargo run --features "web,cli,mesh,security,stealth"
```

### Skills
```bash
# Security audit
skill: "security-audit"

# Test runner
skill: "test-runner" --coverage

# Crypto audit
skill: "crypto-audit"

# Rust expert review
skill: "rust-expert" --review ghostwire/src/core/identity.rs

# libp2p mesh analysis
skill: "libp2p-dht" --routing-table

# Two-environment test
skill: "two-env-test" --deploy
```

### API Endpoints
```bash
# Get profile
curl http://localhost:8080/api/v2/profile

# List peers
curl "http://localhost:8080/api/v2/peers?page=1&per_page=20"

# Mesh health
curl http://localhost:8080/api/v2/system/mesh-health

# Send message
curl -X POST http://localhost:8080/api/v2/messages \
  -H "Content-Type: application/json" \
  -d '{"recipient": "PEER_ID", "content": "Hello"}'
```

---

## 📁 Project Structure

```
GhostWire-secure-mesh-communication/
├── ghostwire/              # Rust backend
│   ├── src/
│   │   ├── core/           # Core modules
│   │   ├── controllers/    # API controllers
│   │   └── main.rs         # Entry point
│   └── Cargo.toml
│
├── webui/                  # React frontend
│   ├── src/
│   │   ├── components/
│   │   ├── services/
│   │   └── App.tsx
│   └── package.json
│
├── .qwen/                  # Skills & agents
│   ├── skills/
│   ├── agents/
│   └── library/
│
├── docs/                   # Documentation
├── scripts/                # Automation
└── environments/           # Environment configs
```

---

## 🔐 Cryptography Reference

### Algorithms
| Algorithm | Usage | Key Size |
|-----------|-------|----------|
| Ed25519 | Signatures | 32 bytes |
| X25519 | Key Exchange | 32 bytes |
| AES-256-GCM | Encryption | 32 bytes |
| ChaCha20-Poly1305 | AEAD | 32 bytes |
| ML-KEM-768 | PQC KEM | 1088 bytes |
| Argon2id | Password Hash | 64 MB memory |

### Key Patterns
```rust
// ✅ Good: Zeroize on drop
#[derive(Zeroize)]
struct SecretKey {
    key: [u8; 32],
}

// ✅ Good: Use secrecy crate
use secrecy::Secret;
let secret = Secret::new(key);

// ❌ Bad: Debug on key types
#[derive(Debug)]  // May leak keys!
struct PrivateKey { ... }
```

---

## 🌐 libp2p Reference

### Multiaddr Format
```
/ip4/192.168.1.1/tcp/4001/p2p/QmPeerID
/ip4/10.0.0.1/udp/4001/quic/p2p/QmPeerID
/dns4/example.com/tcp/4001/p2p/QmPeerID
```

### Kademlia Parameters
```
Replication Factor (k): 20
Parallelism (α): 3
Bucket Size: 20
Query Timeout: 60 seconds
```

### Gossipsub Parameters
```
Mesh Degree (D): 6
Low Watermark (D_lo): 4
High Watermark (D_hi): 12
Gossip Factor: 0.25
Heartbeat Interval: 1 second
```

---

## 🧪 Testing Commands

### Unit Tests
```bash
# Run all tests
cargo test --lib

# Run specific module
cargo test --lib identity

# Run with output
cargo test --lib -- --nocapture
```

### Integration Tests
```bash
# Run integration tests
cargo test --test '*'

# Run with nextest (faster)
cargo nextest run
```

### Coverage
```bash
# Generate HTML coverage
cargo llvm-cov --html

# View summary
cargo llvm-cov --summary-only
```

---

## 🔧 Development Tools

### Install Dev Tools
```bash
# All-in-one install
./scripts/install-dev-tools.sh

# Individual tools
cargo install cargo-audit
cargo install cargo-deny
cargo install cargo-geiger
cargo install cargo-nextest
cargo install cargo-llvm-cov
cargo install cargo-watch
```

### Pre-commit
```bash
# Run all checks
cargo fmt --check
cargo clippy -- -D warnings
cargo audit
cargo test --lib
```

---

## 📊 Monitoring

### Check Node Health
```bash
# Profile info
curl http://localhost:8080/api/v2/profile | jq '.data'

# Peer count
curl "http://localhost:8080/api/v2/peers" | jq '.data | length'

# Mesh health
curl http://localhost:8080/api/v2/system/mesh-health | jq '.'

# Security dashboard
curl http://localhost:8080/api/v2/security/dashboard | jq '.'
```

### Logs
```bash
# View logs
tail -f /tmp/ghostwire-*.log

# Filter by module
RUST_LOG=libp2p=debug ./ghostwire

# Search for errors
grep -i error /tmp/ghostwire-*.log
```

---

## 🛠️ Troubleshooting

### Backend Won't Start
```bash
# Check if port is in use
netstat -tlnp | grep 8080

# Kill existing process
pkill -f ghostwire

# Check logs
tail -50 /tmp/ghostwire-*.log
```

### Peer Discovery Failing
```bash
# Check mDNS
avahi-browse -a | grep ghostwire

# Check firewall
sudo ufw status

# Manual connect
curl -X POST http://localhost:8080/api/v2/peers/connect \
  -H "Content-Type: application/json" \
  -d '{"peer_id": "PEER_ID", "address": "/ip4/IP/tcp/4001"}'
```

### Build Errors
```bash
# Clean rebuild
cargo clean && cargo build --release

# Update dependencies
cargo update

# Check Rust version
rustc --version
rustup update
```

---

## 📚 Documentation Quick Links

| Document | Purpose |
|----------|---------|
| [ARCHITECTURE.md](docs/ARCHITECTURE.md) | System architecture |
| [SECURITY.md](docs/SECURITY.md) | Security model |
| [API_QUICK_REFERENCE.md](docs/API_QUICK_REFERENCE.md) | API endpoints |
| [GLOBAL_KNOWLEDGE_SOURCES.md](docs/GLOBAL_KNOWLEDGE_SOURCES.md) | Learning resources |
| [30_DAY_LIBP2P_CURRICULUM.md](docs/protocol-knowledge/30_DAY_LIBP2P_CURRICULUM.md) | libp2p learning path |
| [two-env-testing-guide.md](environments/two-env-testing-guide.md) | Two-environment setup |

---

## 🌍 Community Resources

### Official
- [GhostWire GitHub](https://github.com/Phantomojo/GhostWire-secure-mesh-communication)
- [libp2p Docs](https://docs.libp2p.io/)
- [Rust Docs](https://doc.rust-lang.org/)

### Communities
- r/rust (Reddit)
- libp2p Discord
- Rust Users Forum
- r/cryptography (Reddit)

### Knowledge Sources
- See [GLOBAL_KNOWLEDGE_SOURCES.md](docs/GLOBAL_KNOWLEDGE_SOURCES.md)
- Russian: rust-lang.ru, habr.com
- Chinese: rustcc.cn, zhihu.com

---

## 🎯 Common Tasks

### Add New API Endpoint
1. Add handler in `ghostwire/src/api_v2_endpoints.rs`
2. Add types in `ghostwire/src/api_v2_types.rs`
3. Update controller in `ghostwire/src/controllers/`
4. Add frontend service in `webui/src/services/api.ts`
5. Add tests

### Add New Skill
1. Create `.qwen/skills/skill-name/`
2. Add `SKILL.md`
3. Add scripts to `scripts/`
4. Make executable: `chmod +x`
5. Test

### Deploy to Stratsytem
```bash
# Setup Tailscale
./scripts/setup-tailscale.sh

# Deploy
skill: "two-env-test" --deploy

# Test discovery
skill: "two-env-test" --test-discovery
```

---

## 📋 Cheat Sheets

### Rust Ownership
```rust
// Borrow (don't clone)
fn process(data: &[u8]) -> Result<Vec<u8>>

// Return borrowed data (needs lifetime)
fn get_ref<'a>(data: &'a [u8]) -> &'a u8

// Use Cow for zero-copy when possible
fn get_name(data: &str) -> Cow<str>
```

### Error Handling
```rust
// Library errors (thiserror)
#[derive(thiserror::Error, Debug)]
pub enum Error {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
}

// Application errors (anyhow)
pub fn process() -> anyhow::Result<()> { ... }

// Propagate with ?
let data = read_data()?;
```

### Async Patterns
```rust
// Spawn task
let handle = tokio::spawn(async move { ... });

// Timeout
tokio::time::timeout(Duration::from_secs(5), future).await?;

// Select (race)
tokio::select! {
    result = future1 => handle(result),
    _ = timeout => handle_timeout(),
}
```

---

## 🔐 Security Checklist

Before committing:
- [ ] Run `skill: "security-audit"`
- [ ] No hardcoded secrets
- [ ] Keys use `Zeroize`
- [ ] No `Debug` on key types
- [ ] Rate limiting on new endpoints
- [ ] Input validation

Before release:
- [ ] Full security audit
- [ ] Test coverage > 50%
- [ ] Crypto audit complete
- [ ] Two-env testing passed
- [ ] Documentation updated

---

**Maintained By:** GhostWire Development Team  
**License:** AGPL-3.0-or-later
