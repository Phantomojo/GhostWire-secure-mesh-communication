# GHOSTWIRE — FIRST LIVE TEST CHECKLIST
# Two PCs, same local network, mDNS discovery

---

## BEFORE YOU START — verify these once

### Both PCs need
- [ ] Rust >= 1.80  →  `rustup install stable && rustup default stable`
- [ ] Node.js >= 18 →  `node --version`
- [ ] Git checkout of the latest Ghostwire codebase

### Network check
- [ ] Both PCs on the same WiFi or LAN
- [ ] Find both IPs:  `ip addr show` (Linux) or `ipconfig` (Windows)
- [ ] Note them: PC-A IP = _________  PC-B IP = _________

---

## STEP 1 — Build the backend (run on BOTH PCs)

```bash
cd ghostwire/
cargo build --release 2>&1 | tee build.log

# If it fails: check build.log for the first error line
# Most common: missing crate version — fix in Cargo.toml
# After any Cargo.toml fix: cargo build --release again
```

Build takes 5-15 minutes first time. Subsequent builds are fast.
Binary appears at: `target/release/ghostwire`

---

## STEP 2 — Build the frontend (run on BOTH PCs)

```bash
cd webui/

# Download self-hosted fonts (one time only)
./scripts/download-fonts.sh

# Install dependencies
npm install

# Build
npm run build
# Output goes to webui/dist/
```

If the font download script fails (no curl), copy the fonts manually:
- JetBrains Mono: https://github.com/JetBrains/JetBrainsMono/releases
- Extract to webui/public/fonts/

---

## STEP 3 — Firewall (run on BOTH PCs)

### Linux (Ubuntu/Debian)
```bash
sudo ufw allow 8080/tcp   # WebUI + API
sudo ufw allow 4001/tcp   # libp2p mesh
sudo ufw allow 4001/udp   # mDNS (UDP)
sudo ufw status           # verify
```

### Windows (PowerShell as Administrator)
```powershell
netsh advfirewall firewall add rule name="GhostWire API" dir=in action=allow protocol=TCP localport=8080
netsh advfirewall firewall add rule name="GhostWire Mesh" dir=in action=allow protocol=TCP localport=4001
netsh advfirewall firewall add rule name="GhostWire mDNS" dir=in action=allow protocol=UDP localport=4001
```

---

## STEP 4 — Start ghostwire (each PC in its own terminal)

### PC-A
```bash
GHOSTWIRE_LOG=ghostwire=info,libp2p=warn \
  ./target/release/ghostwire \
  --port 8080 \
  --profile pc-a

# You will see output like:
# 🔒 GHOSTWIRE SECURITY 🔒
# X-Ghost-Token: AbCdEf1234567890AbCdEf1234567890
# 
# → Copy this token. You need it for the first WebUI login.
```

### PC-B
```bash
GHOSTWIRE_LOG=ghostwire=info,libp2p=warn \
  ./target/release/ghostwire \
  --port 8080 \
  --profile pc-b

# Copy the token from PC-B's terminal too.
```

---

## STEP 5 — Open WebUI and set up identities

### PC-A: open browser → http://localhost:8080
1. The setup screen appears ("ESTABLISH IDENTITY")
2. Enter a callsign (e.g. "Ghost-Alpha")
3. Enter a passphrase — remember it
4. Click "Establish identity"
5. You are now in the dashboard

### PC-B: open browser → http://localhost:8080 (on PC-B's machine)
1. Same flow — use a different callsign (e.g. "Ghost-Beta")
2. Different passphrase
3. Arrive at dashboard

If you see a blank screen / 401 error:
→ The auth token fix (TASK 0 in agent brief) may not be applied yet.
→ Temporary workaround: open browser dev tools → Application → sessionStorage
→ Add key: `gw_session`, value: `<the token from the terminal>`
→ Refresh the page

---

## STEP 6 — Wait for peer discovery

Both dashboards should show:
- Peer nodes: **1**
- The other PC's nickname in the Network panel

This happens via mDNS — usually within 5–30 seconds.
If it doesn't happen after 60 seconds:
→ Check firewall (Step 3)
→ Check both are on the same network: `ping <other PC's IP>`
→ Check the terminal for: `[mdns] discovered peer` log lines

You can also manually add a peer. In PC-A's terminal:
```bash
# Note PC-B's libp2p peer ID from its startup logs
# It looks like: 12D3KooW...
# Then tell PC-A about it:
```
Or in the WebUI Network panel → paste the multiaddr manually.

---

## STEP 7 — Send the first message

### On PC-A:
1. Click "Comms" in the sidebar
2. Select "Ghost-Beta" (PC-B's identity) in the peer list
3. Type: "first contact"
4. Press Enter or click Send

### On PC-B:
1. Click "Comms" in the sidebar
2. Should see "first contact" from Ghost-Alpha

If the message doesn't appear:
→ Check the Network panel — is the peer connected?
→ Check the terminal for encryption or send errors
→ Try the broadcast first: select "ALL NODES" and send — this is simpler

---

## WHAT SUCCESS LOOKS LIKE

```
PC-A dashboard:
  Peer nodes:  1
  Latency:     ~Xms
  Transport:   STEALTH

PC-B dashboard:
  Peer nodes:  1
  
PC-B Communication:
  [Ghost-Alpha]: "first contact"   ⬢ E2E
```

That's it. Two nodes, one message, end-to-end encrypted, zero servers.

---

## WHAT TO NOTE DOWN DURING THE TEST

For debugging and for the NLnet grant application:
- Time from `ghostwire start` to first peer discovery: _____ seconds
- Message round-trip latency (send to receive): _____ ms
- Any error messages in the terminal — screenshot them
- The Node IDs of both nodes (from dashboard) — save these

---

## IF SOMETHING BREAKS

### "Profile creation failed"
→ Delete `~/.local/share/ghostwire/` and start over
→ Check disk space: `df -h`

### "No peers found after 60 seconds"
→ Both on same network? `ping <other IP>`
→ Ports open? `netstat -tlnp | grep 4001`
→ Check for: `MDNS_NOT_RUNNING` in logs
→ Fallback: add `--bootstrap /ip4/<PC-B IP>/tcp/4001/p2p/<PC-B PeerID>` to PC-A's start command

### "WebUI shows blank / 401"
→ Auth token not set in sessionStorage — see Step 5 workaround
→ Check: `curl http://localhost:8080/api/status` — should return JSON
→ If that works: the backend is fine, it's purely a frontend auth issue

### "Build fails: edition2024 required"
→ Your Rust is too old: `rustup update stable`

### "Port 8080 already in use"
→ `sudo lsof -i :8080` to find what's using it
→ Or start on a different port: `--port 8081`

---

## AFTER A SUCCESSFUL TEST

Things to do immediately after:
1. Screenshot both dashboards showing 1 peer
2. Screenshot the message arriving on PC-B
3. Note the exact Ghostwire git commit hash: `git rev-parse HEAD`
4. Write a one-paragraph description of what happened for the grant application

This is the proof of concept. Everything from here builds on this moment.
