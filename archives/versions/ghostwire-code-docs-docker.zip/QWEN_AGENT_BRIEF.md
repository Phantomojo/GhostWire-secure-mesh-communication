# GHOSTWIRE — AGENT BRIEF v1
# Task: Complete frontend UI and fix blocking issues for first live test
# Read this entire document before writing any code.

---

## CONTEXT

Ghostwire is a privacy mesh networking protocol. The backend is a Rust binary
exposing a REST API on port 8080 and a WebSocket at /api/ws.

The frontend is a React 19 + Vite + TypeScript app in the `webui/` directory.
A new design system and architecture was just built. The file structure is:

```
webui/src/
  styles/index.css          — design system (DO NOT MODIFY)
  context/AppContext.tsx     — global state (useReducer, single source of truth)
  services/api.ts           — all backend calls (typed, cookie-auth)
  components/
    layout/
      Sidebar.tsx           — navigation
      Header.tsx            — status bar
    shared/
      Toast.tsx             — notifications (replaces alert())
    panels/
      Login.tsx             — auth screen
      Dashboard.tsx         — overview
      Channels.tsx          — Ghost Channels (anonymous broadcast)
      Network.tsx           — STUB, needs building
      Communication.tsx     — STUB, needs building (critical for live test)
      Ark.tsx               — STUB, needs building
      Security.tsx          — STUB, needs building
      System.tsx            — STUB, needs building
      Settings.tsx          — STUB, needs building
  App.tsx                   — thin routing layer (DO NOT BLOAT)
```

---

## CRITICAL FIX FIRST (do this before anything else)

### TASK 0 — Fix auth token bridge

The backend uses a file-based token, NOT cookies.
The backend generates a random token on startup, prints it to terminal,
stores it in `~/.local/share/ghostwire/<profile>/token`.

Every API request needs header: `X-Ghost-Token: <token>`

The current api.ts uses `credentials: 'include'` expecting cookies — this will
produce 401 on every request and show a blank screen.

Fix by adding token management to api.ts:

```typescript
// In api.ts, add:
const TOKEN_KEY = 'gw_session';

export function setToken(t: string) {
  sessionStorage.setItem(TOKEN_KEY, t);  // sessionStorage NOT localStorage
}
export function getToken(): string | null {
  return sessionStorage.getItem(TOKEN_KEY);
}
export function clearToken() {
  sessionStorage.removeItem(TOKEN_KEY);
}

// Change request() to:
async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['X-Ghost-Token'] = token;
  
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  // ... rest unchanged
}
```

Also add to Login.tsx: after successful `auth.unlock()`, the server returns
a response — check if it includes a token field and call `setToken(token)`.
If the backend doesn't return the token in the unlock response, add a call to
GET /api/auth/token-info (from localhost only) to fetch it.

WHY sessionStorage not localStorage:
- sessionStorage is cleared when the browser tab closes (correct for a locked identity)
- localStorage persists forever (a seized device retains the token)
- Neither is as good as httpOnly cookies but sessionStorage is the acceptable compromise
  until the backend adds cookie support

---

## TASK 1 — Communication panel (required for live test)

File: `src/components/panels/Communication.tsx`
Replace the stub with a working message interface.

The panel has THREE areas:
1. Left sidebar: contact list (peers from `state.peers`)
2. Main area: message thread for the selected peer or broadcast
3. Bottom: message input

```typescript
// Key imports
import { useApp } from '../../context/AppContext';
import { messages as messagesApi } from '../../services/api';

// On mount and when activeRecipient changes:
// const msgs = await messagesApi.list(recipient === 'broadcast' ? 'all' : recipient)
// dispatch({ type: 'SET_MESSAGES', payload: msgs })

// On send:
// await sendMessage(input, activeRecipient)  // sendMessage is in useApp()
```

DESIGN RULES (follow exactly, don't change):
- Background: var(--void)
- Message from us: class="msg-out"
- Message from peer: class="msg-in"
- Input: class="ops-input"
- Send button: class="btn-ops btn-ops-primary"
- No avatars, no emoji reactions, no read receipts visible
- Timestamp: show as HH:MM only, in var(--t3) color
- Encrypted badge: show "⬢ E2E" in ops-tag-sig class
- Broadcast channel: shown as "ALL NODES" in peer list

The peer list on the left uses the same `nav-item` / `nav-item.active` CSS classes.
Each entry: node nickname (or first 8 chars of node_id), trust level tag, online dot.

Wire WebSocket events: the socket already fires `{ type: 'message', payload: MessageV2 }`
events. In AppContext, `ADD_MESSAGE` is handled. The Communication panel just needs
to display `state.messages` filtered by `state.activeRecipient`.

---

## TASK 2 — Settings panel (required for live test)

File: `src/components/panels/Settings.tsx`

Four sections:

### 2a — Connection settings
```
Backend URL: [input showing API_BASE] [Test] 
Token: [show first 8 chars if set] [Clear session]
```
When user clears session → clearToken() → dispatch SET_LOCKED true

### 2b — Identity
```
Nickname: [input] [Save]        → api.profile.update({ nickname })
Bio:      [input] [Save]
DID:      [readonly, shows state.profile?.did]
```

### 2c — Security protocols
```
Duress PIN:   [Set up →]        → links to /v2/profile/lock flow
Dead man's switch: [Configure →]  → shows interval input + alert channel input
PQC Armor:    [toggle]          → calls api.security (PUT /v2/security/armor)
```
These are "configure" prompts for now — the backend endpoints are wired.
Show a small info text explaining what each does. No alert(), use toast().

### 2d — Danger zone
```
[Lock profile]     → auth.lock() then dispatch SET_LOCKED true
[Wipe all data]   → confirm dialog using a custom in-page confirm (not window.confirm)
```

Custom confirm: render an overlay div with "ARE YOU SURE? Type WIPE to confirm"
input. Only proceed if the user types exactly "WIPE".

---

## TASK 3 — Network panel

File: `src/components/panels/Network.tsx`

Three sections:

### 3a — Peer table
Columns: Status dot | Node ID (12 chars) | Nickname | Trust | Latency | Last seen | Actions

Actions per row:
- [Connect] if status === 'offline' → api.peers.connect(peer.node_id)
- [Block]   → api.peers.block(peer.node_id) + toast + refreshMesh()
- [Ping]    → api.peers.ping(peer.node_id) → shows latency toast

### 3b — Scan button
[⬡ Scan nearby] → api.peers.nearby() → refresh peer list

### 3c — Transport status
Show the 4-tier escalation:
  ● STEALTH TCP → ● WEBRTC → ● COVERT → ● FRONTED → ○ OFFLINE
Highlight current tier. Show latency and internet_reachable from state.transport.

---

## TASK 4 — Knowledge Ark panel

File: `src/components/panels/Ark.tsx`

Three columns:

### 4a — Collections sidebar (left, 180px wide)
List of collections from api.ark.collections()
Click to filter entries.
[+ New entry] button at top.

### 4b — Entry list (middle, flex-1)
Search bar: calls api.ark.search(query) with 300ms debounce.
Entry rows: title | collection | tags | created_at
Click row to open in detail view.

### 4c — Entry detail / create form (right, 280px wide)
View mode: shows title, body, tags, CID, created_at, access level.
Create mode: title input, body textarea, collection dropdown, tags input, access select.
[Save] → api.ark.create(data) → toast → refresh list
[Delete] → api.ark.delete(cid) → confirm inline → toast

The body textarea should be at least 8 lines tall (resize: vertical).
CID is displayed as: ops-tag ops-tag-info, monospace, first 16 chars + "..."

---

## TASK 5 — Security panel

File: `src/components/panels/Security.tsx`

### 5a — Score and threat level
Big number showing state.securityScore.
Color: >= 80 = var(--sig), 60-79 = var(--warn), < 60 = var(--crit).
Threat level badge below it.

### 5b — Audit log
Table of recent security events from api.security.audit().
Columns: Time | Level | Event
Level color: info = var(--info), warn = var(--warn), error = var(--crit)

### 5c — Actions
Each is a btn-ops button:
[Rotate keys]    → api.security.rotateKeys() + toast
[Full lockdown]  → custom in-page confirm → api.security.lockdown(true) + toast

NO window.alert(). NO window.confirm(). Use toast() for results.
Use inline confirm divs for destructive actions.

### 5d — Stats grid
Show: messages_encrypted, peers_verified, rate_limit_violations, blocked_peers
from state.meshHealth.security — just 4 metric-card components.

---

## TASK 6 — System panel

File: `src/components/panels/System.tsx`

Just metrics. Four rows:

```
CPU:     [data-bar] value%
Memory:  [data-bar] value%
Uptime:  HH:MM:SS (formatted from state.uptimeSecs)
Peers:   N nodes in routing table

Sphinx sessions:  N    (from meshHealth.routing.sphinx_sessions)
Mix queue depth:  N    (from meshHealth.routing.mixing_queue_depth)
DTN bundles:      N    (from meshHealth.storage.mailbox_pending)
Ark entries:      N    (from meshHealth.storage.ark_entry_count)
Dedup cache:      N    (from meshHealth.performance.dedup_cache_size)
WS subscribers:   N    (from meshHealth.performance.ws_subscriber_count)
```

[Refresh] button → calls refreshMesh() from useApp()

---

## DESIGN RULES — apply to ALL panels, no exceptions

1. NO window.alert(), window.confirm(), window.prompt() — ever. Use toast().
2. All colors from CSS variables only: var(--sig), var(--warn), var(--crit), etc.
3. Font family: var(--mono) everywhere except section titles which use var(--sans)
4. All text uppercase + letter-spacing: use class="ops-label" or "ops-section-title"
5. Panel wrapper: padding 20px, overflow-y auto, height 100%, class="animate-in"
6. No external icons — use Unicode sigils: ◈ ⬡ ⟁ ◉ ⬟ ⬢ ⊕ ⊞ ✓ ✕ ⚠
7. No gradients on UI elements. Borders use var(--border) or var(--border-hi).
8. No animations except class="animate-in" on panel root divs.
9. Buttons: class="btn-ops" base, add "btn-ops-primary" or "btn-ops-danger" as needed.
10. Inputs: class="ops-input" always.
11. Panels that need left+right split: use display:flex, no CSS grid for two-col layouts.
12. Data tables: use div rows with border-bottom: 1px solid var(--border), NOT <table>.
13. Empty states: centered, var(--t4) color, 11px, explain what to do next.

---

## THINGS TO NEVER DO

- NEVER use `localStorage` for tokens (use sessionStorage)
- NEVER use window.alert / window.confirm
- NEVER import Google Fonts or any external CDN
- NEVER add new npm dependencies without asking first
- NEVER modify styles/index.css
- NEVER modify context/AppContext.tsx dispatch action types without checking all callers
- NEVER add polling (setInterval with API calls) — WebSocket handles real-time
- NEVER put business logic in App.tsx — it must stay thin
- NEVER use the old api.ts patterns (no `api.get()` generic, no `api.post()` generic)
  — use the named module functions: `auth.unlock()`, `peers.list()`, etc.

---

## HOW TO TEST YOUR WORK

Before marking a task done:

1. Does it compile? `npm run build` must succeed with zero errors.
2. Does it respect the design system? Check: no hardcoded colors, no font-family overrides.
3. Does it handle loading states? Show a spinner or "loading..." text during async calls.
4. Does it handle errors? Catch thrown errors and call toast('error', e.message).
5. Does it handle empty states? Show something helpful when lists are empty.
6. Is every alert() gone? Search the file for `alert(`, `confirm(`, `prompt(`.

---

## FILE TO READ FIRST BEFORE CODING

`src/services/api.ts` — understand every exported function and type before
building any panel. Every panel is just a view over the API types defined there.
The AppContext state shape tells you what's already fetched and cached.

If you need data that isn't in AppContext yet, add a local useState + useEffect
in the panel component. Don't add it to AppContext unless it's truly global.

---

## PRIORITY ORDER

1. TASK 0 — auth fix (nothing works without this)
2. TASK 1 — Communication panel (required for live test)
3. TASK 2 — Settings panel (required for live test)
4. TASK 3 — Network panel (helpful for live test)
5. TASK 4 — Knowledge Ark (Wave 4 feature, not blocking)
6. TASK 5 — Security panel (not blocking for first test)
7. TASK 6 — System panel (not blocking for first test)

---

## LIVE TEST CONTEXT

The first live test is between two PCs on the same local network.
Both PCs will run `./ghostwire --port 8080 --mesh-port 4001`.
mDNS will handle peer discovery automatically.
No bootstrap server needed for a local test.

The test sequence:
1. PC-A: start ghostwire → create profile → note Node ID from dashboard
2. PC-B: start ghostwire → create profile → note Node ID from dashboard
3. Wait ~10 seconds → both dashboards should show 1 peer
4. PC-A: Communication panel → select PC-B → type "test" → send
5. PC-B: Communication panel → should see the message arrive

That's the first successful test. Everything in TASK 0 and TASK 1 must work
for step 4 and 5 to succeed.
