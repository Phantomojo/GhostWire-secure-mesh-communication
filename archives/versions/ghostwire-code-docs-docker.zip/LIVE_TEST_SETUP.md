# 🧪 GHOSTWIRE LIVE TEST — SETUP COMPLETE

## ✅ PRE-TEST CHECKLIST

### **Machine Status**

| Machine | Role | Tailscale IP | Binary Deployed | Ports Available |
|---------|------|--------------|-----------------|-----------------|
| **omen** | PC-A | `100.88.234.14` | ✅ `/home/ph/ghostwire-live-test/ghostwire` | ✅ 8080, 4001 |
| **stratsytem** | PC-B | `100.105.58.61` | ✅ `~/ghostwire-live-test/ghostwire` | ✅ 8080, 4001 |

### **Network Configuration**

- ✅ Both machines on Tailscale mesh
- ✅ Direct connection available (stratsytem: `172.16.89.6:1590`)
- ✅ Firewall: INACTIVE on both machines
- ✅ Ports 8080 (API) and 4001 (mesh) available

---

## 🚀 TEST PROCEDURE

### **STEP 1: Start PC-A (omen)**

```bash
# On omen (100.88.234.14)
cd /home/ph/ghostwire-live-test
./ghostwire --port 8080 --mesh-port 4001
```

**Expected Output:**
```
🔑 Loading or creating identity...
📂 Storage path: /root/.local/share/ghostwire/default
🎉 Generated new identity: id_xxxxxxxx
🌐 DID: did:ghost:<hash>
🔓 Identity UNLOCKED
🚀 GhostWire API server starting on http://0.0.0.0:8080
📡 Mesh network initialized on port 4001
```

**ACTION:** Note the **Node ID** from terminal output (looks like `id_xxxxxxxx`)

---

### **STEP 2: Start PC-B (stratsytem)**

```bash
# On stratsytem (100.105.58.61)
ssh stratsytem
cd ~/ghostwire-live-test
./ghostwire --port 8080 --mesh-port 4001
```

**Expected Output:** Same as PC-A

**ACTION:** Note the **Node ID** from terminal output

---

### **STEP 3: Wait for mDNS Discovery (10-30 seconds)**

Both nodes will automatically discover each other via mDNS on the local network.

**What to watch for in terminal:**
```
🔍 Discovered peer via mDNS: <peer_id>
🤝 Connected to peer: <peer_id>
```

---

### **STEP 4: Open Web UI on PC-A**

**Browser URL:** `http://localhost:8080` or `http://100.88.234.14:8080`

**Expected UI Flow:**

1. **Login Screen** appears
   - No existing profile → Shows "Create Profile" option

2. **Create Profile** (if first time)
   - Enter nickname (e.g., "PC-A")
   - Click "Create"
   - Backend generates identity and returns token

3. **Dashboard** loads
   - Shows Node ID
   - Shows peer count (should show 1 after discovery)
   - Shows mesh status

---

### **STEP 5: Open Web UI on PC-B**

**Browser URL:** `http://localhost:8080` or `http://100.105.58.61:8080`

**Same flow as PC-A**

---

### **STEP 6: Verify Peer Discovery**

**On BOTH dashboards:**
- ✅ Peer count shows **1 node**
- ✅ Trust level: **First Contact**
- ✅ Status: **Online** (green dot)

**If peers not showing:**
- Wait another 30 seconds
- Check terminal for mDNS discovery messages
- Verify both nodes are on same network segment

---

### **STEP 7: Test Communication**

**On PC-A:**
1. Click **"Communication"** in sidebar
2. Select **PC-B** from peer list (or "ALL NODES" for broadcast)
3. Type: `test message from PC-A`
4. Click **Send** (⬢ icon)

**On PC-B:**
1. Click **"Communication"** in sidebar
2. Should see message arrive in real-time via WebSocket
3. Message shows with:
   - ✅ Timestamp (HH:MM format)
   - ✅ "⬢ E2E" encrypted badge
   - ✅ Sender nickname

**Reply from PC-B:**
1. Type: `received on PC-B`
2. Click **Send**

**On PC-A:**
- Should see reply arrive

---

### **STEP 8: Verify Dashboard Metrics**

**On BOTH machines, check:**

| Metric | Expected Value |
|--------|----------------|
| **Uptime** | Increasing (HH:MM:SS) |
| **Peers** | 1 node |
| **Messages Encrypted** | > 0 |
| **Security Score** | 60-100 |
| **Threat Level** | LOW |

---

## 🔧 TROUBLESHOOTING

### **Problem: No peer discovery after 60 seconds**

**Solution 1: Check mDNS**
```bash
# On both machines
avahi-browse -a -t 2>/dev/null | grep ghostwire || echo "mDNS not broadcasting"
```

**Solution 2: Manual peer connection**
```bash
# Get PC-A's local IP
ip addr show | grep "inet " | grep -v 127.0.0.1

# On PC-B, connect manually via API
curl -X POST http://100.88.234.14:8080/api/v2/peers/connect \
  -H "Content-Type: application/json" \
  -d '{"peer_id": "<PC-A-node-id>", "address": "/ip4/100.88.234.14/tcp/4001"}'
```

---

### **Problem: Web UI shows blank screen**

**Solution:**
1. Open browser DevTools (F12)
2. Check Console for errors
3. Check Network tab for 401 errors
4. If 401: Backend requires token — check `api.ts` auth flow

**Quick fix:**
```bash
# Get token from backend terminal output
# In browser console:
sessionStorage.setItem('gw_session', 'TOKEN_FROM_TERMINAL');
location.reload();
```

---

### **Problem: Messages not arriving**

**Solution:**
1. Check WebSocket connection in DevTools → Network → WS
2. Verify backend terminal shows message events
3. Check `mesh_health` endpoint: `http://localhost:8080/api/v2/system/mesh-health`

---

## 📊 SUCCESS CRITERIA

Test passes when ALL of the following are true:

- [ ] Both nodes started without errors
- [ ] Both Web UIs load successfully
- [ ] Peer count shows 1 on both dashboards
- [ ] Message sent from PC-A arrives on PC-B
- [ ] Reply from PC-B arrives on PC-A
- [ ] Messages show "⬢ E2E" encryption badge
- [ ] Dashboard metrics update in real-time

---

## 🛑 STOP TEST IF

- Backend crashes with panic
- Web UI shows 500 errors
- Messages show "failed to send"
- Peer count stays at 0 after 2 minutes

---

## 📝 POST-TEST ACTIONS

1. **Stop nodes:**
   ```bash
   # Press Ctrl+C in terminal
   ```

2. **Save logs:**
   ```bash
   # Copy terminal output to log file
   ```

3. **Check for errors:**
   ```bash
   grep -i "error\|panic\|failed" <log-file>
   ```

4. **Report results:**
   - Note any errors or warnings
   - Record message latency (send time → receive time)
   - Screenshot dashboard metrics

---

## 🔐 SECURITY NOTES

- **Token Storage:** sessionStorage (cleared on tab close)
- **Identity Storage:** `~/.local/share/ghostwire/default/`
- **Encryption:** E2E via vodozemac Double Ratchet
- **Transport:** Stealth TCP on port 4001

---

## 📞 EMERGENCY CONTACTS

If test fails:
1. Check `CHANGES_WAVE7_FIXES.md` for known issues
2. Review backend terminal for panic messages
3. Check browser console for JavaScript errors
4. Verify Tailscale connectivity: `tailscale ping <other-node>`

---

**🎊 READY FOR LIVE TEST!**

**Start PC-A (omen) first, then PC-B (stratsytem).**

**Good luck! 🚀**
