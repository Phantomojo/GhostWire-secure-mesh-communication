//! message.rs — Rich message model for Ghostwire
//!
//! The current Message struct is a stub — a flat bag of strings.
//! This replaces it with a proper model that:
//!
//!   - Encodes MessageKind explicitly (text, file, knowledge, reaction, system)
//!   - Tracks encryption state as a typed enum, not a free string
//!   - Carries delivery receipts natively
//!   - Supports the Knowledge Ark content type
//!   - Has a compact wire representation (MessagePack via wire_protocol.rs)
//!   - Handles expiring / ephemeral messages
//!   - Carries optional SURB for anonymous replies

use serde::{Deserialize, Serialize};
use std::time::{SystemTime, UNIX_EPOCH};
use uuid::Uuid;
use zeroize::{Zeroize, ZeroizeOnDrop};

// ── Message kind ──────────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum MessageKind {
    /// Plain text chat
    Text,
    /// Rich markdown text
    Markdown,
    /// File transfer — references a BlockStore manifest CID
    File {
        manifest_cid: String,
        filename: String,
        size_bytes: u64,
        mime_type: Option<String>,
    },
    /// A Knowledge Ark entry — structured knowledge fragment
    KnowledgeEntry {
        entry_id: String,
        collection: String,
        content_type: KnowledgeContentType,
    },
    /// Emoji reaction to another message
    Reaction {
        target_id: String,
        emoji: String,
    },
    /// Read receipt / delivery confirmation
    Receipt {
        target_id: String,
        receipt_kind: ReceiptKind,
    },
    /// Key rotation announcement
    KeyRotation {
        new_key_id: String,
        signed_by: String,
    },
    /// System / protocol message (not displayed to user)
    System {
        action: SystemAction,
    },
    /// Voice note — references a BlockStore manifest CID
    Audio {
        manifest_cid: String,
        duration_secs: u32,
    },
    /// Group management
    Group {
        action: GroupAction,
        group_id: String,
    },
}

impl MessageKind {
    pub fn is_displayable(&self) -> bool {
        !matches!(self, Self::System { .. } | Self::Receipt { .. })
    }

    pub fn type_label(&self) -> &'static str {
        match self {
            Self::Text => "text",
            Self::Markdown => "markdown",
            Self::File { .. } => "file",
            Self::KnowledgeEntry { .. } => "knowledge",
            Self::Reaction { .. } => "reaction",
            Self::Receipt { .. } => "receipt",
            Self::KeyRotation { .. } => "key_rotation",
            Self::System { .. } => "system",
            Self::Audio { .. } => "audio",
            Self::Group { .. } => "group",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum KnowledgeContentType {
    Note,
    Article,
    Code { language: String },
    Reference { url: String },
    MediaClip,
    DataSet,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ReceiptKind {
    Delivered,
    Read,
    Failed { reason: String },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum SystemAction {
    SessionInit,
    SessionClose,
    TypingStart,
    TypingStop,
    Ping,
    Pong,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum GroupAction {
    Create { name: String },
    AddMember { peer_id: String },
    RemoveMember { peer_id: String },
    Leave,
    Rename { new_name: String },
}

// ── Encryption state ──────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum EncryptionState {
    /// Not encrypted (only for local drafts — never sent unencrypted)
    Plaintext,
    /// Encrypted with ChaCha20-Poly1305, direct (no ratchet)
    DirectEncrypted { key_id: String },
    /// Double Ratchet (E2E, forward-secret)
    DoubleRatchet {
        session_id: String,
        message_number: u32,
    },
    /// Sphinx onion-routed + double ratchet
    SphinxRouted {
        route_hops: u8,
        session_id: String,
    },
    /// Sealed sender (recipient can't identify sender)
    SealedSender { session_id: String },
}

impl EncryptionState {
    pub fn is_encrypted(&self) -> bool {
        !matches!(self, Self::Plaintext)
    }

    pub fn has_forward_secrecy(&self) -> bool {
        matches!(self, Self::DoubleRatchet { .. } | Self::SphinxRouted { .. } | Self::SealedSender { .. })
    }

    pub fn label(&self) -> &'static str {
        match self {
            Self::Plaintext => "none",
            Self::DirectEncrypted { .. } => "encrypted",
            Self::DoubleRatchet { .. } => "e2e+fs",
            Self::SphinxRouted { .. } => "sphinx+e2e",
            Self::SealedSender { .. } => "sealed",
        }
    }
}

// ── Delivery state ────────────────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum DeliveryState {
    /// Created locally, not yet sent
    Pending,
    /// Sent to first relay / peer
    Sent,
    /// Confirmed received by recipient's device
    Delivered,
    /// Confirmed read by recipient
    Read,
    /// Delivery failed (will retry or go to mailbox)
    Failed { reason: String, retry_count: u8 },
    /// Queued in MailboxStore for offline delivery
    Queued,
    /// Expired (ephemeral message TTL exceeded)
    Expired,
}

// ── Core Message struct ───────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Message {
    /// Unique message ID (UUID v4)
    pub id: String,
    /// Sender's node ID (hex-encoded BLAKE3 of Ed25519 pub key)
    pub sender: String,
    /// Recipient's node ID, group ID, or "broadcast"
    pub recipient: String,
    /// Message type and payload
    pub kind: MessageKind,
    /// The actual content (encrypted bytes or plaintext for local storage)
    pub content: String,
    /// Encryption state
    pub encryption: EncryptionState,
    /// Delivery state
    pub delivery: DeliveryState,
    /// Creation timestamp (Unix seconds)
    pub timestamp: u64,
    /// Optional TTL — message auto-deletes after this Unix timestamp
    pub expires_at: Option<u64>,
    /// Thread ID (for replies) — references another message's ID
    pub thread_id: Option<String>,
    /// Optional SURB for anonymous replies (see sphinx.rs)
    pub surb: Option<Vec<u8>>, // serialized Surb
    /// Signature over (id + sender + recipient + content + timestamp)
    pub signature: Option<Vec<u8>>,
    /// Version field for protocol evolution
    pub version: u8,
}

impl Message {
    pub fn new(sender: String, recipient: String, content: String) -> Self {
        Self {
            id: Uuid::new_v4().to_string(),
            sender,
            recipient,
            kind: MessageKind::Text,
            content,
            encryption: EncryptionState::Plaintext,
            delivery: DeliveryState::Pending,
            timestamp: now_secs(),
            expires_at: None,
            thread_id: None,
            surb: None,
            signature: None,
            version: 2,
        }
    }

    pub fn new_text(sender: String, recipient: String, content: String) -> Self {
        Self::new(sender, recipient, content)
    }

    pub fn new_ephemeral(
        sender: String,
        recipient: String,
        content: String,
        ttl_secs: u64,
    ) -> Self {
        let mut msg = Self::new(sender, recipient, content);
        msg.expires_at = Some(now_secs() + ttl_secs);
        msg
    }

    pub fn new_file(
        sender: String,
        recipient: String,
        manifest_cid: String,
        filename: String,
        size_bytes: u64,
        mime_type: Option<String>,
    ) -> Self {
        let mut msg = Self::new(sender.clone(), recipient.clone(), String::new());
        msg.kind = MessageKind::File { manifest_cid, filename, size_bytes, mime_type };
        msg
    }

    pub fn new_knowledge_entry(
        sender: String,
        recipient: String,
        entry_id: String,
        collection: String,
        content_type: KnowledgeContentType,
        content: String,
    ) -> Self {
        let mut msg = Self::new(sender, recipient, content);
        msg.kind = MessageKind::KnowledgeEntry { entry_id, collection, content_type };
        msg
    }

    pub fn is_expired(&self) -> bool {
        self.expires_at
            .map(|t| now_secs() > t)
            .unwrap_or(false)
    }

    pub fn mark_sent(&mut self) {
        self.delivery = DeliveryState::Sent;
    }

    pub fn mark_delivered(&mut self) {
        self.delivery = DeliveryState::Delivered;
    }

    pub fn mark_read(&mut self) {
        self.delivery = DeliveryState::Read;
    }

    /// Compute the signable payload: deterministic bytes over key fields
    pub fn signable_bytes(&self) -> Vec<u8> {
        let mut buf = Vec::new();
        buf.extend_from_slice(self.id.as_bytes());
        buf.extend_from_slice(self.sender.as_bytes());
        buf.extend_from_slice(self.recipient.as_bytes());
        buf.extend_from_slice(self.content.as_bytes());
        buf.extend_from_slice(&self.timestamp.to_le_bytes());
        buf
    }

    /// Backward-compat: return type label as string
    pub fn message_type(&self) -> &'static str {
        self.kind.type_label()
    }

    pub fn encryption_status(&self) -> &'static str {
        self.encryption.label()
    }
}

// ── Message builder ───────────────────────────────────────────────────────────

/// Fluent builder for constructing messages
pub struct MessageBuilder {
    sender: String,
    recipient: String,
    content: String,
    kind: MessageKind,
    encryption: EncryptionState,
    expires_at: Option<u64>,
    thread_id: Option<String>,
    surb: Option<Vec<u8>>,
}

impl MessageBuilder {
    pub fn new(sender: impl Into<String>, recipient: impl Into<String>) -> Self {
        Self {
            sender: sender.into(),
            recipient: recipient.into(),
            content: String::new(),
            kind: MessageKind::Text,
            encryption: EncryptionState::Plaintext,
            expires_at: None,
            thread_id: None,
            surb: None,
        }
    }

    pub fn text(mut self, content: impl Into<String>) -> Self {
        self.content = content.into();
        self.kind = MessageKind::Text;
        self
    }

    pub fn markdown(mut self, content: impl Into<String>) -> Self {
        self.content = content.into();
        self.kind = MessageKind::Markdown;
        self
    }

    pub fn file(mut self, manifest_cid: String, filename: String, size_bytes: u64) -> Self {
        self.kind = MessageKind::File {
            manifest_cid,
            filename,
            size_bytes,
            mime_type: None,
        };
        self
    }

    pub fn knowledge(
        mut self,
        entry_id: String,
        collection: String,
        content: impl Into<String>,
    ) -> Self {
        self.content = content.into();
        self.kind = MessageKind::KnowledgeEntry {
            entry_id,
            collection,
            content_type: KnowledgeContentType::Note,
        };
        self
    }

    pub fn encrypt_double_ratchet(mut self, session_id: String, msg_num: u32) -> Self {
        self.encryption = EncryptionState::DoubleRatchet {
            session_id,
            message_number: msg_num,
        };
        self
    }

    pub fn expires_in(mut self, ttl_secs: u64) -> Self {
        self.expires_at = Some(now_secs() + ttl_secs);
        self
    }

    pub fn reply_to(mut self, message_id: impl Into<String>) -> Self {
        self.thread_id = Some(message_id.into());
        self
    }

    pub fn with_surb(mut self, surb_bytes: Vec<u8>) -> Self {
        self.surb = Some(surb_bytes);
        self
    }

    pub fn build(self) -> Message {
        Message {
            id: Uuid::new_v4().to_string(),
            sender: self.sender,
            recipient: self.recipient,
            kind: self.kind,
            content: self.content,
            encryption: self.encryption,
            delivery: DeliveryState::Pending,
            timestamp: now_secs(),
            expires_at: self.expires_at,
            thread_id: self.thread_id,
            surb: self.surb,
            signature: None,
            version: 2,
        }
    }
}

fn now_secs() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn builder_creates_valid_message() {
        let msg = MessageBuilder::new("alice", "bob")
            .text("Ubuntu — I am because we are")
            .encrypt_double_ratchet("session_abc".into(), 0)
            .expires_in(3600)
            .build();

        assert_eq!(msg.sender, "alice");
        assert_eq!(msg.kind, MessageKind::Text);
        assert!(msg.encryption.has_forward_secrecy());
        assert!(msg.expires_at.is_some());
        assert!(!msg.is_expired());
    }

    #[test]
    fn ephemeral_message_expires() {
        let mut msg = Message::new_ephemeral("a".into(), "b".into(), "secret".into(), 0);
        // TTL=0 means expired immediately
        std::thread::sleep(std::time::Duration::from_millis(10));
        assert!(msg.is_expired());
    }

    #[test]
    fn signable_bytes_are_deterministic() {
        let msg = Message::new("a".into(), "b".into(), "hello".into());
        let b1 = msg.signable_bytes();
        let b2 = msg.signable_bytes();
        assert_eq!(b1, b2);
    }
}
