# GHOSTWIRE WAVE 4 — CORE OVERHAUL
# Agent Instructions: Start-to-End Micro-Optimization + Knowledge Ark + Cross-Device Pairing
# Builds on: ghostwire-v2-complete.zip + ghostwire-v3-security.zip
# Apply in order: v2 → v3 → v4
# Version: 4.0 | March 2026

---

## WHAT THIS PACKAGE CONTAINS

| Module | Purpose |
|--------|---------|
| `src/core/message.rs` | Complete message model rewrite — typed kinds, encryption states, delivery tracking |
| `src/core/knowledge/knowledge_ark.rs` | The Knowledge Ark — distributed knowledge layer for Indra's Net vision |
| `src/core/identity/device_pairing.rs` | Cross-device pairing — QR codes, LAN discovery, DHT rendezvous |
| `src/startup.rs` | Phased boot sequence with diagnostics, health checks, boot report |
| `src/core/micro_optimizations.rs` | Identity cache, peer address cache, O(1) dedup, ring bus, session warming |

---

## THE CROSS-DEVICE PROBLEM (READ THIS FIRST)

Your two PCs can't talk because of three missing pieces:

1. **No pairing protocol** — They don't know each other's public keys
2. **No rendezvous mechanism** — They can't find each other's IPs across networks  
3. **No LAN auto-discovery for trusted peers** — mDNS finds peers but doesn't establish trust

Wave 4 fixes all three. After applying this wave, the flow is:

**Same LAN (both PCs on same WiFi):**
- PC1 and PC2 auto-discover each other via mDNS (already works in mesh.rs)
- `device_pairing.rs` Phase 2: LAN discovery handles trust establishment
- Both PCs exchange a 6-digit safety number to confirm the connection
- Done — they're paired and can message

**Different networks (home + work, Nairobi + remote):**
- PC1 runs `ghostwire pair generate` → shows a 16-char code + rendezvous address
- You send the rendezvous address to PC2 out-of-band (WhatsApp, email, printed)
- PC2 runs `ghostwire pair connect <rendezvous_address>`
- DHT lookup finds PC1's current multiaddrs
- TOFU + safety number confirmation
- Done

**Fully offline / air-gap:**
- PC1 shows a QR code containing its ContactCard (`gw2:...` prefix)
- PC2 scans it
- Direct IP connection + pairing code verification
- Done

---

## PHASE 1 — MESSAGE MODEL MIGRATION

### 1.1 Replace message.rs

```bash
cp src/core/message.rs ghostwire/src/core/message.rs
```

### 1.2 Update all message consumers

Find all places that use `message.message_type` or `message.encryption_status`:

```bash
grep -rn "message_type\|encryption_status\|\.encrypted" ghostwire/src/ --include="*.rs"
```

For each occurrence, migrate:
```rust
// BEFORE:
let mtype = message.message_type.clone();
let enc = message.encryption_status.clone();
let is_enc = message.encrypted;

// AFTER:
let mtype = message.message_type(); // method call, same return type
let enc = message.encryption_status(); // method call
let is_enc = message.encryption.is_encrypted();
```

### 1.3 Update message construction throughout codebase

```bash
grep -rn "Message::new\|Message {" ghostwire/src/ --include="*.rs"
```

All existing `Message::new(sender, recipient, content)` calls are backward-compatible —
the new message.rs keeps this constructor. Only add `MessageBuilder` for new message types.

### 1.4 Update message serialization

In `mesh.rs` where messages are broadcast via gossipsub:
```rust
// BEFORE:
let data = serde_json::to_vec(&message)?;

// AFTER (smaller wire format):
use crate::core::wire_protocol::{Frame, FrameKind};
let frame = Frame::encode(FrameKind::Message, &message)?;
let data = frame.to_bytes();
```

---

## PHASE 2 — KNOWLEDGE ARK

### 2.1 Add module
```bash
mkdir -p ghostwire/src/core/knowledge
cp src/core/knowledge/knowledge_ark.rs ghostwire/src/core/knowledge/knowledge_ark.rs
cat > ghostwire/src/core/knowledge/mod.rs << 'EOF'
pub mod knowledge_ark;
pub use knowledge_ark::{KnowledgeArk, ArkEntry, ArkCollection, EntryKind, AccessLevel};
EOF
```

### 2.2 Add to core mod.rs
```rust
pub mod knowledge;
```

### 2.3 Add KnowledgeArk to Core struct
```rust
// In Core struct:
pub knowledge_ark: Arc<crate::core::knowledge::KnowledgeArk>,

// In Core::new() after identity init:
let knowledge_ark = Arc::new(crate::core::knowledge::KnowledgeArk::new(
    identity.id.clone()
));
```

### 2.4 Add API endpoints
In `web.rs`:
```rust
// Knowledge Ark endpoints
.route("/v2/ark/collections",        get(ArkController::list_collections))
.route("/v2/ark/collections",        post(ArkController::create_collection))
.route("/v2/ark/entries",            post(ArkController::create_entry))
.route("/v2/ark/entries/:cid",       get(ArkController::get_entry))
.route("/v2/ark/entries/:cid",       delete(ArkController::delete_entry))
.route("/v2/ark/search",             get(ArkController::search))
.route("/v2/ark/tags/:tag",          get(ArkController::search_by_tag))
.route("/v2/ark/stats",              get(ArkController::stats))
.route("/v2/ark/sync",               post(ArkController::sync_with_peer))
```

Create `ghostwire/src/controllers/ark.rs`:
```rust
pub struct ArkController;

impl ArkController {
    pub async fn search(
        State(state): State<Arc<AppState>>,
        Query(params): Query<HashMap<String, String>>,
    ) -> impl IntoResponse {
        let query = params.get("q").map(|s| s.as_str()).unwrap_or("");
        let core = state.core.read().await;
        let results = core.knowledge_ark.search(query).await;
        Json(ApiV2Response::success(
            results.into_iter().map(|(e, score)| {
                serde_json::json!({ "entry": e, "score": score })
            }).collect::<Vec<_>>()
        ))
    }

    pub async fn create_entry(
        State(state): State<Arc<AppState>>,
        Json(req): Json<serde_json::Value>,
    ) -> impl IntoResponse {
        let title = req["title"].as_str().unwrap_or("").to_string();
        let body = req["body"].as_str().unwrap_or("").to_string();
        let collection = req["collection"].as_str().unwrap_or("default").to_string();

        let core = state.core.read().await;
        let node_id = core.get_identity_id().await;

        let entry = ArkEntry::new(title, body, EntryKind::Note, node_id, collection);
        let cid = core.knowledge_ark.add_entry(entry).await.unwrap();
        Json(ApiV2Response::success(serde_json::json!({ "cid": cid })))
    }
    // ... other handlers
}
```

### 2.5 Wire Knowledge messages into message routing

When a `MessageKind::KnowledgeEntry` arrives, import it into the local Ark:
```rust
// In mesh.rs message handler:
if let MessageKind::KnowledgeEntry { entry_id, collection, .. } = &message.kind {
    if let Ok(bytes) = serde_json::to_vec(&message) {
        let _ = core.knowledge_ark.import_entry(&bytes).await;
    }
}
```

---

## PHASE 3 — DEVICE PAIRING

### 3.1 Add module
```bash
cp src/core/identity/device_pairing.rs ghostwire/src/core/identity/device_pairing.rs
```

In `ghostwire/src/core/identity/mod.rs`, add:
```rust
pub mod device_pairing;
pub use device_pairing::{PairingManager, PairingCode, PairedPeer, ContactCard};
```

### 3.2 Add PairingManager to Core struct
```rust
// In Core struct:
pub pairing_manager: Arc<crate::core::identity::device_pairing::PairingManager>,

// In Core::new() after identity and encryption init:
let ed25519_pub = identity.get_public_key().to_vec();
let x25519_pub = encryption.get_x25519_public_key().to_vec();
let pairing_manager = Arc::new(PairingManager::new(
    identity.id.clone(),
    ed25519_pub,
    x25519_pub,
));
```

### 3.3 Add API endpoints
```rust
.route("/v2/pair/generate",     post(PairingController::generate_code))
.route("/v2/pair/respond",      post(PairingController::respond_to_code))
.route("/v2/pair/complete",     post(PairingController::complete_pairing))
.route("/v2/pair/contact-card", get(PairingController::get_contact_card))
.route("/v2/pair/scan",         post(PairingController::scan_contact_card))
.route("/v2/pair/rendezvous",   get(PairingController::get_rendezvous_address))
```

### 3.4 Add CLI commands
In `cli/commands.rs`:
```rust
Commands::Pair => {
    let (code, session) = core.pairing_manager.initiate_pairing().await?;
    println!("Pairing code: {}", code.display);
    println!("Safety number: {}", code.safety_number());
    println!("Share this code with the other device. Expires in 10 minutes.");
    println!("\nOr share your rendezvous address:");
    println!("{}", core.pairing_manager.rendezvous_address(&core.get_public_key()));
}
Commands::Connect { address } => {
    // For rendezvous address: look up in DHT, initiate pairing
    println!("Connecting to rendezvous address: {}", address);
    // DHT lookup + TOFU
}
```

### 3.5 Wire rendezvous address publication into mesh startup

In `mesh.rs` after the mesh is running and DHT is connected:
```rust
// Publish our rendezvous record to DHT so peers can find us
let rendezvous_key = core.pairing_manager.rendezvous_dht_key(&our_ed25519_pub);
let our_multiaddrs: Vec<String> = swarm
    .listeners()
    .map(|a| a.to_string())
    .collect();
let value = serde_json::to_vec(&our_multiaddrs)?;
swarm.behaviour_mut().kad.put_record(
    libp2p::kad::Record {
        key: libp2p::kad::RecordKey::new(&rendezvous_key),
        value,
        publisher: None,
        expires: Some(std::time::Instant::now() + Duration::from_secs(3600)),
    },
    libp2p::kad::Quorum::One,
)?;
```

### 3.6 Wire pairing into TrustStore

After a successful pairing, pin the peer's key in TrustStore:
```rust
let paired = pairing_manager.complete_pairing(&session_id, &response, &code).await?;
core.trust_store
    .verify_or_pin(&paired.node_id, &paired.ed25519_pub)
    .await?;
core.trust_store
    .mark_verified(&paired.node_id, &paired.ed25519_pub)
    .await?; // Pairing = verified contact
```

---

## PHASE 4 — STARTUP SEQUENCE

### 4.1 Add module
```bash
cp src/startup.rs ghostwire/src/startup.rs
```

In `ghostwire/src/lib.rs`:
```rust
pub mod startup;
```

### 4.2 Replace main.rs boot sequence

The new main.rs should look like:

```rust
#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt::init();

    let args = Args::parse();
    let config = load_config(&args)?;

    // Boot sequence with diagnostics
    let (boot_tx, _) = tokio::sync::broadcast::channel(64);
    let mut boot = startup::StartupSequence::new(Some(boot_tx));

    let data_dir = dirs::data_dir()
        .unwrap_or_else(|| std::path::PathBuf::from("."))
        .join("ghostwire");

    boot.phase0_preflight(&data_dir)?;

    let identity_result = boot.phase1_identity(
        args.profile.as_deref(), &data_dir
    ).await?;

    boot.phase2_storage(&data_dir).await?;

    let net_config = startup::NetworkBootConfig {
        listen_port: args.port,
        bootstrap_nodes: args.bootstrap.clone(),
        websocket_mode: config.network.websocket_mode,
        shadowsocks_mode: config.network.shadowsocks_mode,
        obfs4_enabled: config.network.obfs4_enabled,
    };
    let net_result = boot.phase3_network(&net_config).await?;

    boot.phase4_knowledge(&data_dir).await?;

    // Now init Core (all checks passed)
    let core = Core::new(config.clone(), bootstrap_multiaddrs, args.sim_addr, args.profile).await?;
    let core_arc = Arc::new(core);

    // Boot complete
    boot.phase5_ready(
        &core_arc.get_identity_id().await,
        &net_result.transport_mode,
        0,
    );

    let report = boot.report(Some(core_arc.get_identity_id().await), &net_result);
    tracing::info!("Boot completed in {}ms — {} warnings",
        report.total_duration_ms, report.warnings.len());

    // Start services
    core_arc.clone().start_nervous_system(args.mesh_host.clone()).await;
    ghostwire::web::start_web_server(...).await?;

    Ok(())
}
```

### 4.3 Expose boot report via API

Add endpoint:
```rust
.route("/v2/system/boot-report", get(SystemController::boot_report))
```

Store the BootReport in AppState:
```rust
pub struct AppState {
    // ...existing fields...
    pub boot_report: Arc<tokio::sync::RwLock<Option<crate::startup::BootReport>>>,
}
```

---

## PHASE 5 — MICRO-OPTIMIZATIONS

### 5.1 Add module
```bash
cp src/core/micro_optimizations.rs ghostwire/src/core/micro_optimizations.rs
```

### 5.2 Add to Core struct
```rust
use crate::core::micro_optimizations::{
    IdentityCache, PeerAddressCache, MessageDeduplicator,
    RingBus, SessionWarmer,
};

// In Core struct:
pub identity_cache: Arc<IdentityCache>,
pub peer_address_cache: Arc<PeerAddressCache>,
pub message_dedup: Arc<MessageDeduplicator>,
pub session_warmer: Arc<SessionWarmer>,

// In Core::new():
identity_cache: Arc::new(IdentityCache::new()),
peer_address_cache: Arc::new(PeerAddressCache::new(
    std::time::Duration::from_secs(300) // 5min TTL
)),
message_dedup: Arc::new(MessageDeduplicator::new(
    std::time::Duration::from_secs(60) // 60s dedup window
)),
session_warmer: Arc::new(SessionWarmer::new()),
```

### 5.3 Update identity_cache after unlock

In `controllers/identity.rs` unlock handler, after successful unlock:
```rust
let snapshot = IdentitySnapshot {
    node_id: core.get_identity_id().await,
    did: core.get_did().await,
    nickname: core.get_metadata().await.nickname,
    ed25519_pub: core.get_public_key().to_vec(),
    x25519_pub: vec![], // From encryption manager
    key_id: core.get_key_id(),
    is_locked: false,
};
state.core.read().await.identity_cache.update(snapshot).await;
```

### 5.4 Replace message dedup in mesh.rs

Where gossipsub messages are received:
```rust
// BEFORE: no dedup (every message processed)
// AFTER:
let msg_id = format!("{}", message.message_id);
if core.message_dedup.is_duplicate(&msg_id) {
    tracing::debug!("Dropping duplicate message {}", msg_id);
    return;
}
```

### 5.5 Session pre-warming in peer connection handler

```rust
SwarmEvent::ConnectionEstablished { peer_id, .. } => {
    let peer_id_str = peer_id.to_string();
    if !core.session_warmer.is_warm(&peer_id_str) {
        // Init Double Ratchet session proactively
        if let Some(peer_pub_key) = core.trust_store.get(&peer_id_str).await
            .and_then(|r| Some(r.current_key))
        {
            let _ = core.crypto_machine.init_session(
                peer_id_str.clone(),
                "default".into(),
                peer_pub_key.try_into().unwrap_or([0u8; 32]),
            );
            core.session_warmer.mark_warmed(peer_id_str);
        }
    }
}
```

---

## INTEGRATION CHECKLIST

After applying all 5 phases, verify:

```bash
# Compile check
cargo check --all-features 2>&1 | grep "^error"

# Full test suite
cargo test 2>&1 | grep -E "FAILED|PASSED|test result"

# Boot sequence test
cargo run -- --config ghostwire.toml.example 2>&1 | head -40
# Should show the phased boot sequence with checkmarks

# Cross-device test (run on both PCs on same LAN)
# PC1:
curl http://localhost:8080/api/v2/pair/generate
# Should return: { "code": "XXXX-XXXX-XXXX-XXXX", "safety_number": "123456", "session_id": "..." }

# PC2 (replace CODE with output from PC1):
curl -X POST http://localhost:8080/api/v2/pair/respond \
  -d '{"code":"XXXX-XXXX-XXXX-XXXX","initiator_id":"..."}' | jq .

# Verify safety numbers match between the two terminals
# If they match: pairing is successful and both nodes are trusted peers

# Knowledge Ark test
curl -X POST http://localhost:8080/api/v2/ark/entries \
  -d '{"title":"First entry","body":"Ubuntu - I am because we are","collection":"default"}' | jq .

curl "http://localhost:8080/api/v2/ark/search?q=ubuntu" | jq .
```

---

## FULL SYSTEM ARCHITECTURE (after all 4 waves)

```
STARTUP
  Phase 0: Pre-flight (disk, ports, platform)
  Phase 1: Identity (load/create, verify keys, JWT seed)
  Phase 2: Storage (encrypted sled, message DB)
  Phase 3: Network (internet probe, LAN IP, transport select, bootstrap)
  Phase 4: Knowledge Ark (load collections, build index)
  Phase 5: Ready (announce, start API)

CORE
  ├── IdentityCache (lock-free read snapshot)
  ├── EncryptionManager (X25519 + ChaCha20 + ML-KEM)
  ├── GhostCryptoMachine (Double Ratchet sessions)
  ├── SessionWarmer (pre-warm sessions on peer connect)
  ├── TrustStore (TOFU + WoT + attestations)
  ├── PairingManager (QR + LAN + DHT rendezvous)
  ├── KnowledgeArk (collections + full-text search)
  ├── BlockStore (content-addressed file transfer)
  ├── MailboxStore (offline delivery)
  ├── EncryptedStore (Argon2 sled)
  ├── MessageDeduplicator (O(1) DashMap)
  ├── PeerAddressCache (TTL-based multiaddr cache)
  └── DisasterManager (transport fallback chain)

NETWORK
  ├── MeshDriver (libp2p: Kademlia + Gossipsub + mDNS)
  ├── DiverseRoutingTable (S/Kademlia IP diversity)
  ├── SphinxRouter (bitwise-unlinkable onion routing)
  ├── MixingQueue (exponential delay)
  ├── TrafficArmor (padding + cover traffic)
  ├── StealthTCPProvider (HMAC handshake)
  └── PluggableTransport (WebSocket / Shadowsocks camouflage)

API
  ├── /v2/profile (identity CRUD)
  ├── /v2/pair (device pairing)
  ├── /v2/messages (send/receive/history)
  ├── /v2/files (BlockStore transfer)
  ├── /v2/ark (Knowledge Ark CRUD + search)
  ├── /v2/trust (peer trust management)
  ├── /v2/network (status, QR contact)
  ├── /v2/security (audit log)
  └── /v2/system (health, boot report)
```

---

## WHAT MAKES GHOSTWIRE UNIQUE (after all 4 waves)

1. **Knowledge Ark** — no other private messenger has a built-in knowledge commons.
   Notes, articles, code, data — all content-addressed, replicated across trusted peers,
   searchable offline. This is the Indra's Net vision made concrete.

2. **Ubuntu-first design** — relay incentives (Bitswap ledger), Shamir recovery
   (community-held keys), social graph trust (WoT attestation). Privacy that
   strengthens community rather than isolating individuals.

3. **Global South ready** — MessagePack wire format (50% smaller than JSON),
   WebSocket camouflage (passes through Safaricom traffic shaping),
   disaster mode with LoRa bridge, works on metered 3G.

4. **Sovereign identity** — did:ghost:// DIDs, no phone numbers, no email,
   no central registration. Your identity is your keypair.

5. **Defence in depth** — Sphinx (bitwise unlinkability) + exponential mixing
   (timing resistance) + padding (size resistance) + cover traffic (silence resistance)
   + WebSocket camouflage (fingerprint resistance). Four independent layers.

---

## FUTURE VISION (Wave 5+)

- **Knowledge Ark federation** — public collections replicate across the entire mesh.
  Anyone can contribute to a shared knowledge commons.
- **LoRa bridge** — rural Kenya reach via LILYGO T-Beam hardware
- **Platform-native secret storage** — keyring crate for Keychain/Keystore
- **Full Sphinx curve-point blinding** — replace BLAKE3 approximation with
  proper x25519 scalar multiplication
- **Android client** — Tauri mobile or React Native + Ghostwire FFI
