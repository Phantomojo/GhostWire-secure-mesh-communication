// GhostWire API Service — real calls only, no fake data
// Replaces: api.ts, enhancedApi.ts (delete that file)

// ── Base URL ──────────────────────────────────────────────────────────────────
// Backend runs on 8080 (NOT 3001 — that was wrong everywhere)

const getApiBase = (): string => {
  const saved = localStorage.getItem('ghostwire_backend_url');
  if (saved) return saved.replace(/\/$/, '');
  if (import.meta.env.VITE_API_BASE_URL) return import.meta.env.VITE_API_BASE_URL;
  const host = window.location.hostname;
  const port = import.meta.env.VITE_API_PORT || '8080';
  return `http://${host}:${port}/api`;
};

const getWsBase = (): string => {
  const httpBase = getApiBase();
  return httpBase.replace(/^http/, 'ws').replace('/api', '') + '/api/ws';
};

export const API_BASE = getApiBase();
export const WS_URL = getWsBase();

// ── Auth ──────────────────────────────────────────────────────────────────────

const getToken = (): string | null =>
  localStorage.getItem('ghostwire_auth_token') ||
  localStorage.getItem('ghostwire_token');

const setToken = (t: string) => localStorage.setItem('ghostwire_auth_token', t);
const clearToken = () => localStorage.removeItem('ghostwire_auth_token');

const authHeaders = (): Record<string, string> => {
  const t = getToken();
  const h: Record<string, string> = { 'Content-Type': 'application/json' };
  if (t) h['Authorization'] = `Bearer ${t}`;
  return h;
};

// ── Core fetch wrapper ────────────────────────────────────────────────────────

async function req<T>(
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH',
  path: string,
  body?: unknown,
  noAuth = false
): Promise<T> {
  const url = path.startsWith('http') ? path : `${API_BASE}${path}`;
  const opts: RequestInit = {
    method,
    headers: noAuth ? { 'Content-Type': 'application/json' } : authHeaders(),
  };
  if (body !== undefined) opts.body = JSON.stringify(body);

  const res = await fetch(url, opts);

  if (res.status === 401) {
    clearToken();
    window.dispatchEvent(new Event('ghostwire:session-expired'));
    throw new Error('Session expired');
  }

  const data = await res.json().catch(() => ({ success: false, error: res.statusText }));

  if (!res.ok) {
    throw new Error(data?.error?.message || data?.error || `HTTP ${res.status}`);
  }

  return data;
}

const get = <T>(path: string) => req<T>('GET', path);
const post = <T>(path: string, body?: unknown) => req<T>('POST', path, body);
const put = <T>(path: string, body?: unknown) => req<T>('PUT', path, body);
const del = <T>(path: string) => req<T>('DELETE', path);
const patch = <T>(path: string, body?: unknown) => req<T>('PATCH', path, body);

// ── Types ─────────────────────────────────────────────────────────────────────

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: { code: string; message: string };
  timestamp?: string;
}

export interface ProfileData {
  id: string;
  did: string;
  nickname: string;
  bio: string;
  avatar_url: string | null;
  public_key: string;
  setup_complete: boolean;
  is_locked: boolean;
  profile: string;
}

export interface PeerData {
  node_id: string;
  nickname: string | null;
  did: string;
  connection_state: string;
  is_online: boolean;
  signal: number;
  last_seen: number;
  discovery_method: string;
}

export interface MessageData {
  id: string;
  sender: string;
  recipient: string;
  content: string;
  timestamp: number;
  kind: string;
  encryption: string;
  delivery: string;
  expires_at: number | null;
  thread_id: string | null;
}

export interface NetworkStatus {
  internet_reachable: boolean;
  latency_ms: number;
  packet_loss_pct: number;
  active_peers: number;
  transport_mode: string;
  network_state: string;
  last_update: number;
}

export interface SettingsData {
  // Identity
  nickname: string;
  bio: string;
  avatar_url: string | null;
  status_message: string | null;
  // Network
  listen_port: number;
  api_port: number;
  max_peers: number;
  mdns_enabled: boolean;
  dht_enabled: boolean;
  transport_mode: 'stealth' | 'websocket' | 'shadowsocks' | 'obfs4';
  mixing_preset: 'low_latency' | 'balanced' | 'max_anonymity';
  cover_traffic_pct: number;
  // Security
  pqc_enabled: boolean;
  auto_lock_minutes: number;
  key_rotation_days: number;
  failed_attempts_lockout: number;
  // Privacy
  presence: 'off' | 'contacts' | 'public';
  read_receipts: boolean;
  message_preview: boolean;
  strip_metadata: boolean;
  traffic_morphing: boolean;
  stealth_mode: boolean;
  anonymous_sender: boolean;
  sphinx_dms: boolean;
  // Notifications
  sound_enabled: boolean;
  desktop_notifications: boolean;
  notify_connection_requests: boolean;
  notify_ark_sync: boolean;
  // Ark
  default_collection: string;
  ark_auto_sync: boolean;
  ark_max_mb: number;
  // Advanced
  debug_mode: boolean;
  log_level: 'error' | 'warn' | 'info' | 'debug' | 'trace';
  msgpack_wire: boolean;
  auto_update: boolean;
}

export interface ArkEntry {
  id: string;
  title: string;
  body: string;
  kind: string;
  author: string;
  collection: string;
  tags: string[];
  access: string;
  created_at: number;
  updated_at: number;
  cid: string;
}

export interface GhostChannel {
  topic_id: number[];
  local_name: string | null;
  description: string | null;
  created_at: number;
  invite_string?: string;
}

export interface ConnectRequest {
  request_id: string;
  from_node_id: string;
  from_did: string;
  from_nickname: string;
  message: string | null;
  timestamp: number;
}

// ── Auth API ──────────────────────────────────────────────────────────────────

export const auth = {
  // Get a dev token (only works when debug mode is on)
  devToken: () => get<{ token: string }>('/dev/token'),

  // Unlock profile with password
  unlock: async (profile: string, password: string): Promise<string> => {
    const res = await post<ApiResponse<{ token: string }>>('/v2/profile/unlock', { profile, password });
    if (res.data?.token) {
      setToken(res.data.token);
      return res.data.token;
    }
    throw new Error('No token in unlock response');
  },

  lock: () => post('/v2/profile/lock'),

  isAuthenticated: () => !!getToken(),
  clearSession: clearToken,
};

// ── Profile API ───────────────────────────────────────────────────────────────

export const profile = {
  get: () => get<ApiResponse<ProfileData>>('/v2/profile'),
  getPublicKey: () => get<ApiResponse<{ public_key: string }>>('/v2/profile/public-key'),

  create: (name: string, nickname?: string, password?: string) =>
    post<ApiResponse>('/v2/profile/create', { name, nickname, password }),

  update: (data: Partial<Pick<SettingsData, 'nickname' | 'bio' | 'avatar_url' | 'status_message'>>) =>
    put<ApiResponse>('/v2/profile/metadata', data),

  list: () => get<ApiResponse<{ profiles: { name: string; has_identity: boolean; setup_complete: boolean }[]; current: string }>>('/profile/list'),

  select: (profile_name: string) =>
    post<ApiResponse>('/profile/select', { profile_name }),

  delete: (name: string) => del<ApiResponse>(`/profile/delete/${name}`),

  wipe: () => post<ApiResponse>('/system/wipe'),
};

// ── Peers / Social API ────────────────────────────────────────────────────────

export const peers = {
  list: () => get<ApiResponse<{ peers: PeerData[]; count: number }>>('/v2/peers'),
  nearby: () => get<ApiResponse<{ nearby: PeerData[] }>>('/v2/peers/nearby'),

  sendRequest: (node_id: string, message?: string) =>
    post<ApiResponse>('/v2/peers/connect', { node_id, message }),

  listRequests: () => get<ApiResponse<{ requests: ConnectRequest[] }>>('/v2/peers/requests'),

  respondToRequest: (request_id: string, accept: boolean) =>
    post<ApiResponse>('/v2/peers/requests/respond', { request_id, accept }),

  disconnect: (node_id: string) => del<ApiResponse>(`/v2/peers/${node_id}`),
  block: (node_id: string) => post<ApiResponse>(`/v2/peers/${node_id}/block`),
  getProfile: (node_id: string) => get<ApiResponse<PeerData>>(`/v2/peers/${node_id}/profile`),

  ping: (node_id: string) => post<ApiResponse<{ latency_ms: number }>>('/v2/peers/ping', { node_id }),
};

// ── Messaging API ─────────────────────────────────────────────────────────────

export const messages = {
  list: (peer_id = 'all', limit = 50) =>
    get<ApiResponse<MessageData[]>>(`/v2/messages?peer_id=${peer_id}&limit=${limit}`),

  send: (recipient: string, content: string, ttl_secs?: number) =>
    post<ApiResponse<{ id: string }>>('/v2/messages/send', { recipient, content, ttl_secs }),

  broadcast: (content: string) =>
    post<ApiResponse<{ message_id: string; recipients: number }>>('/broadcast', { message: content }),

  react: (target_id: string, emoji: string, recipient: string) =>
    post<ApiResponse>('/v2/messages/send', {
      recipient,
      content: '',
      kind: 'reaction',
      target_id,
      emoji,
    }),

  markRead: (message_id: string, sender: string) =>
    post<ApiResponse>('/v2/messages/send', {
      recipient: sender,
      content: '',
      kind: 'receipt',
      target_id: message_id,
      receipt_kind: 'read',
    }),
};

// ── Network API ───────────────────────────────────────────────────────────────

export const network = {
  status: () => get<ApiResponse<NetworkStatus>>('/v2/network/status'),
  meshHealth: () => get<ApiResponse>('/v2/system/mesh-health'),
  generateContactQr: () => get<ApiResponse<{ qr_string: string; node_id: string; rendezvous: string }>>('/v2/network/qr-contact'),
  scanQr: (qr_string: string) => post<ApiResponse>('/v2/network/scan-qr', { qr_string }),

  // Legacy endpoints the frontend uses — now mapped to real routes
  scanForNodes: () => get<ApiResponse<{ nearby: PeerData[] }>>('/v2/peers/nearby'),
  getLocalIp: () => get<ApiResponse<NetworkStatus>>('/v2/network/status'),
};

// ── Settings API ──────────────────────────────────────────────────────────────

export const settings = {
  get: () => get<ApiResponse<SettingsData>>('/settings'),
  update: (data: Partial<SettingsData>) => put<ApiResponse>('/settings', data),
};

// ── Pairing API ───────────────────────────────────────────────────────────────

export const pairing = {
  generateCode: () => post<ApiResponse<{ code: string; safety_number: string; session_id: string; expires_in_secs: number }>>('/v2/pair/generate'),
  getContactCard: () => get<ApiResponse<{ qr_string: string; node_id: string; rendezvous: string }>>('/v2/pair/contact-card'),
  getRendezvous: () => get<ApiResponse<{ rendezvous_address: string }>>('/v2/pair/rendezvous'),
  scanContactCard: (qr_string: string) => post<ApiResponse>('/v2/pair/scan', { qr_string }),
};

// ── Knowledge Ark API ─────────────────────────────────────────────────────────

export const ark = {
  listCollections: () => get<ApiResponse>('/v2/ark/collections'),
  createCollection: (name: string, description?: string) =>
    post<ApiResponse>('/v2/ark/collections', { name, description }),

  createEntry: (title: string, body: string, collection: string, tags?: string[], access?: string) =>
    post<ApiResponse<{ cid: string }>>('/v2/ark/entries', { title, body, collection, tags, access }),

  getEntry: (cid: string) => get<ApiResponse<ArkEntry>>(`/v2/ark/entries/${cid}`),
  deleteEntry: (cid: string) => del<ApiResponse>(`/v2/ark/entries/${cid}`),
  search: (q: string) => get<ApiResponse>(`/v2/ark/search?q=${encodeURIComponent(q)}`),
  searchByTag: (tag: string) => get<ApiResponse>(`/v2/ark/tags/${encodeURIComponent(tag)}`),
  stats: () => get<ApiResponse>('/v2/ark/stats'),
};

// ── Ghost Channels API ────────────────────────────────────────────────────────

export const channels = {
  list: () => get<ApiResponse<GhostChannel[]>>('/v2/channels'),
  create: (name?: string) => post<ApiResponse<{ channel: GhostChannel; invite: string }>>('/v2/channels', { name }),
  join: (invite: string) => post<ApiResponse<GhostChannel>>('/v2/channels/join', { invite }),
  leave: (id: string) => post<ApiResponse>(`/v2/channels/${id}/leave`),
  publish: (id: string, text: string) => post<ApiResponse>(`/v2/channels/${id}/publish`, { text }),
  getMessages: (id: string) => get<ApiResponse<string[]>>(`/v2/channels/${id}/messages`),
};

// ── Security API ──────────────────────────────────────────────────────────────

export const security = {
  audit: () => get<ApiResponse>('/v2/security/audit'),
  getAuditLog: () => get<ApiResponse>('/system/audit'),
  rotateKeys: () => post<ApiResponse>('/v2/security/rotate-keys'),
  lockdown: () => post<ApiResponse>('/v2/security/lockdown'),
};

// ── Recovery API ──────────────────────────────────────────────────────────────

export const recovery = {
  setupShares: (threshold: number, total: number, guardians: unknown[]) =>
    post<ApiResponse>('/v2/recovery/setup', { threshold, total, guardians }),
  listMyShares: () => get<ApiResponse>('/v2/recovery/my-shares'),
  reconstruct: (shares: unknown[], new_password: string) =>
    post<ApiResponse>('/v2/recovery/reconstruct', { shares, new_password }),
};

// ── Trust API ─────────────────────────────────────────────────────────────────

export const trust = {
  get: (peer_id: string) => get<ApiResponse>(`/v2/trust/${peer_id}`),
  verify: (peer_id: string, public_key: string) => post<ApiResponse>(`/v2/trust/${peer_id}/verify`, { public_key }),
  block: (peer_id: string) => post<ApiResponse>(`/v2/trust/${peer_id}/block`),
  list: () => get<ApiResponse>('/v2/trust'),
};

// ── System API ────────────────────────────────────────────────────────────────

export const system = {
  status: () => get<ApiResponse>('/system/stats'),
  bootReport: () => get<ApiResponse>('/v2/system/boot-report'),
  meshHealth: () => get<ApiResponse>('/v2/system/mesh-health'),
  getLogs: () => get<ApiResponse>('/system/logs'),
};

// ── Connectivity check ────────────────────────────────────────────────────────

export async function checkBackendConnection(): Promise<boolean> {
  try {
    await fetch(`${API_BASE}/status`, { method: 'GET', signal: AbortSignal.timeout(3000) });
    return true;
  } catch {
    return false;
  }
}

// ── WebSocket client ──────────────────────────────────────────────────────────

export type WsEventType =
  | 'connected'
  | 'core_event'
  | 'connection_request'
  | 'peer_list'
  | 'pong'
  | 'error';

export interface WsEvent {
  type: WsEventType;
  payload?: unknown;
  // connection_request fields
  from_node_id?: string;
  from_nickname?: string;
  request_id?: string;
  timestamp?: number;
  // peer_list
  peers?: PeerData[];
  count?: number;
  // pong
  timestamp_ms?: number;
  // connected
  node_id?: string;
  version?: string;
  // error
  code?: string;
  message?: string;
}

type WsHandler = (event: WsEvent) => void;

class GhostWireWs {
  private ws: WebSocket | null = null;
  private handlers: Set<WsHandler> = new Set();
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectDelay = 2000;
  private shouldConnect = false;

  connect() {
    this.shouldConnect = true;
    this._connect();
  }

  private _connect() {
    if (this.ws?.readyState === WebSocket.OPEN) return;
    const url = WS_URL;
    this.ws = new WebSocket(url);

    this.ws.onopen = () => {
      this.reconnectDelay = 2000;
      window.dispatchEvent(new Event('ghostwire:ws-connected'));
    };

    this.ws.onmessage = (e) => {
      try {
        const event: WsEvent = JSON.parse(e.data);
        this.handlers.forEach(h => h(event));
      } catch { /* ignore malformed */ }
    };

    this.ws.onclose = () => {
      window.dispatchEvent(new Event('ghostwire:ws-disconnected'));
      if (this.shouldConnect) {
        this.reconnectTimer = setTimeout(() => {
          this.reconnectDelay = Math.min(this.reconnectDelay * 1.5, 30000);
          this._connect();
        }, this.reconnectDelay);
      }
    };

    this.ws.onerror = () => this.ws?.close();
  }

  disconnect() {
    this.shouldConnect = false;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.ws?.close();
  }

  send(cmd: object) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(cmd));
    }
  }

  on(handler: WsHandler) {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }

  ping() { this.send({ cmd: 'ping' }); }
  getPeers() { this.send({ cmd: 'get_peers' }); }
}

export const ws = new GhostWireWs();

// Legacy compat — old api object that components use
// Maps old method names to new real endpoints
export const api = {
  get: (path: string) => get<ApiResponse>(path),
  post: (path: string, body?: unknown) => post<ApiResponse>(path, body),
  put: (path: string, body?: unknown) => put<ApiResponse>(path, body),
  delete: (path: string) => del<ApiResponse>(path),

  listProfiles: profile.list,
  deleteProfile: (name: string) => profile.delete(name).then(() => true).catch(() => false),
  wipeSystem: () => profile.wipe().then(() => true).catch(() => false),
  getProfile: profile.get,
  updateProfile: profile.update,
  unlock: auth.unlock,
  lock: auth.lock,
  createProfile: profile.create,

  sendMessage: (recipient: string, content: string) => messages.send(recipient, content),
  getMessages: (peer_id?: string) => messages.list(peer_id),
  broadcast: (content: string) => messages.broadcast(content),

  getPeers: peers.list,
  getNearbyPeers: peers.nearby,

  getNetworkStatus: network.status,
  scanNetwork: network.scanForNodes,
  getNetworkInfo: network.getLocalIp,

  getSettings: settings.get,
  updateSettings: settings.update,

  setUsername: (username: string) => profile.update({ nickname: username }),
  getUsername: () => profile.get().then(r => ({ username: r.data?.nickname })),

  // Security
  runSecurityScan: security.audit,
  runThreatHunt: security.audit,
  runSecurityAudit: security.getAuditLog,
  lockdown: security.lockdown,
  backupSecurity: recovery.setupShares,
  rotateKeys: security.rotateKeys,
};
