# 🧪 Quick API Test Guide

Fast reference for testing GhostWire APIs from the command line.

## Fastest Method: Use Our Test Scripts

```bash
# Full automated test (recommended)
./test-api.sh localhost:8080

# Or with Newman (needs Node.js)
./test-api-newman.sh localhost:8080
```

---

## Manual Testing with cURL (No Installation)

### 1. Start the API
```bash
cd ghostwire
cargo run -- web --port 8080
```

In another terminal, run tests below.

### 2. Check Health
```bash
curl http://localhost:8080/api/status
```

### 3. Get Authentication Token
```bash
TOKEN=$(curl -s http://localhost:8080/api/dev/token | grep -oP '"data":"?\K[^"]+')
echo "Token: $TOKEN"
```

### 4. Test Profile Endpoints
```bash
# List profiles (no auth needed)
curl http://localhost:8080/api/v2/profile

# Get profile details (needs auth)
curl -H "X-Ghost-Token: $TOKEN" \
  http://localhost:8080/api/v2/profile
```

### 5. Test Security
```bash
# Get security dashboard
curl -H "X-Ghost-Token: $TOKEN" \
  http://localhost:8080/api/v2/security/dashboard
```

### 6. Test Messaging
```bash
# Get messages
curl -H "X-Ghost-Token: $TOKEN" \
  http://localhost:8080/api/v2/messages

# Send broadcast
curl -X POST http://localhost:8080/api/broadcast \
  -H "X-Ghost-Token: $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"content": "Test message"}'
```

### 7. Test Peers
```bash
curl -H "X-Ghost-Token: $TOKEN" \
  http://localhost:8080/api/v2/peers
```

---

## API Test Checklist

Use this to verify all major functionality:

```bash
# Start API
cargo run -- web --port 8080 &
API_PID=$!
sleep 2

# Get token
TOKEN=$(curl -s http://localhost:8080/api/dev/token | \
  grep -oP '"data":"?\K[^"]+')

# Test each category
echo "Testing Status..."
curl -s http://localhost:8080/api/status | jq .

echo "Testing Profiles..."
curl -s http://localhost:8080/api/v2/profile | jq .

echo "Testing Auth..."
curl -s -H "X-Ghost-Token: $TOKEN" \
  http://localhost:8080/api/v2/profile | jq .

echo "Testing Security..."
curl -s -H "X-Ghost-Token: $TOKEN" \
  http://localhost:8080/api/v2/security/dashboard | jq .

echo "Testing Peers..."
curl -s -H "X-Ghost-Token: $TOKEN" \
  http://localhost:8080/api/v2/peers | jq .

echo "Testing Messages..."
curl -s -H "X-Ghost-Token: $TOKEN" \
  http://localhost:8080/api/v2/messages | jq .

# Cleanup
kill $API_PID
```

---

## One-Liner Tests

```bash
# Check if API is running
curl -s http://localhost:8080/api/status | grep -q "ok" && echo "✓ API online" || echo "✗ API offline"

# Get token and test
TOKEN=$(curl -s http://localhost:8080/api/dev/token | grep -oP '"data":"?\K[^"]+') && \
curl -s -H "X-Ghost-Token: $TOKEN" http://localhost:8080/api/v2/profile | jq .

# Test all endpoints
for endpoint in status "v2/profile" "v2/peers" "v2/messages" "v2/security/dashboard"; do
  echo "Testing /$endpoint..."
  curl -s -w "Status: %{http_code}\n" \
    -H "X-Ghost-Token: ${TOKEN:-none}" \
    http://localhost:8080/api/$endpoint | head -20
done
```

---

## Using jq for JSON Pretty-Print

Most responses are JSON. Use `jq` to format them:

```bash
# Install jq (if not present)
apt-get install jq  # or: pacman -S jq

# Pretty-print response
curl -s http://localhost:8080/api/status | jq .

# Extract specific field
curl -s http://localhost:8080/api/dev/token | jq .data

# Filter results
curl -s -H "X-Ghost-Token: $TOKEN" \
  http://localhost:8080/api/v2/peers | jq '.peers[0]'
```

---

## Testing Payloads (POST Requests)

### Create Profile
```bash
curl -X POST http://localhost:8080/api/v2/profile \
  -H "Content-Type: application/json" \
  -d '{
    "name": "test_profile",
    "nickname": "Test User",
    "password": "securepass123"
  }'
```

### Send Message
```bash
curl -X POST http://localhost:8080/api/broadcast \
  -H "X-Ghost-Token: $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "content": "Hello mesh network!"
  }'
```

### Update Profile
```bash
curl -X PUT http://localhost:8080/api/v2/profile/metadata \
  -H "X-Ghost-Token: $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "nickname": "New Name",
    "bio": "My bio here"
  }'
```

---

## Common Issues & Fixes

### Issue: "Connection refused"
```bash
# API not running
# Start it:
cargo run -- web --port 8080
```

### Issue: "401 Unauthorized"
```bash
# Token expired or missing
# Get new token:
TOKEN=$(curl -s http://localhost:8080/api/dev/token | grep -oP '"data":"?\K[^"]+')
# Use with requests:
curl -H "X-Ghost-Token: $TOKEN" http://localhost:8080/api/v2/profile
```

### Issue: "CORS error"
```bash
# Browser-based requests may need CORS headers
# Already fixed in web.rs, but if issues persist:
# Rebuild: cargo build --release
```

### Issue: "Can't parse JSON response"
```bash
# Response not JSON (might be HTML error page)
curl -v http://localhost:8080/api/v2/profile  # Check response headers

# Or check what the API returned:
curl -s http://localhost:8080/api/v2/profile | head -20
```

---

## Performance Testing

### Measure Response Time
```bash
# Single request timing
time curl -s http://localhost:8080/api/status > /dev/null

# Multiple requests
for i in {1..10}; do
  time curl -s http://localhost:8080/api/v2/peers > /dev/null
done
```

### Load Testing
```bash
# Install Apache Bench (if not present)
apt-get install apache2-utils

# Run 100 requests, 10 concurrent
ab -n 100 -c 10 http://localhost:8080/api/status

# Expected: sub-100ms average for status endpoint
```

---

## Complete Test Flow (Copy-Paste Ready)

```bash
#!/bin/bash

API="http://localhost:8080/api"

echo "1. Health check..."
curl -s $API/status | jq .

echo "2. Get token..."
TOKEN=$(curl -s $API/dev/token | jq -r .data)
echo "Token: ${TOKEN:0:20}..."

echo "3. Test authenticated endpoint..."
curl -s -H "X-Ghost-Token: $TOKEN" $API/v2/profile | jq .

echo "4. Send message..."
curl -X POST $API/broadcast \
  -H "X-Ghost-Token: $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"content": "Test from CLI"}' | jq .

echo "5. List peers..."
curl -s -H "X-Ghost-Token: $TOKEN" $API/v2/peers | jq .

echo "✓ All tests complete!"
```

Save as `test.sh`, then run:
```bash
chmod +x test.sh
./test.sh
```

---

## Recommended Tools

| Tool | Purpose | Install |
|------|---------|---------|
| **curl** | Basic HTTP | Pre-installed |
| **jq** | JSON formatting | `apt-get install jq` |
| **httpie** | Pretty HTTP | `pip3 install httpie` |
| **newman** | Postman CLI | `npm install -g newman` |
| **ab** | Load testing | `apt-get install apache2-utils` |
| **wrk** | Performance | `brew install wrk` |

---

## Next Steps

1. **Quick Test**: Run `./test-api.sh localhost:8080`
2. **Full Report**: Run `./test-api-newman.sh localhost:8080`
3. **Manual Testing**: Use cURL commands above
4. **CI/CD**: See `API_TESTING_GUIDE.md` for integration

---

**All tests pass?** ✓ Your API is ready for production!

See `API_TESTING_GUIDE.md` for detailed documentation.
