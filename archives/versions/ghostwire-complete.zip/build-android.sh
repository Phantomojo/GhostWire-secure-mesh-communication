#!/bin/bash
# GhostWire Android Build Script
# This builds the GhostWire backend for Android deployment

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GHOSTWIRE_DIR="$SCRIPT_DIR/ghostwire"
ANDROID_TARGET="aarch64-linux-android"
OUTPUT_DIR="$SCRIPT_DIR/android-build"

echo -e "${BLUE}=========================================${NC}"
echo -e "${BLUE}  GhostWire Android Build${NC}"
echo -e "${BLUE}=========================================${NC}"
echo ""

# Check if Android NDK is available
if [ -z "$ANDROID_NDK_HOME" ] && [ -z "$NDK_HOME" ]; then
    echo -e "${YELLOW}⚠️  Android NDK not found in environment${NC}"
    echo "   Looking for NDK in common locations..."
    
    if [ -d "$ANDROID_HOME/ndk" ]; then
        ANDROID_NDK_HOME=$(ls -d $ANDROID_HOME/ndk/* | head -1)
        echo -e "${GREEN}✓ Found NDK: $ANDROID_NDK_HOME${NC}"
    else
        echo -e "${RED}❌ Android NDK not found${NC}"
        echo "   Please install Android NDK or set ANDROID_NDK_HOME"
        exit 1
    fi
fi

export ANDROID_NDK_HOME=${ANDROID_NDK_HOME:-$NDK_HOME}

# Check if rustup target is installed
echo -n "📦 Checking Rust target for Android... "
if rustup target list --installed | grep -q "$ANDROID_TARGET"; then
    echo -e "${GREEN}Installed${NC}"
else
    echo -e "${YELLOW}Not installed${NC}"
    echo "   Installing $ANDROID_TARGET..."
    rustup target add $ANDROID_TARGET
fi

# Create output directory
mkdir -p "$OUTPUT_DIR"

# Build for Android
echo ""
echo -e "${YELLOW}🔨 Building GhostWire for Android...${NC}"
echo "   Target: $ANDROID_TARGET"
echo "   Output: $OUTPUT_DIR"
echo ""

cd "$GHOSTWIRE_DIR"
cargo build --release --target $ANDROID_TARGET 2>&1 | tee "$SCRIPT_DIR/logs/android_build_$(date +%Y%m%d_%H%M%S).log"

# Check if build succeeded
if [ -f "$GHOSTWIRE_DIR/target/$ANDROID_TARGET/release/ghostwire" ]; then
    echo ""
    echo -e "${GREEN}=========================================${NC}"
    echo -e "${GREEN}  ✓ Android Build Successful!${NC}"
    echo -e "${GREEN}=========================================${NC}"
    echo ""
    echo -e "${BLUE}Binary location:${NC}"
    ls -lh "$GHOSTWIRE_DIR/target/$ANDROID_TARGET/release/ghostwire"
    echo ""
    echo -e "${BLUE}To deploy to device:${NC}"
    echo "   adb push $GHOSTWIRE_DIR/target/$ANDROID_TARGET/release/ghostwire /data/local/tmp/ghostwire"
    echo "   adb shell chmod 755 /data/local/tmp/ghostwire"
    echo "   adb shell /data/local/tmp/ghostwire"
else
    echo ""
    echo -e "${RED}❌ Build failed${NC}"
    echo "   Check logs for details"
    exit 1
fi
