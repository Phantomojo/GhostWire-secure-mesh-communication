# GhostWire TODO List

> **Last Updated:** February 18, 2026  
> **Total Items:** 30  
> **Completed:** 0  
> **In Progress:** 2  
> **Pending:** 28

---

## 🔴 Critical Security (In Progress)

- [ ] **#2:** Add rate limiting to `/api/v2/profile/unlock` endpoint (brute force protection)
- [ ] **#9:** Implement audit logging for lock/unlock security events
- [ ] **#21:** Fix security module compilation conflicts (SecurityEvent naming)
- [ ] **#22:** Add governor rate limiter middleware to Axum router
- [ ] **#23:** Wire FailedAttemptTracker into Core::new() initialization
- [ ] **#24:** Wire AuditLogger into Core::new() initialization
- [ ] **#25:** Update unlock_profile endpoint to use rate limiting + lockout + audit
- [ ] **#26:** Update lock_profile endpoint to use audit logging
- [ ] **#27:** Add security headers middleware (HSTS, X-Frame-Options, etc.)

---

## 🟠 High Priority (Pending)

- [ ] **#1:** Add obfs4 disclaimer warning at startup (ALPHA - not yet functional)
- [ ] **#3:** Run cargo audit and fix any vulnerabilities
- [ ] **#4:** Remove or use dead code: obfs4_state field in MeshTransport
- [ ] **#7:** Add integration tests for new profile endpoints (lock/unlock/save)
- [ ] **#8:** Add integration tests for obfs4 configuration
- [ ] **#16:** Add monitoring/alerting for failed unlock attempts
- [ ] **#20:** Run full build with cargo build --release and verify no errors
- [ ] **#28:** Create deny.toml for cargo-deny security policies
- [ ] **#30:** Set up GitHub Actions CI workflow with security scanning

---

## 🟡 Medium Priority (Pending)

- [ ] **#5:** Curate documentation - review 12 NotebookLLM docs for accuracy
- [ ] **#6:** Consolidate overlapping documentation guides
- [ ] **#10:** Consider adding password recovery mechanism for profiles
- [ ] **#11:** Complete obfs4 transport layer integration (actual traffic obfuscation)
- [ ] **#12:** Add peer count cache invalidation strategy (currently can be stale)
- [ ] **#13:** Test publish_username() DHT functionality end-to-end
- [ ] **#14:** Add connection stats tracking for obfs4 transport
- [ ] **#15:** Create API deprecation strategy document
- [ ] **#17:** Document bootstrap node selection criteria and privacy implications
- [ ] **#18:** Add key rotation support for locked/unlocked profiles
- [ ] **#29:** Add utoipa for OpenAPI/Swagger documentation

---

## 🟢 Low Priority (Pending)

- [ ] **#19:** Verify intentional deletion of GhostWire_Interface_TUI.md (3,719 lines)

---

## 📊 Progress Tracking

### Security Implementation Status

| Component | Status | Notes |
|-----------|--------|-------|
| Rate Limiting | ⚠️ Partial | Governor added, not wired |
| Account Lockout | ⚠️ Partial | Code written, not integrated |
| Audit Logging | ⚠️ Partial | Code written, not integrated |
| Security Headers | ❌ Not Started | |
| CI/CD Security | ❌ Not Started | |

### Documentation Status

| Document | Status | Location |
|----------|--------|----------|
| Dev Tools Guide | ✅ Complete | `docs/DEV_TOOLS.md` |
| API Security Checklist | ✅ Complete | `docs/API_SECURITY.md` |
| API Versioning Policy | ✅ Complete | `docs/API_VERSIONING.md` |
| API Deep Dive | ✅ Complete | `docs/api/DEEP_DIVE.md` |
| Bruno Collection | ✅ Complete | `bruno-collection/` |
| Install Script | ✅ Complete | `scripts/install-dev-tools.sh` |
| Makefile.toml | ✅ Complete | Project root |

---

## 🎯 Next Steps (Priority Order)

1. **Fix security module compilation** (#21)
2. **Wire FailedAttemptTracker & AuditLogger** (#23, #24)
3. **Update unlock/lock endpoints** (#25, #26)
4. **Run cargo audit** (#3)
5. **Remove dead code** (#4)
6. **Run full release build** (#20)

---

## 📝 Notes

- **Security module code** is written in `src/core/security.rs` but has naming conflicts with existing `SecurityEvent` enum
- **Core struct** has fields added for `failed_attempt_tracker` and `audit_logger` but needs proper initialization
- **All documentation** is complete and ready to use
- **Bruno collection** ready for API testing

---

**Created:** February 18, 2026  
**Maintained By:** GhostWire Team
