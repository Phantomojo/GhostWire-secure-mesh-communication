# System-Wide Progress Bar & Monitor for Arch Linux

**Complete guide to creating a top bar system monitor that tracks ALL background tasks**

---

## 🎯 **What We're Building**

A **system-wide progress monitoring system** that shows:
- 📦 Pacman package downloads & installs
- 🔨 Build processes (cargo, gradle, npm, etc.)
- 📥 File downloads
- 🔄 Background tasks
- 💻 System resources (CPU, RAM, Network)
- 📊 Progress bars in top panel

---

## 📋 **Research Findings**

### Best Solutions for Arch/Hyprland:

| Tool | Best For | Integration | Complexity |
|------|----------|-------------|------------|
| **Waybar** | Top bar monitoring | ⭐⭐⭐⭐⭐ | Easy |
| **Progress** | CLI progress bars | ⭐⭐⭐⭐ | Easy |
| **libnotify** | Desktop notifications | ⭐⭐⭐⭐ | Medium |
| **kdialog/zenity** | GUI dialogs | ⭐⭐⭐ | Easy |
| **System Monitor Plus** | Full system monitoring | ⭐⭐⭐⭐ | Medium |

---

## 🚀 **Solution 1: Waybar with Custom Modules (RECOMMENDED)**

### Installation:
```bash
sudo pacman -S waybar
```

### Configuration (`~/.config/waybar/config`):

```json
{
  "layer": "top",
  "position": "top",
  "height": 30,
  "modules-left": ["hyprland/workspaces", "custom/pacman_progress", "custom/build_progress"],
  "modules-center": ["hyprland/window"],
  "modules-right": ["custom/system_tasks", "cpu", "memory", "network", "tray"],
  
  "custom/pacman_progress": {
    "format": "📦 {}",
    "escape": true,
    "return-type": "json",
    "exec": "~/.config/waybar/scripts/pacman-progress.sh",
    "interval": 2,
    "on-click": "alacritty -e pacman -Qu"
  },
  
  "custom/build_progress": {
    "format": "🔨 {}",
    "exec": "~/.config/waybar/scripts/build-progress.sh",
    "interval": 3,
    "return-type": "json"
  },
  
  "custom/system_tasks": {
    "format": "⚙️ {}",
    "exec": "~/.config/waybar/scripts/system-tasks.sh",
    "interval": 5,
    "return-type": "json"
  }
}
```

### Style (`~/.config/waybar/style.css`):

```css
* {
  font-family: "JetBrainsMono Nerd Font", monospace;
  font-size: 14px;
}

window#waybar {
  background: rgba(30, 30, 46, 0.9);
  color: #cdd6f4;
  border-bottom: 2px solid #cba6f7;
}

#custom-pacman_progress {
  color: #f9e2af;
  background: rgba(249, 226, 175, 0.1);
  padding: 0 10px;
}

#custom-build_progress {
  color: #89b4fa;
  background: rgba(137, 180, 250, 0.1);
  padding: 0 10px;
}

#custom-system_tasks {
  color: #a6e3a1;
  background: rgba(166, 227, 161, 0.1);
  padding: 0 10px;
}

#cpu, #memory, #network {
  padding: 0 10px;
  margin: 0 2px;
}

#cpu { color: #f38ba8; }
#memory { color: #fab387; }
#network { color: #89dceb; }
```

---

## 📦 **Solution 2: Pacman Progress Hook**

### Create Progress Script (`/usr/share/libalpm/hooks/progress.hook`):

```ini
[Trigger]
Operation = Install
Operation = Upgrade
Operation = Remove
Type = Package
Target = *

[Action]
Description = Notifying progress...
When = PreTransaction
Exec = /usr/local/bin/notify-progress start pacman
When = PostTransaction
Exec = /usr/local/bin/notify-progress end pacman
```

### Create Notification Script (`/usr/local/bin/notify-progress`):

```bash
#!/bin/bash

ACTION=$1
TASK=$2

case $ACTION in
  start)
    notify-send -u low -t 0 -h int:value:0 -h string:x-canonical-private-synchronous:system-tasks \
      "📦 $TASK Started" "Package operation in progress..."
    ;;
  end)
    notify-send -u low -t 3000 -h string:x-canonical-private-synchronous:system-tasks \
      "✅ $TASK Complete" "Operation finished successfully!"
    ;;
  update)
    PERCENT=$3
    notify-send -u low -t 0 -h int:value:$PERCENT -h string:x-canonical-private-synchronous:system-tasks \
      "📦 $TASK" "Progress: $PERCENT%"
    ;;
esac
```

---

## 🔨 **Solution 3: Build Progress Monitor**

### Create Build Monitor Script (`~/.local/bin/build-monitor`):

```bash
#!/bin/bash

# Monitor cargo, gradle, npm builds and show progress

WATCH_DIRS=("/home/ph/GhostWire-secure-mesh-communication")
LOG_FILE="/tmp/build-progress.log"

monitor_builds() {
  while true; do
    # Check for cargo builds
    if pgrep -x "cargo" > /dev/null; then
      PROGRESS=$(ps aux | grep -E "cargo.*build" | wc -l)
      echo "{\"text\": \"🦀 $PROGRESS builds\", \"tooltip\": \"Cargo builds running\", \"class\": \"warning\"}"
    # Check for gradle
    elif pgrep -x "gradle" > /dev/null; then
      echo "{\"text\": \"🐘 Gradle building\", \"tooltip\": \"Android build in progress\", \"class\": \"warning\"}"
    # Check for npm
    elif pgrep -x "npm" > /dev/null; then
      echo "{\"text\": \"📦 npm install\", \"tooltip\": \"Installing dependencies\", \"class\": \"warning\"}"
    else
      echo "{\"text\": \"\", \"tooltip\": \"No builds running\"}"
    fi
    sleep 3
  done
}

monitor_builds
```

### Make Executable:
```bash
chmod +x ~/.local/bin/build-monitor
```

---

## 📊 **Solution 4: System-Wide Task Monitor**

### Create System Task Monitor (`~/.config/waybar/scripts/system-tasks.sh`):

```bash
#!/bin/bash

# Count active system tasks
PACMAN_LOCK="/var/lib/pacman/db.lck"
CARGO_LOCKS=$(find /home -name "Cargo.lock" -mmin -5 2>/dev/null | wc -l)
GRADLE_DAEMONS=$(pgrep -f "gradle" | wc -l)
NPM_PROCESSES=$(pgrep -f "npm" | wc -l)
DOWNLOADS=$(pgrep -f "wget|curl|aria2" | wc -l)

TOTAL=$((CARGO_LOCKS + GRADLE_DAEMONS + NPM_PROCESSES + DOWNLOADS))

if [ -f "$PACMAN_LOCK" ]; then
  echo "{\"text\": \"📦 Pacman\", \"tooltip\": \"Package manager active\", \"class\": \"critical\"}"
elif [ $TOTAL -gt 0 ]; then
  echo "{\"text\": \"⚙️ $TOTAL tasks\", \"tooltip\": \"$CARGO_LOCKS cargo, $GRADLE_DAEMONS gradle, $NPM_PROCESSES npm, $DOWNLOADS downloads\", \"class\": \"warning\"}"
else
  echo "{\"text\": \"✓\", \"tooltip\": \"All systems idle\", \"class\": \"good\"}"
fi
```

---

## 🎨 **Solution 5: Desktop Notifications with Progress**

### Install Dependencies:
```bash
sudo pacman -S libnotify dunst
```

### Create Progress Notification Function (`~/.bashrc` or `~/.zshrc`):

```bash
# Add to your shell config

progress_notify() {
  local task="$1"
  local duration="$2"
  
  (
    for i in $(seq 0 10 100); do
      notify-send -u low -t 0 -h int:value:$i -h string:x-canonical-private-synchronous:progress \
        "🔄 $task" "Progress: $i%"
      sleep $((duration / 10))
    done
    notify-send -u low -t 3000 -h string:x-canonical-private-synchronous:progress \
      "✅ $task Complete" "Finished successfully!"
  ) &
}

# Usage example:
# progress_notify "Building project" 30
```

---

## 🔧 **Solution 6: Pacman Wrapper with Progress**

### Create Wrapper Script (`/usr/local/bin/pacman-progress`):

```bash
#!/bin/bash

# Wrapper for pacman with progress notifications

LOCK_FILE="/var/lib/pacman/db.lck"

# Check if pacman is running
if [ -f "$LOCK_FILE" ]; then
  echo "⚠️  Pacman is already running!"
  pgrep -a pacman
  exit 1
fi

# Start notification
notify-send -u low -t 0 -h string:x-canonical-private-synchronous:pacman \
  "📦 Pacman Starting" "Package operation beginning..."

# Run pacman with progress
sudo pacman "$@" 2>&1 | while read line; do
  echo "$line"
  # Parse progress from pacman output
  if [[ $line =~ \([0-9]+/[0-9]+\) ]]; then
    PROGRESS=$(echo "$line" | grep -oP '\(\K[0-9]+(?=/)')
    TOTAL=$(echo "$line" | grep -oP '(?<=/)[0-9]+(?=\))')
    PERCENT=$((PROGRESS * 100 / TOTAL))
    notify-send -u low -t 0 -h int:value:$PERCENT -h string:x-canonical-private-synchronous:pacman \
      "📦 Installing" "$PROGRESS/$TOTAL packages ($PERCENT%)"
  fi
done

# Complete notification
notify-send -u low -t 5000 -h string:x-canonical-private-synchronous:pacman \
  "✅ Pacman Complete" "Package operation finished!"
```

---

## 🎯 **Complete Integration Example**

### Create Master Monitor Script (`~/.local/bin/system-monitor-all`):

```bash
#!/bin/bash

# Comprehensive system monitor for top bar

WAYBAR_SCRIPT_DIR="$HOME/.config/waybar/scripts"

# Ensure scripts directory exists
mkdir -p "$WAYBAR_SCRIPT_DIR"

# Create pacman progress script
cat > "$WAYBAR_SCRIPT_DIR/pacman-progress.sh" << 'EOF'
#!/bin/bash
if [ -f /var/lib/pacman/db.lck ]; then
  PID=$(pgrep pacman | head -1)
  if [ -n "$PID" ]; then
    echo "{\"text\": \"📦 Running\", \"tooltip\": \"Pacman PID: $PID\", \"class\": \"warning\"}"
  else
    echo "{\"text\": \"📦 Locked\", \"tooltip\": \"Database locked\", \"class\": \"critical\"}"
  fi
else
  echo "{\"text\": \"✓\", \"tooltip\": \"No package operations\", \"class\": \"good\"}"
fi
EOF
chmod +x "$WAYBAR_SCRIPT_DIR/pacman-progress.sh"

# Create build progress script
cat > "$WAYBAR_SCRIPT_DIR/build-progress.sh" << 'EOF'
#!/bin/bash
CARGO=$(pgrep -c cargo 2>/dev/null || echo 0)
GRADLE=$(pgrep -c gradle 2>/dev/null || echo 0)
NPM=$(pgrep -c npm 2>/dev/null || echo 0)
TOTAL=$((CARGO + GRADLE + NPM))

if [ $TOTAL -gt 0 ]; then
  echo "{\"text\": \"🔨 $TOTAL\", \"tooltip\": \"Cargo: $CARGO, Gradle: $GRADLE, NPM: $NPM\", \"class\": \"warning\"}"
else
  echo "{\"text\": \"\", \"tooltip\": \"No builds running\"}"
fi
EOF
chmod +x "$WAYBAR_SCRIPT_DIR/build-progress.sh"

# Create system tasks script
cat > "$WAYBAR_SCRIPT_DIR/system-tasks.sh" << 'EOF'
#!/bin/bash
DOWNLOADS=$(pgrep -c "wget|curl|aria2|firefox|chrome" 2>/dev/null || echo 0)
UPDATES=$(checkupdates 2>/dev/null | wc -l || echo 0)

if [ $UPDATES -gt 0 ]; then
  echo "{\"text\": \"🔄 $UPDATES\", \"tooltip\": \"$UPDATES updates available\", \"class\": \"info\"}"
elif [ $DOWNLOADS -gt 0 ]; then
  echo "{\"text\": \"📥 $DOWNLOADS\", \"tooltip\": \"$DOWNLOADS downloads active\", \"class\": \"warning\"}"
else
  echo "{\"text\": \"✓\", \"tooltip\": \"System idle\"}"
fi
EOF
chmod +x "$WAYBAR_SCRIPT_DIR/system-tasks.sh"

echo "✅ System monitor scripts created!"
echo "📍 Location: $WAYBAR_SCRIPT_DIR"
echo ""
echo "Restart waybar to apply:"
echo "  killall waybar && waybar &"
```

### Run the Setup:
```bash
chmod +x ~/.local/bin/system-monitor-all
~/.local/bin/system-monitor-all
```

---

## 🎨 **Theme Integration**

### Catppuccin Theme for Waybar:

```css
/* ~/.config/waybar/catppuccin.css */

@define-color rosewater #f5e0dc;
@define-color flamingo #f2cdcd;
@define-color pink #f5c2e7;
@define-color mauve #cba6f7;
@define-color red #f38ba8;
@define-color maroon #eba0ac;
@define-color peach #fab387;
@define-color yellow #f9e2af;
@define-color green #a6e3a1;
@define-color teal #94e2d5;
@define-color sky #89dceb;
@define-color sapphire #74c7ec;
@define-color blue #89b4fa;
@define-color lavender #b4befe;
@define-color text #cdd6f4;
@define-color subtext1 #bac2de;
@define-color subtext0 #a6adc8;
@define-color overlay2 #9399b2;
@define-color overlay1 #7f849c;
@define-color overlay0 #6c7086;
@define-color surface2 #585b70;
@define-color surface1 #45475a;
@define-color surface0 #313244;
@define-color base #1e1e2e;
@define-color mantle #181825;
@define-color crust #11111b;

window#waybar {
  background: @base;
  color: @text;
  border-bottom: 2px solid @mauve;
}
```

---

## 📊 **Final Result**

Your top bar will show:

```
[Workspaces] [📦 Pacman] [🔨 2 builds] [Window Title] [⚙️ 3 tasks] [CPU 45%] [RAM 62%] [🌐 WiFi] [🔊 80%] [📅 12:34]
```

With real-time updates on:
- Package manager activity
- Build processes
- Download progress
- System resources
- Background tasks

---

## 🔗 **Quick Setup Commands**

```bash
# 1. Install waybar
sudo pacman -S waybar

# 2. Create config directory
mkdir -p ~/.config/waybar/scripts

# 3. Copy example configs
cp /etc/xdg/waybar/config ~/.config/waybar/
cp /etc/xdg/waybar/style.css ~/.config/waybar/

# 4. Create monitor scripts
~/.local/bin/system-monitor-all

# 5. Restart waybar
killall waybar && waybar &

# 6. Test notifications
notify-send "Test" "System monitor active!"
```

---

**Status:** Ready to implement  
**Compatibility:** Arch Linux, Hyprland, Wayland  
**Theme:** Catppuccin (customizable)
