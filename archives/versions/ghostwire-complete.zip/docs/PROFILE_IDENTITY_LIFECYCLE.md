# Profile & Identity Lifecycle

A **profile** is the user’s identity in GhostWire: one keypair, one nickname, one vault. This doc describes creation, use, and deletion.

---

## Storage layout

- **Identity file**: `~/.ghostwire/identity.json` (default profile) or `~/.ghostwire/identity_{name}.json`.
- **Vault (Sled DB)**: `~/.ghostwire/vault/ghost_default` or `~/.ghostwire/vault/ghost_{name}`.
- If `GHOSTWIRE_HOME` is set, that directory is used instead of `~/.ghostwire`.

---

## Lifecycle

### 1. Create profile

- **POST /api/profile/create**  
  Body: `{ "name": "alice" }` or one-step: `{ "name": "alice", "nickname": "Alice", "password": "secret123" }`.
- Without nickname/password: creates identity file with default password `ghostwire`; user should **switch** to the profile then run **setup**.
- With nickname + password (min 8 chars): creates and secures in one step; no setup needed.
- Name `"default"` creates `identity.json` (single default profile).

### 2. List profiles

- **GET /api/profile/list**  
  Returns `{ "profiles": ["default", "alice"], "current": "default" }`.  
  Scans `~/.ghostwire` for `identity.json` and `identity_*.json`.

### 3. Switch profile

- **POST /api/profile/select**  
  Body: `{ "profile_name": "alice" }` or `"default"`.
- Shuts down current Core, loads the selected profile’s identity, starts Core again.  
  Current profile is the one in use until next switch.

### 4. First-time setup (if created without password)

- **POST /api/identity/setup**  
  Body: `{ "nickname": "Alice", "password": "your_password" }` (password min 8 chars).
- Unlocks with default `ghostwire`, sets nickname and `setup_complete`, re-saves with the given password.

### 5. Unlock / lock

- **POST /api/v2/profile/unlock**  
  Body: `{ "password": "..." }`.  
  Loaded identity starts locked; unlock to use keys (mesh, sign, etc.).
- **POST /api/v2/profile/lock**  
  Clears key material from memory; use unlock to use again.

### 6. Profile status

- **GET /api/v2/profile/status**  
  Returns `{ "locked": true|false, "profile": "default"|"alice" }`.

### 7. Read profile

- **GET /api/v2/profile**  
  Returns id, did, username (= nickname), nickname, bio, public_key, key_id, created_at, dht_published, security_score, setup_complete.  
  All from identity metadata (no `username.txt`).

### 8. Update profile

- **PUT /api/v2/profile/metadata**  
  Body: `{ "nickname": "...", "bio": "...", "avatar_url": "..." }`.  
  Updates in memory only.
- **PUT /api/v2/profile/username**  
  Same as setting nickname.
- **POST /api/v2/profile/save**  
  Body: `{ "password": "..." }`.  
  Persists current identity (including metadata) to disk. Call after edits so they survive restart.

### 9. Delete / purge profile

- **DELETE /api/profile/delete/:name**  
  Deletes identity file and vault dir for that profile.  
  Cannot delete the **active** profile; switch first.
- **POST /api/system/wipe**  
  Emergency: removes entire `~/.ghostwire` (or `GHOSTWIRE_HOME`) and exits.

---

## Summary

| Step           | API / action |
|----------------|--------------|
| Create         | POST /api/profile/create |
| List           | GET /api/profile/list |
| Switch         | POST /api/profile/select |
| Setup (first time) | POST /api/identity/setup |
| Unlock / lock  | POST /api/v2/profile/unlock, POST /api/v2/profile/lock |
| Status         | GET /api/v2/profile/status |
| Read           | GET /api/v2/profile |
| Update         | PUT /api/v2/profile/metadata, PUT /api/v2/profile/username |
| Persist        | POST /api/v2/profile/save |
| Delete         | DELETE /api/profile/delete/:name |
| Emergency wipe | POST /api/system/wipe |

Profile = identity: one profile, one identity file, one vault, one nickname and keypair.
