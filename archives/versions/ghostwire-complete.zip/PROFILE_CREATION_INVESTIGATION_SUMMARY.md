# Profile Creation Error Investigation - Summary

**Date:** February 28, 2026  
**Issue:** "Profile creation failed" error on both PC and Android  
**Status:** ✅ Enhanced logging implemented, ready for debugging

---

## 🔍 Investigation Findings

### Root Cause Analysis

The error message "Profile creation failed" was too generic to identify the actual problem. The underlying issue could be any of:

1. **Directory Permission Issues** - Cannot create or write to `~/.ghostwire`
2. **Home Directory Detection Failure** - `dirs::home_dir()` returns `None`
3. **Invalid Profile Name** - Contains disallowed characters
4. **Profile Already Exists** - Name collision
5. **Encryption Failure** - Memory or RNG issues
6. **Disk Space Issues** - No space left on device

### Code Flow

```
User Input (Profile Name)
    ↓
Frontend: LoginScreen.tsx → api.createProfile()
    ↓
Backend: POST /api/v2/profile
    ↓
ProfilesController::create()
    ↓
1. Validate name (alphanumeric, _, -)
2. Check ghostwire directory
3. Check if profile exists
4. Identity::new() or Identity::create_with_setup()
    ↓
5. get_storage_path() → Determine file location
6. save_to_disk() → Encrypt and write file
    ↓
Success/Error Response
```

---

## ✅ Changes Implemented

### 1. Backend Enhanced Logging

#### File: `ghostwire/src/controllers/profiles.rs`

**Added 7-step logging process:**
1. 📝 Log request details (profile name, nickname, password)
2. ✅ Validate name with detailed error logging
3. 📂 Check ghostwire directory (existence, permissions)
4. 🔍 Check if profile already exists
5. 🔧 Log creation attempt type (basic or with setup)
6. 🔐 Track encryption process
7. ✅/❌ Log success or detailed error with debug info

**Key improvements:**
- Tests directory writability before attempting file operations
- Logs full error chain with `error_debug` and `error_cause`
- Uses `target: "profile_creation"` for easy filtering

#### File: `ghostwire/src/core/identity/core_identity.rs`

**Enhanced functions:**
- `load_or_create()` - Logs profile loading/creation decision
- `get_storage_path()` - Tracks GHOSTWIRE_HOME vs default, directory creation
- `save_to_disk()` - Logs encryption and file write operations

**Key improvements:**
- Logs when GHOSTWIRE_HOME environment variable is used
- Shows full path before attempting file operations
- Tracks encryption process steps

### 2. Frontend Enhanced Logging

#### File: `webui/src/components/LoginScreen.tsx`

**Improved error handling:**
```typescript
const handleCreateProfile = async (e: React.FormEvent) => {
    setError(''); // Clear previous errors
    try {
        console.log('📝 Creating profile:', newProfileName);
        const success = await api.createProfile(newProfileName);
        if (success) {
            console.log('✅ Profile created successfully');
            await handleSelectProfile(newProfileName);
        } else {
            setError('Profile creation failed. Check backend logs for details.');
        }
    } catch (err: any) {
        const errorMsg = err?.message || 'Creation error: Unable to connect to backend';
        console.error('❌ Profile creation exception:', err);
        setError(errorMsg);
    }
};
```

**Key improvements:**
- Clears previous errors before new attempts
- Shows more descriptive error messages
- Logs to console for debugging

### 3. Documentation

#### File: `PROFILE_CREATION_DEBUG_GUIDE.md`

**Comprehensive 8-page guide including:**
- Step-by-step debugging instructions
- Common error patterns and solutions
- PC and Android-specific troubleshooting
- Log analysis scripts
- Quick test commands

---

## 🛠️ How to Use

### On PC (Linux)

```bash
# 1. Start with enhanced logging
cd /home/ph/GhostWire-secure-mesh-communication/ghostwire
RUST_LOG=info,profile_creation=info,identity=info cargo run --release 2>&1 | tee ghostwire.log

# 2. In another terminal, watch logs in real-time
tail -f ghostwire.log | grep -E "profile_creation|identity|ERROR"

# 3. Attempt profile creation via WebUI
# Open browser to http://localhost:8080
# Click "CREATE NEW PROFILE"
# Enter name and submit

# 4. Check logs for errors
cat ghostwire.log | grep -A 5 "CRITICAL"
```

### On Android (via ADB)

```bash
# 1. Connect device
adb devices

# 2. Start logcat
adb logcat -s GhostWire:* > android_logs.txt

# 3. Attempt profile creation in app

# 4. Analyze logs
cat android_logs.txt | grep -i "error\|failed\|critical"
```

### Analyze Logs

```bash
# Use the provided analysis script
cd /home/ph/GhostWire-secure-mesh-communication
./analyze_logs.sh ghostwire.log

# Or manually check for specific errors
grep "CRITICAL" ghostwire.log
grep "Directory not writable" ghostwire.log
grep "Could not find home directory" ghostwire.log
```

---

## 📋 Common Errors & Quick Fixes

### Error: "Cannot create data directory"

```bash
# Check permissions
ls -la ~/.ghostwire

# Fix permissions
chmod -R 755 ~/.ghostwire
chown -R $USER:$USER ~/.ghostwire
```

### Error: "Directory not writable"

```bash
# Test write access
touch ~/.ghostwire/test_file

# If fails, check:
# 1. Disk space: df -h
# 2. Mount options: mount | grep home
# 3. SELinux: getenforce
```

### Error: "Could not find home directory"

```bash
# Check HOME environment
echo $HOME

# Set GHOSTWIRE_HOME explicitly
export GHOSTWIRE_HOME=/path/to/ghostwire/data
```

### Error: "Profile already exists"

```bash
# List existing profiles
ls -la ~/.ghostwire/identity*.json

# Remove if desired
rm ~/.ghostwire/identity_<profile_name>.json
```

---

## 🎯 Next Steps

1. **Build and Test**
   ```bash
   cd /home/ph/GhostWire-secure-mesh-communication/ghostwire
   cargo build --release
   ```

2. **Run with Logging**
   ```bash
   RUST_LOG=info,profile_creation=debug,identity=debug cargo run --release
   ```

3. **Attempt Profile Creation**
   - Open WebUI
   - Try to create a profile
   - Watch the logs

4. **Identify the Error**
   - Look for `CRITICAL` or `ERROR` in logs
   - Match against "Common Errors & Quick Fixes"
   - Apply the fix

5. **Verify Success**
   - Should see: `✅ Profile created successfully`
   - Check `~/.ghostwire/identity_<name>.json` exists

---

## 📞 Support

If issues persist after following this guide:

1. **Collect:**
   - `ghostwire.log` or `android_logs.txt`
   - OS and version
   - Storage type (internal/SD/network)

2. **Share:**
   - Error messages from logs
   - Steps taken to reproduce
   - Any relevant system information

---

## 🔗 Related Files

- **Backend Controller:** `ghostwire/src/controllers/profiles.rs`
- **Identity Core:** `ghostwire/src/core/identity/core_identity.rs`
- **Frontend Component:** `webui/src/components/LoginScreen.tsx`
- **API Service:** `webui/src/services/api.ts`
- **Debug Guide:** `PROFILE_CREATION_DEBUG_GUIDE.md`

---

**Status:** ✅ Ready for testing  
**Impact:** High - affects both PC and Android users  
**Priority:** Critical - blocks initial user onboarding
