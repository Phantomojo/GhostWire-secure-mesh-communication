# GhostWire Profile Creation Error - Setup Complete ✅

**Date:** February 28, 2026  
**Status:** Enhanced logging implemented and tested successfully  
**Platforms:** PC (✅ Ready), Android (⚠️ Needs ARM build)

---

## 🎯 What Was Done

### 1. Enhanced Backend Logging ✅

**Modified Files:**
- `ghostwire/src/controllers/profiles.rs` - Added 7-step detailed logging
- `ghostwire/src/core/identity/core_identity.rs` - Enhanced path and encryption logging

**New Log Messages:**
```
📝 Profile creation request received
📂 Checking ghostwire directory
🔍 Checking if profile exists
🔧 Creating profile
🆕 Creating basic profile (no nickname/password)
✅ Profile created successfully
❌ CRITICAL: Profile creation failed (with detailed error)
```

### 2. Enhanced Frontend Error Handling ✅

**Modified Files:**
- `webui/src/components/LoginScreen.tsx` - Better error messages
- `webui/src/services/api.ts` - Fixed endpoint URL

**Improvements:**
- Clears previous errors before new attempts
- Shows descriptive error messages
- Logs to console for debugging

### 3. PC Build Completed ✅

**Binary Location:**
```
/home/ph/GhostWire-secure-mesh-communication/ghostwire/target/release/ghostwire
```

**Size:** 20MB  
**Status:** Built successfully with enhanced logging

### 4. Android Deployment ⚠️

**Status:** Backend deployed but needs ARM build
- Current binary: x86_64 (PC architecture)
- Android device: ARM64 (requires cross-compilation)
- Existing app: `org.ghostwire.messenger` (already installed)

**Deployed File:**
```
/data/local/tmp/ghostwire (on Android device)
```

---

## 🧪 Testing Results

### PC Test - SUCCESS ✅

```bash
# Command
curl -X POST http://localhost:8080/api/profile/create \
  -H "Content-Type: application/json" \
  -H "X-Ghost-Token: eOAL2kTExt70taE71HmYh1wWZ5eD8T3W" \
  -d '{"name": "Test5"}'

# Response
{
  "version": "2.0",
  "data": {
    "status": "created",
    "profile": "Test5",
    "message": "Profile created; switch to it and run setup to set nickname and password"
  }
}
```

**Logs Show:**
```
INFO profile_creation: 📝 Profile creation request received
INFO profile_creation: 📂 Checking ghostwire directory
INFO profile_creation: 🔍 Checking if profile exists
INFO profile_creation: 🔧 Creating profile
INFO profile_creation: 🆕 Creating basic profile (no nickname/password)
INFO profile_creation: ✅ Profile created successfully
```

---

## 🚀 How to Use

### On PC

#### Quick Start
```bash
cd /home/ph/GhostWire-secure-mesh-communication

# Start with enhanced logging
./start-ghostwire-debug.sh

# Or manually
cd ghostwire
RUST_LOG=info,profile_creation=debug,identity=debug \
  ./target/release/ghostwire
```

#### Test Profile Creation
```bash
# Get auth token
cat ~/.config/ghostwire/token

# Create profile
curl -X POST http://localhost:8080/api/profile/create \
  -H "Content-Type: application/json" \
  -H "X-Ghost-Token: YOUR_TOKEN" \
  -d '{"name": "MyProfile"}'
```

#### View Logs
```bash
# Real-time
tail -f logs/ghostwire_*.log | grep -E "profile_creation|identity"

# Search for errors
grep "CRITICAL\|ERROR" logs/ghostwire_*.log
```

### On Android

#### Option 1: Use Existing App
The app `org.ghostwire.messenger` is already installed. The frontend code has been updated with better error handling. Rebuild and deploy:

```bash
cd /home/ph/GhostWire-secure-mesh-communication/webui

# Build frontend
npm run build

# Build Android app (requires Android NDK)
npx tauri android build --release

# Deploy
adb install -r target/aarch64-linux-android/release/app.apk
```

#### Option 2: Run Backend Separately (Requires ARM Build)
```bash
# Cross-compile for ARM (requires Android NDK)
export ANDROID_NDK_HOME=/path/to/ndk
rustup target add aarch64-linux-android
cd ghostwire
cargo build --release --target aarch64-linux-android

# Deploy to device
adb push target/aarch64-linux-android/release/ghostwire /data/local/tmp/
adb shell "chmod 755 /data/local/tmp/ghostwire"
adb shell "/data/local/tmp/ghostwire"

# View logs
adb logcat | grep -E "profile_creation|identity|RUST"
```

---

## 📋 Common Errors & Solutions

### Error: "Cannot create data directory"

**Log Message:**
```
❌ CRITICAL: Cannot create ghostwire directory
error="Permission denied (os error 13)"
```

**Solution:**
```bash
# Fix permissions
chmod -R 755 ~/.ghostwire
chown -R $USER:$USER ~/.ghostwire

# Or recreate
rm -rf ~/.ghostwire
mkdir -p ~/.ghostwire
```

### Error: "Directory not writable"

**Log Message:**
```
❌ CRITICAL: Directory not writable
error="Permission denied (os error 13)"
```

**Solution:**
```bash
# Check mount options
mount | grep home

# Check SELinux (if enabled)
getenforce

# Temporarily disable for testing
setenforce 0
```

### Error: "Could not find home directory"

**Log Message:**
```
🏠 Using default home directory
❌ CRITICAL: Profile creation failed
error="Could not find home directory"
```

**Solution:**
```bash
# Set HOME explicitly
export HOME=/home/yourusername

# Or set GHOSTWIRE_HOME
export GHOSTWIRE_HOME=/path/to/ghostwire/data
```

### Error: "Profile already exists"

**Log Message:**
```
⚠️ Profile already exists
profile_name="TestProfile"
```

**Solution:**
```bash
# List existing profiles
ls -la ~/.ghostwire/identity_*.json

# Remove if desired
rm ~/.ghostwire/identity_TestProfile.json

# Or choose different name
```

### Error: "Invalid profile name"

**Log Message:**
```
❌ Invalid profile name
profile_name="Test Profile"
reason="Contains invalid characters"
```

**Solution:**
Use only: `a-z`, `A-Z`, `0-9`, `_`, `-`

**Examples:**
- ✅ `Ghost_Operator`
- ✅ `Shadow-Runner`
- ❌ `Ghost Operator` (space not allowed)

---

## 🔧 Debugging Tools

### Diagnostic Script
```bash
cd /home/ph/GhostWire-secure-mesh-communication
./debug_profile_creation.sh
```

**Checks:**
- ✅ Directory existence
- ✅ Permissions
- ✅ Disk space
- ✅ Environment variables
- ✅ Running processes
- ✅ Endpoint connectivity

### Log Analysis
```bash
# Create analysis script
cat > analyze_logs.sh << 'EOF'
#!/bin/bash
LOG_FILE="${1:-logs/ghostwire_*.log}"
echo "=== Profile Creation Analysis ==="
echo "📝 Requests:"
grep "📝 Profile creation" $LOG_FILE | tail -5
echo ""
echo "❌ Errors:"
grep "❌" $LOG_FILE | tail -10
echo ""
echo "✅ Successes:"
grep "✅" $LOG_FILE | tail -5
EOF
chmod +x analyze_logs.sh

# Run
./analyze_logs.sh
```

---

## 📊 What's Next

### Immediate Actions

1. **Test on PC** - Try creating a profile via WebUI and check logs
2. **Share Logs** - If error occurs, share the detailed logs
3. **Android NDK** - Install if Android-specific testing needed

### Android NDK Installation (Optional)

```bash
# Download NDK
cd /tmp
wget https://dl.google.com/android/repository/android-ndk-r27c-linux.zip
unzip android-ndk-r27c-linux.zip -d /opt/
export ANDROID_NDK_HOME=/opt/android-ndk-r27c

# Or use sdkmanager
sdkmanager "ndk;27.0.12077973"
```

---

## 📞 Support

### Collect These for Debugging

1. **Log File:** `logs/ghostwire_YYYYMMDD_HHMMSS.log`
2. **OS Info:** `uname -a`
3. **Disk Space:** `df -h ~/.ghostwire`
4. **Permissions:** `ls -la ~/.ghostwire`

### Quick Commands

```bash
# PC - Start with logging
./start-ghostwire-debug.sh

# PC - Test profile creation
curl -X POST http://localhost:8080/api/profile/create \
  -H "Content-Type: application/json" \
  -H "X-Ghost-Token: $(cat ~/.config/ghostwire/token)" \
  -d '{"name": "Test"}'

# Android - View app logs
adb logcat | grep -i ghostwire

# Android - View backend logs (if running separately)
adb shell logcat | grep RUST
```

---

## ✅ Summary

| Component | Status | Notes |
|-----------|--------|-------|
| PC Backend | ✅ Built | Enhanced logging active |
| PC Frontend | ✅ Updated | Better error messages |
| Android Backend | ⚠️ Deployed | x86_64 binary (won't run on ARM) |
| Android Frontend | ✅ Updated | Needs rebuild with NDK |
| Debug Scripts | ✅ Created | Ready for use |
| Documentation | ✅ Complete | Comprehensive guides |

---

**The enhanced logging is now active and tested. When you try to create a profile, the logs will show exactly where any error occurs!**

**Next Step:** Try creating a profile on PC and share the logs if you encounter the error.
