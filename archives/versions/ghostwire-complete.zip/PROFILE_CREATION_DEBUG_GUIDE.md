# Profile Creation Error - Debugging Guide

## Problem
Users are getting a "Profile creation failed" error on both PC and Android when trying to create a new profile.

## Solution Implemented

### 1. Enhanced Backend Logging ✅
Added comprehensive logging to track every step of profile creation:

**File: `ghostwire/src/controllers/profiles.rs`**
- Logs request details
- Validates profile name
- Checks ghostwire directory existence and permissions
- Tests directory writability
- Tracks profile existence check
- Logs creation attempt with full error details

**File: `ghostwire/src/core/identity/core_identity.rs`**
- Logs storage path determination
- Tracks GHOSTWIRE_HOME vs default home directory
- Logs directory creation
- Tracks file write operations
- Logs encryption process

### 2. Enhanced Frontend Logging ✅
**File: `webui/src/components/LoginScreen.tsx`**
- Logs profile creation attempts
- Shows detailed error messages
- Clears previous errors before new attempts

## How to Debug

### Step 1: Start Ghostwire with Logging

```bash
# Navigate to ghostwire directory
cd /home/ph/GhostWire-secure-mesh-communication/ghostwire

# Run with verbose logging
RUST_LOG=info,profile_creation=info,identity=info cargo run --release 2>&1 | tee ghostwire.log
```

### Step 2: Attempt Profile Creation

1. Open the GhostWire WebUI in your browser
2. Click "CREATE NEW PROFILE"
3. Enter a profile name (e.g., `Test_Profile`)
4. Click "CREATE PROFILE"

### Step 3: Check the Logs

Look for these log entries in `ghostwire.log`:

```
✅ SUCCESS EXAMPLE:
[INFO] profile_creation: 📝 Profile creation request received
[INFO] profile_creation: 📂 Checking ghostwire directory
[INFO] profile_creation: 🔍 Checking if profile exists
[INFO] profile_creation: 🔧 Creating profile
[INFO] profile_creation: ✅ Profile created successfully
```

```
❌ ERROR EXAMPLES:

Error 1: Cannot create directory
[ERROR] profile_creation: ❌ CRITICAL: Cannot create ghostwire directory
  directory="/home/ph/.ghostwire"
  error="Permission denied (os error 13)"

Error 2: Directory not writable
[ERROR] profile_creation: ❌ CRITICAL: Directory not writable
  directory="/home/ph/.ghostwire"
  error="Permission denied (os error 13)"

Error 3: Home directory not found
[ERROR] identity: 🏠 Using default home directory
[ERROR] profile_creation: ❌ CRITICAL: Profile creation failed
  error="Could not find home directory"

Error 4: Profile already exists
[WARN] profile_creation: ⚠️ Profile already exists
  profile_name="Test_Profile"

Error 5: Invalid profile name
[WARN] profile_creation: ❌ Invalid profile name
  profile_name="Test Profile"
  reason="Contains invalid characters"
```

## Common Issues & Fixes

### Issue 1: Permission Denied
**Symptom:** `Cannot create ghostwire directory` or `Directory not writable`

**Fix:**
```bash
# Check current permissions
ls -la ~/.ghostwire

# Fix permissions (if directory exists)
chmod -R 755 ~/.ghostwire
chown -R $USER:$USER ~/.ghostwire

# Or delete and recreate
rm -rf ~/.ghostwire
mkdir -p ~/.ghostwire
chmod 755 ~/.ghostwire
```

### Issue 2: Home Directory Not Found (Android)
**Symptom:** `Could not find home directory`

**Cause:** Android doesn't have a traditional home directory structure

**Fix:** Set GHOSTWIRE_HOME environment variable:
```bash
# For Android via ADB
export GHOSTWIRE_HOME=/data/data/com.ghostwire.app/files

# Or for SD card storage
export GHOSTWIRE_HOME=/sdcard/ghostwire

# Then restart the app
```

### Issue 3: Invalid Profile Name
**Symptom:** `Invalid profile name. Use alphanumeric, _, - only`

**Fix:** Use only these characters:
- Letters: a-z, A-Z
- Numbers: 0-9
- Underscore: _
- Hyphen: -

**Examples:**
- ✅ `Ghost_Operator`
- ✅ `Shadow-Runner`
- ✅ `Agent47`
- ❌ `Ghost Operator` (space not allowed)
- ❌ `Shadow@Runner` (@ symbol not allowed)

### Issue 4: Profile Already Exists
**Symptom:** `Profile already exists`

**Fix:**
```bash
# List existing profiles
ls -la ~/.ghostwire/identity*.json

# Delete the existing profile (if desired)
rm ~/.ghostwire/identity_Test_Profile.json

# Or choose a different profile name
```

### Issue 5: GHOSTWIRE_HOME Points to Wrong Location
**Symptom:** Logs show unexpected directory path

**Fix:**
```bash
# Check current setting
echo $GHOSTWIRE_HOME

# Unset to use default
unset GHOSTWIRE_HOME

# Or set to correct path
export GHOSTWIRE_HOME=/home/ph/.ghostwire
```

## Android-Specific Debugging

### Via ADB (USB)

```bash
# Connect to device
adb devices

# Start logcat to see app logs
adb logcat | grep -i ghostwire

# Or save to file
adb logcat -s GhostWire:* > android_logs.txt

# Attempt profile creation in the app
# Then check android_logs.txt for errors
```

### Check App Data Directory

```bash
# Open ADB shell
adb shell

# Navigate to app data
cd /data/data/com.ghostwire.app/files

# List contents
ls -la

# Check permissions
ls -ld /data/data/com.ghostwire.app/files
```

### Set GHOSTWIRE_HOME for Android

In the Tauri app (`src-tauri/src/lib.rs`), the GHOSTWIRE_HOME is already set to app data directory. If you need to change it:

```rust
// In setup function
sidecar_command = sidecar_command.env(
    "GHOSTWIRE_HOME", 
    "/sdcard/ghostwire"  // Change to SD card if internal storage is full
);
```

## PC-Specific Debugging

### Check System Logs

```bash
# Journalctl (systemd systems)
journalctl -f | grep ghostwire

# Or check dmesg for permission issues
dmesg | tail -50
```

### Verify Disk Space

```bash
# Check available space
df -h ~/.ghostwire

# Check inode availability
df -i ~/.ghostwire
```

### Test Manual Directory Creation

```bash
# Test if you can create the directory
mkdir -p ~/.ghostwire/test_dir

# If this fails, check:
# 1. Disk space: df -h
# 2. Permissions: ls -la ~ | grep ghostwire
# 3. SELinux/AppArmor: getenforce / aa-status
```

## Log Analysis Script

Save this as `analyze_logs.sh`:

```bash
#!/bin/bash

LOG_FILE="${1:-ghostwire.log}"

echo "=== Profile Creation Error Analysis ==="
echo "Log file: $LOG_FILE"
echo ""

echo "📝 Profile Creation Attempts:"
grep -i "profile creation" "$LOG_FILE" | tail -10
echo ""

echo "📂 Directory Issues:"
grep -i "directory\|permission\|writable" "$LOG_FILE" | tail -10
echo ""

echo "❌ Errors:"
grep -i "error\|failed\|critical" "$LOG_FILE" | tail -20
echo ""

echo "✅ Successes:"
grep -i "success\|created\|complete" "$LOG_FILE" | tail -10
```

Usage:
```bash
chmod +x analyze_logs.sh
./analyze_logs.sh ghostwire.log
```

## Quick Test

Run this to test profile creation directly:

```bash
# Test with curl
curl -X POST http://localhost:8080/api/v2/profile \
  -H "Content-Type: application/json" \
  -d '{"name": "Test_Profile"}'

# Expected success response:
{"version":"v2","timestamp":"...","request_id":"...","data":{"status":"created","profile":"Test_Profile",...}}

# Expected error response:
{"version":"v2","timestamp":"...","request_id":"...","error":{"code":"INTERNAL_ERROR","message":"Failed to create profile: ..."}}
```

## Next Steps

1. **Run with enhanced logging** and capture the output
2. **Identify the specific error** from the logs
3. **Apply the corresponding fix** from the "Common Issues & Fixes" section
4. **Test again** and verify success

## Support

If the issue persists after following this guide:

1. Collect logs: `ghostwire.log` and/or `android_logs.txt`
2. Note your environment:
   - OS: (Windows/Linux/macOS/Android)
   - Version: (e.g., Android 13, Ubuntu 22.04)
   - Storage: (Internal/SD card/Network drive)
3. Share the error message and logs for further assistance

---

**Last Updated:** February 28, 2026
**Version:** 1.0
