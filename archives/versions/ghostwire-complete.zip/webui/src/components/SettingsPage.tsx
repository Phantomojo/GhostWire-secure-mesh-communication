import { useState, useEffect } from 'react';
import { api } from '../services/api';

interface SettingsPageProps {
    backendConnected: boolean;
    onBack: () => void;
}

interface SettingsState {
    // Identity
    username: string;
    displayName: string;
    bio: string;

    // Network
    listenPort: number;
    enableMdns: boolean;
    enableDht: boolean;
    maxPeers: number;

    // Security
    encryptionLevel: 'standard' | 'enhanced' | 'quantum';
    autoLockMinutes: number;
    keyRotationDays: number;

    // Privacy
    stealthMode: boolean;
    trafficMorphing: boolean;
    stripMetadata: boolean;

    // Notifications
    soundEnabled: boolean;
    desktopNotifications: boolean;
    messagePreview: boolean;

    // Advanced
    debugMode: boolean;
    logLevel: 'info' | 'debug' | 'trace';
}

const defaultSettings: SettingsState = {
    username: '',
    displayName: '',
    bio: '',
    listenPort: 3001,
    enableMdns: true,
    enableDht: true,
    maxPeers: 50,
    encryptionLevel: 'enhanced',
    autoLockMinutes: 15,
    keyRotationDays: 30,
    stealthMode: false,
    trafficMorphing: false,
    stripMetadata: true,
    soundEnabled: true,
    desktopNotifications: true,
    messagePreview: true,
    debugMode: false,
    logLevel: 'info',
};

export default function SettingsPage({ backendConnected, onBack }: SettingsPageProps) {
    const [settings, setSettings] = useState<SettingsState>(defaultSettings);
    const [activeSection, setActiveSection] = useState<string>('identity');
    const [saving, setSaving] = useState(false);
    const [saved, setSaved] = useState(false);
    const [profiles, setProfiles] = useState<string[]>([]);
    const [currentProfile, setCurrentProfile] = useState<string | null>(null);

    // Load settings on mount
    useEffect(() => {
        if (backendConnected) {
            loadSettings();
            loadProfiles();
        }
    }, [backendConnected]);

    const loadProfiles = async () => {
        try {
            const data = await api.listProfiles();
            setProfiles(data.profiles);
            setCurrentProfile(data.current);
        } catch (error) {
            console.error('Failed to load profiles:', error);
        }
    };

    const loadSettings = async () => {
        try {
            const data = await api.get('/settings');
            if (data.success) {
                setSettings(prev => ({ ...prev, ...data.data }));
            }
        } catch (error) {
            console.error('Failed to load settings:', error);
        }
    };

    const saveSettings = async () => {
        setSaving(true);
        console.log('💾 Initiating settings save...', settings);

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

        try {
            await api.put('/settings', settings);
            console.log('✅ Settings save successful');
            setSaved(true);

            // Reload local profiles and trigger a potential global refresh
            await loadProfiles();

            setTimeout(() => setSaved(false), 2000);
        } catch (error: any) {
            console.error('❌ Failed to save settings:', error);
            if (error.name === 'AbortError') {
                alert('Save operation timed out. Backend might be unresponsive.');
            } else {
                alert(`Save failed: ${error.message}`);
            }
        } finally {
            clearTimeout(timeoutId);
            setSaving(false);
            console.log('🏁 Save operation finished');
        }
    };

    const updateSetting = <K extends keyof SettingsState>(key: K, value: SettingsState[K]) => {
        setSettings(prev => ({ ...prev, [key]: value }));
    };

    const handleDeleteProfile = async (name: string) => {
        if (!confirm(`Are you absolutely sure you want to delete profile "${name}"? This will purge all message history and keys for this identity.`)) {
            return;
        }

        const success = await api.deleteProfile(name);
        if (success) {
            alert(`Profile ${name} deleted successfully.`);
            loadProfiles();
        } else {
            alert(`Failed to delete profile ${name}. Check logs.`);
        }
    };

    const handleEmergencyWipe = async () => {
        if (!confirm('⚠️ CRITICAL WARNING: This will PERMANENTLY ERASE ALL PROFILES, message history, and settings on this machine. Proceed with emergency "Self-Destruct" wipe?')) {
            return;
        }

        if (!confirm('FINAL CONFIRMATION: You are about to wipe GhostWire entirely. Continue?')) {
            return;
        }

        const success = await api.wipeSystem();
        if (success) {
            alert('System wiped. The application will now terminate.');
            window.location.reload();
        }
    };

    const sections = [
        { id: 'profile', label: 'Profile', icon: '👤' },
        { id: 'network', label: 'Network', icon: '🌐' },
        { id: 'security', label: 'Security', icon: '🔐' },
        { id: 'privacy', label: 'Privacy', icon: '👁️' },
        { id: 'notifications', label: 'Notifications', icon: '🔔' },
        { id: 'advanced', label: 'Advanced', icon: '⚙️' },
    ];

    return (
        <div className="space-y-6 animate-fade-in">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <button
                        onClick={onBack}
                        className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                    >
                        ← Back
                    </button>
                    <h1 className="text-2xl font-bold text-white">Settings</h1>
                </div>
                <button
                    onClick={saveSettings}
                    disabled={saving}
                    className={`px-6 py-2 rounded-xl font-semibold transition-all ${saved
                        ? 'bg-emerald-500 text-white'
                        : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                        }`}
                >
                    {saving ? 'Saving...' : saved ? '✓ Saved' : 'Save Changes'}
                </button>
            </div>

            <div className="grid grid-cols-4 gap-6">
                {/* Sidebar Navigation */}
                <div className="col-span-1 space-y-2">
                    {sections.map(section => (
                        <button
                            key={section.id}
                            onClick={() => setActiveSection(section.id)}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${activeSection === section.id
                                ? 'bg-indigo-600/20 text-white border border-indigo-500/30'
                                : 'text-slate-400 hover:bg-white/5 hover:text-white'
                                }`}
                        >
                            <span className="text-xl">{section.icon}</span>
                            <span className="font-medium">{section.label}</span>
                        </button>
                    ))}
                </div>

                {/* Settings Content */}
                <div className="col-span-3 bg-slate-900/50 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
                    {/* Profile Section */}
                    {activeSection === 'profile' && (
                        <div className="space-y-8">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                👤 Sovereign Profile
                            </h2>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                <div className="space-y-4">
                                    <h3 className="text-sm font-bold text-white/40 uppercase tracking-widest">Metadata</h3>
                                    <div>
                                        <label className="block text-xs font-medium text-white/40 mb-2 uppercase">Username</label>
                                        <input
                                            type="text"
                                            value={settings.username}
                                            onChange={(e) => updateSetting('username', e.target.value)}
                                            className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-indigo-500 focus:outline-none"
                                            placeholder="your_username"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-xs font-medium text-white/40 mb-2 uppercase">Display Name</label>
                                        <input
                                            type="text"
                                            value={settings.displayName}
                                            onChange={(e) => updateSetting('displayName', e.target.value)}
                                            className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-indigo-500 focus:outline-none"
                                            placeholder="Your Display Name"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-xs font-medium text-white/40 mb-2 uppercase">Bio</label>
                                        <textarea
                                            value={settings.bio}
                                            onChange={(e) => updateSetting('bio', e.target.value)}
                                            className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-indigo-500 focus:outline-none resize-none h-24"
                                            placeholder="A short description about yourself..."
                                        />
                                    </div>
                                </div>

                                <div className="space-y-6 bg-indigo-500/5 p-6 rounded-2xl border border-indigo-500/10">
                                    <h3 className="text-sm font-bold text-indigo-400/80 uppercase tracking-widest">Cryptographic Credentials</h3>

                                    <div className="space-y-4">
                                        <div>
                                            <div className="flex justify-between items-center mb-1">
                                                <label className="block text-[10px] font-black text-white/30 uppercase tracking-tighter">Sovereign_DID</label>
                                                <button
                                                    onClick={() => {
                                                        const did = localStorage.getItem('ghostwire_did') || 'did:ghost:...';
                                                        navigator.clipboard.writeText(did);
                                                        alert('DID copied to clipboard');
                                                    }}
                                                    className="text-[10px] text-indigo-400 hover:text-white transition-colors"
                                                >
                                                    COPY
                                                </button>
                                            </div>
                                            <div className="bg-black/40 rounded-lg p-3 border border-white/5 text-[10px] font-mono text-slate-400 break-all select-all">
                                                {localStorage.getItem('ghostwire_did') || 'Establishing link...'}
                                            </div>
                                        </div>

                                        <div>
                                            <div className="flex justify-between items-center mb-1">
                                                <label className="block text-[10px] font-black text-white/30 uppercase tracking-tighter">Public_Key_Hex</label>
                                                <button
                                                    onClick={() => alert('Feature coming soon: Cross-Signing Keys')}
                                                    className="text-[10px] text-indigo-400 hover:text-white transition-colors"
                                                >
                                                    COPY
                                                </button>
                                            </div>
                                            <div className="bg-black/40 rounded-lg p-3 border border-white/5 text-[10px] font-mono text-slate-500 break-all opacity-60">
                                                0x736f7665726569676e5f6b65795f64617461...
                                            </div>
                                        </div>
                                    </div>

                                    <div className="pt-4 border-t border-white/5 space-y-3">
                                        <button
                                            onClick={() => alert('Generating cryptographic backup bundle...')}
                                            className="w-full py-2 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border border-indigo-500/20 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                                        >
                                            Export Profile Bundle
                                        </button>
                                        <p className="text-[9px] text-slate-500 text-center italic">
                                            Never share your private keys. GhostWire support will NEVER ask for your passphrase.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Network Section */}
                    {activeSection === 'network' && (
                        <div className="space-y-6">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                🌐 Network Settings
                            </h2>

                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-white/60 mb-2">Listen Port</label>
                                    <input
                                        type="number"
                                        value={settings.listenPort}
                                        onChange={(e) => updateSetting('listenPort', parseInt(e.target.value))}
                                        className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-indigo-500 focus:outline-none"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-white/60 mb-2">Max Peers</label>
                                    <input
                                        type="number"
                                        value={settings.maxPeers}
                                        onChange={(e) => updateSetting('maxPeers', parseInt(e.target.value))}
                                        className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-indigo-500 focus:outline-none"
                                    />
                                </div>

                                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                                    <div>
                                        <div className="text-white font-medium">mDNS Discovery</div>
                                        <div className="text-sm text-white/50">Auto-discover peers on local network</div>
                                    </div>
                                    <button
                                        onClick={() => updateSetting('enableMdns', !settings.enableMdns)}
                                        className={`w-14 h-8 rounded-full transition-colors ${settings.enableMdns ? 'bg-emerald-500' : 'bg-slate-700'
                                            }`}
                                    >
                                        <div className={`w-6 h-6 bg-white rounded-full transition-transform ${settings.enableMdns ? 'translate-x-7' : 'translate-x-1'
                                            }`} />
                                    </button>
                                </div>

                                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                                    <div>
                                        <div className="text-white font-medium">DHT Network</div>
                                        <div className="text-sm text-white/50">Distributed hash table for peer discovery</div>
                                    </div>
                                    <button
                                        onClick={() => updateSetting('enableDht', !settings.enableDht)}
                                        className={`w-14 h-8 rounded-full transition-colors ${settings.enableDht ? 'bg-emerald-500' : 'bg-slate-700'
                                            }`}
                                    >
                                        <div className={`w-6 h-6 bg-white rounded-full transition-transform ${settings.enableDht ? 'translate-x-7' : 'translate-x-1'
                                            }`} />
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Security Section */}
                    {activeSection === 'security' && (
                        <div className="space-y-6">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                🔐 Security Settings
                            </h2>

                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-white/60 mb-2">Encryption Level</label>
                                    <select
                                        value={settings.encryptionLevel}
                                        onChange={(e) => updateSetting('encryptionLevel', e.target.value as any)}
                                        className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-indigo-500 focus:outline-none"
                                    >
                                        <option value="standard">Standard (AES-256-GCM)</option>
                                        <option value="enhanced">Enhanced (ChaCha20-Poly1305)</option>
                                        <option value="quantum">Quantum-Resistant (Kyber)</option>
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-white/60 mb-2">Auto-Lock (minutes)</label>
                                    <input
                                        type="number"
                                        value={settings.autoLockMinutes}
                                        onChange={(e) => updateSetting('autoLockMinutes', parseInt(e.target.value))}
                                        className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-indigo-500 focus:outline-none"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-white/60 mb-2">Key Rotation (days)</label>
                                    <input
                                        type="number"
                                        value={settings.keyRotationDays}
                                        onChange={(e) => updateSetting('keyRotationDays', parseInt(e.target.value))}
                                        className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-indigo-500 focus:outline-none"
                                    />
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Privacy Section */}
                    {activeSection === 'privacy' && (
                        <div className="space-y-6">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                👁️ Privacy Settings
                            </h2>

                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                                    <div>
                                        <div className="text-white font-medium">Stealth Mode</div>
                                        <div className="text-sm text-white/50">Hide presence from network scans</div>
                                    </div>
                                    <button
                                        onClick={() => updateSetting('stealthMode', !settings.stealthMode)}
                                        className={`w-14 h-8 rounded-full transition-colors ${settings.stealthMode ? 'bg-emerald-500' : 'bg-slate-700'
                                            }`}
                                    >
                                        <div className={`w-6 h-6 bg-white rounded-full transition-transform ${settings.stealthMode ? 'translate-x-7' : 'translate-x-1'
                                            }`} />
                                    </button>
                                </div>

                                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                                    <div>
                                        <div className="text-white font-medium">Traffic Morphing</div>
                                        <div className="text-sm text-white/50">Disguise traffic patterns</div>
                                    </div>
                                    <button
                                        onClick={() => updateSetting('trafficMorphing', !settings.trafficMorphing)}
                                        className={`w-14 h-8 rounded-full transition-colors ${settings.trafficMorphing ? 'bg-emerald-500' : 'bg-slate-700'
                                            }`}
                                    >
                                        <div className={`w-6 h-6 bg-white rounded-full transition-transform ${settings.trafficMorphing ? 'translate-x-7' : 'translate-x-1'
                                            }`} />
                                    </button>
                                </div>

                                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                                    <div>
                                        <div className="text-white font-medium">Strip Metadata</div>
                                        <div className="text-sm text-white/50">Remove identifying info from messages</div>
                                    </div>
                                    <button
                                        onClick={() => updateSetting('stripMetadata', !settings.stripMetadata)}
                                        className={`w-14 h-8 rounded-full transition-colors ${settings.stripMetadata ? 'bg-emerald-500' : 'bg-slate-700'
                                            }`}
                                    >
                                        <div className={`w-6 h-6 bg-white rounded-full transition-transform ${settings.stripMetadata ? 'translate-x-7' : 'translate-x-1'
                                            }`} />
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Notifications Section */}
                    {activeSection === 'notifications' && (
                        <div className="space-y-6">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                🔔 Notification Settings
                            </h2>

                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                                    <div>
                                        <div className="text-white font-medium">Sound Effects</div>
                                        <div className="text-sm text-white/50">Play sounds for events</div>
                                    </div>
                                    <button
                                        onClick={() => updateSetting('soundEnabled', !settings.soundEnabled)}
                                        className={`w-14 h-8 rounded-full transition-colors ${settings.soundEnabled ? 'bg-emerald-500' : 'bg-slate-700'
                                            }`}
                                    >
                                        <div className={`w-6 h-6 bg-white rounded-full transition-transform ${settings.soundEnabled ? 'translate-x-7' : 'translate-x-1'
                                            }`} />
                                    </button>
                                </div>

                                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                                    <div>
                                        <div className="text-white font-medium">Desktop Notifications</div>
                                        <div className="text-sm text-white/50">Show system notifications</div>
                                    </div>
                                    <button
                                        onClick={() => updateSetting('desktopNotifications', !settings.desktopNotifications)}
                                        className={`w-14 h-8 rounded-full transition-colors ${settings.desktopNotifications ? 'bg-emerald-500' : 'bg-slate-700'
                                            }`}
                                    >
                                        <div className={`w-6 h-6 bg-white rounded-full transition-transform ${settings.desktopNotifications ? 'translate-x-7' : 'translate-x-1'
                                            }`} />
                                    </button>
                                </div>

                                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                                    <div>
                                        <div className="text-white font-medium">Message Preview</div>
                                        <div className="text-sm text-white/50">Show message content in notifications</div>
                                    </div>
                                    <button
                                        onClick={() => updateSetting('messagePreview', !settings.messagePreview)}
                                        className={`w-14 h-8 rounded-full transition-colors ${settings.messagePreview ? 'bg-emerald-500' : 'bg-slate-700'
                                            }`}
                                    >
                                        <div className={`w-6 h-6 bg-white rounded-full transition-transform ${settings.messagePreview ? 'translate-x-7' : 'translate-x-1'
                                            }`} />
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Advanced Section */}
                    {activeSection === 'advanced' && (
                        <div className="space-y-6">
                            <h2 className="text-xl font-bold text-white flex items-center gap-2">
                                ⚙️ Advanced Settings
                            </h2>

                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                                    <div>
                                        <div className="text-white font-medium">Debug Mode</div>
                                        <div className="text-sm text-white/50">Enable verbose logging</div>
                                    </div>
                                    <button
                                        onClick={() => updateSetting('debugMode', !settings.debugMode)}
                                        className={`w-14 h-8 rounded-full transition-colors ${settings.debugMode ? 'bg-yellow-500' : 'bg-slate-700'
                                            }`}
                                    >
                                        <div className={`w-6 h-6 bg-white rounded-full transition-transform ${settings.debugMode ? 'translate-x-7' : 'translate-x-1'
                                            }`} />
                                    </button>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-white/60 mb-2">Log Level</label>
                                    <select
                                        value={settings.logLevel}
                                        onChange={(e) => updateSetting('logLevel', e.target.value as any)}
                                        className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-indigo-500 focus:outline-none"
                                    >
                                        <option value="info">Info</option>
                                        <option value="debug">Debug</option>
                                        <option value="trace">Trace</option>
                                    </select>
                                </div>

                                <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-2xl space-y-4">
                                    <div className="text-red-400 font-bold flex items-center gap-2">
                                        <span className="text-lg">⚠️</span> DANGER ZONE
                                    </div>
                                    <div className="text-[10px] text-red-100/40 leading-relaxed uppercase tracking-tighter">
                                        The following actions are irreversible and will result in permanent data loss.
                                    </div>

                                    <div className="space-y-3">
                                        <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                                            <div className="flex justify-between items-center mb-3">
                                                <div>
                                                    <div className="text-xs font-black text-white/80 uppercase">Profile Deletion</div>
                                                    <div className="text-[9px] text-slate-500">Purge specific identity and vault files</div>
                                                </div>
                                            </div>

                                            <div className="space-y-2 max-h-40 overflow-y-auto pr-2 custom-scrollbar">
                                                {profiles.map(p => (
                                                    <div key={p} className="flex items-center justify-between p-2 bg-white/5 rounded-lg border border-white/5">
                                                        <div className="flex items-center gap-2">
                                                            <div className={`w-1.5 h-1.5 rounded-full ${p === currentProfile ? 'bg-indigo-500' : 'bg-slate-700'}`} />
                                                            <span className={`text-[11px] font-mono ${p === currentProfile ? 'text-indigo-400 font-bold' : 'text-slate-300'}`}>
                                                                {p} {p === currentProfile && '(Active)'}
                                                            </span>
                                                        </div>
                                                        <button
                                                            disabled={p === currentProfile}
                                                            onClick={() => handleDeleteProfile(p)}
                                                            className={`px-3 py-1 rounded-md text-[9px] font-black uppercase transition-all ${p === currentProfile
                                                                ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
                                                                : 'bg-red-500/20 text-red-400 hover:bg-red-500 hover:text-white'
                                                                }`}
                                                        >
                                                            PURGE
                                                        </button>
                                                    </div>
                                                ))}
                                                {profiles.length === 0 && (
                                                    <div className="text-center py-4 text-[10px] text-slate-600 italic">
                                                        No additional profiles detected
                                                    </div>
                                                )}
                                            </div>
                                        </div>

                                        <div className="bg-red-950/20 p-4 rounded-xl border border-red-500/20 flex items-center justify-between">
                                            <div>
                                                <div className="text-xs font-black text-red-400 uppercase">Emergency System Wipe</div>
                                                <div className="text-[9px] text-red-100/40">Total purge of .ghostwire directory and shutdown</div>
                                            </div>
                                            <button
                                                onClick={handleEmergencyWipe}
                                                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white rounded-lg transition-all text-[10px] font-black uppercase shadow-lg shadow-red-900/20"
                                            >
                                                SELF DESTRUCT
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
