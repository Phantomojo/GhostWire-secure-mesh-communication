# GHOSTWIRE WEBSITE - COMPLETE AI AGENT BRIEF
## Build Instructions for the Official GhostWire Project Site

**Version:** 1.0  
**Date:** March 2, 2026  
**Project:** GhostWire Secure Mesh Communication  
**Founder:** NGAIRURU (Nairobi, Kenya)  
**Site:** ghostwire.net (placeholder)

---

## PART 1: WHAT GHOSTWIRE ACTUALLY IS

### The Critical Context (READ THIS FIRST)

**GhostWire is NOT:**
- ❌ A SaaS product
- ❌ A subscription service
- ❌ A commercial app
- ❌ A startup trying to get users

**GhostWire IS:**
- ✅ Decentralized communication infrastructure (like Tor, Signal, Bitcoin)
- ✅ Free and open-source software (FOSS)
- ✅ A public good / digital public infrastructure
- ✅ Built for human rights, not profit
- ✅ Infrastructure for censorship resistance
- ✅ A mesh network that works without internet

### Reference Projects (Study These Sites)

**DO NOT copy Kimi's previous output.** Instead, study and emulate:

| Site | Why It's a Good Model | What to Copy |
|------|----------------------|--------------|
| **torproject.org** | Privacy infrastructure, mission-driven | Homepage structure, download prominence, security info |
| **signal.org** | Secure messaging, nonprofit | Clean design, clear mission, donation integration |
| **bitcoin.org** | Decentralized protocol | Educational content, neutral tone, community focus |
| **kernel.org** | Critical infrastructure | Minimal, functional, trust-focused |
| **ipfs.tech** | Decentralized protocol | Technical but accessible, developer-focused |
| **tailnet.tailscale.com** | Network tech | Clear value prop, technical depth |

**DO NOT study:**
- SaaS landing pages
- Startup marketing sites
- Product launch pages
- E-commerce sites

---

## PART 2: WEBSITE STRUCTURE

### Required Pages (In Order of Priority)

```
ghostwire.net/
│
├── / (Home) — CRITICAL
│   ├── Hero: Mission statement + Download CTA
│   ├── Network Stats: Live node count, messages, uptime
│   ├── What Is GhostWire: 2-3 sentence explanation
│   ├── Use Cases: Journalists, activists, communities, disaster zones
│   ├── Features: E2E encryption, no servers, RF mesh, offline-capable
│   ├── Community: Links to GitHub, Matrix, discussions
│   └── Trust: Security audits, cryptography details
│
├── /download/ — CRITICAL
│   ├── Latest release (from GitHub API)
│   ├── Binaries: Linux, Windows, macOS, Android
│   ├── Source code link
│   ├── Installation guides
│   ├── Verification (PGP signatures, checksums)
│   └── Older releases archive
│
├── /docs/ — CRITICAL
│   ├── Quick Start (5-minute setup)
│   ├── Installation (detailed, per-platform)
│   ├── Configuration (settings, networking)
│   ├── API Reference (for developers)
│   ├── RF Setup (LoRa, WiFi Direct, SDR)
│   ├── Security Best Practices
│   ├── Troubleshooting
│   └── FAQ (technical, not marketing)
│
├── /about/ — HIGH
│   ├── Mission (from manifesto)
│   ├── Manifesto (full text or excerpt + link)
│   ├── Team/Founder (NGAIRURU, contributors)
│   ├── History/Timeline
│   ├── Press Kit (logos, screenshots, fact sheet)
│   └── Contact (for press, not support)
│
├── /security/ — HIGH
│   ├── Cryptography Details (algorithms, key lengths)
│   ├── Security Audits (reports, status)
│   ├── Vulnerability Disclosure Process
│   ├── Security Advisories (CVE-style)
│   ├── Threat Model (who GhostWire protects against)
│   └── Limitations (what GhostWire does NOT protect against)
│
├── /community/ — HIGH
│   ├── GitHub Discussions link
│   ├── Matrix/Chat server info
│   ├── Contributing Guide
│   ├── Code of Conduct
│   ├── Events/Meetups
│   └── Recognition (contributors, supporters)
│
├── /blog/ — MEDIUM
│   ├── Release Notes (auto from GitHub)
│   ├── Technical Posts
│   ├── Community Updates
│   ├── Security Advisories
│   └── Guest Posts (community)
│
├── /donate/ — MEDIUM
│   ├── OpenCollective link
│   ├── Cryptocurrency addresses (BTC, ETH, XMR)
│   ├── Grants Info
│   ├── Sponsorship Tiers (for companies)
│   └── How Funds Are Used (transparency)
│
└── /status/ — LOW (future)
    ├── Network Health (live)
    ├── Node Count by Region
    ├── Uptime Stats
    └── Incident Reports
```

---

## PART 3: HOMEPAGE SPECIFICATIONS

### Hero Section (Above the Fold)

**What Must Appear:**

```
┌─────────────────────────────────────────────────────────────┐
│  [GhostWire Logo]                              [GitHub] [≡] │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│           GHOSTWIRE                                         │
│           Infrastructure for Human Dignity                  │
│                                                             │
│           A decentralized, censorship-resistant             │
│           communication mesh. No servers. No owners.        │
│           Built for when the internet goes dark.            │
│                                                             │
│           [Download v0.1.0]  [Read the Docs]                │
│                                                             │
│           [Dashboard Screenshot — actual GhostWire UI]      │
│                                                             │
│           Active Nodes: 247  │  Messages Today: 12,847     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Copy (Use This Exact Text or Similar):**

```markdown
# GHOSTWIRE
## Infrastructure for Human Dignity

A decentralized, censorship-resistant communication mesh.
No central servers. No backdoors. No owners.
Built for journalists under threat. Activists in hostile regimes.
Anyone who believes privacy is a human right.

When the internet goes dark, GhostWire stays on.

[Download GhostWire] [Read Documentation]

End-to-end encrypted • Offline-capable • Free forever
```

**What NOT to Say:**
- ❌ "Get Started" (vague)
- ❌ "Learn More" (vague)
- ❌ "High-performance platform" (marketing buzzword)
- ❌ "Revolutionary technology" (hype)
- ❌ Pricing information (it's free)

---

### Network Stats Section (Live Data)

**Pull from GhostWire API or GitHub:**

```tsx
interface NetworkStats {
  activeNodes: number;      // From API or estimate
  messagesToday: number;    // From API or estimate
  countries: number;        // From geo data
  uptime: string;           // Network age
  githubStars: number;      // GitHub API
  contributors: number;     // GitHub API
  latestRelease: string;    // GitHub API
}
```

**Display:**
```
┌──────────────┬──────────────┬──────────────┬──────────────┐
│ Active Nodes │ Messages/Day │ Countries    │ Since        │
│     247      │   12,847     │     23       │   Jan 2026   │
└──────────────┴──────────────┴──────────────┴──────────────┘
```

If live data isn't available yet, use static numbers with "as of [date]" disclaimer.

---

### Use Cases Section

**Who GhostWire Is For:**

```markdown
## Built for the Frontlines

**Journalists**
Communicate with sources without fear of surveillance or seizure.
Used by reporters in conflict zones and authoritarian regimes.

**Activists**
Organize without platform interference. No Terms of Service.
No deplatforming. No shadow banning.

**Communities**
Own your infrastructure. Run your own mesh. No ISP required.
Sovereign communication for sovereign people.

**Disaster Response**
When cell towers fall and power grids fail, GhostWire works.
Battery-powered. Offline-first. Resilient by design.

**Healthcare Workers**
Patient confidentiality in crisis zones. Medical coordination
without centralized servers that can be seized or subpoenaed.

**Whistleblowers**
Expose corruption without revealing your identity.
Secure drops. Anonymous routing. Zero-knowledge architecture.
```

---

### Features Section (Technical, Not Marketing)

```markdown
## Technical Capabilities

**End-to-End Encryption**
ChaCha20-Poly1305, Ed25519 signatures, X25519 key exchange.
No plaintext leaves your device. Ever.

**Decentralized Mesh**
No central servers. Communication routes peer-to-peer.
No single point of failure. No one to subpoena.

**Offline-Capable**
LoRa (2-15km), WiFi Direct (100m), Bluetooth LE.
Works without internet. Works during blackouts.

**Anonymous Routing**
Participation requires no identity disclosure.
You are a node, not a user. Nodes don't have names.

**Zero-Knowledge Architecture**
The network cannot know what it carries.
Metadata minimized. Routing encrypted.

**Censorship-Resistant**
No domain to seize. No servers to shut down.
No app store to ban you from.

**Free and Open Source**
Core protocol: MIT/Apache license.
Owned by no one. Auditable by everyone.
```

---

## PART 4: DESIGN REQUIREMENTS

### Visual Style

**Mood:**
- Serious, not playful
- Urgent, not casual
- Technical, not corporate
- Trustworthy, not flashy

**Color Palette:**
```
Primary: #0a0a0a (near-black background)
Secondary: #ffffff (white text)
Accent: #7e6ee3 (purple — use sparingly)
Success: #22c55e (green — for status, security)
Warning: #f59e0b (amber — for alerts)
Danger: #ef4444 (red — for critical warnings)
```

**Typography:**
```
Headings: Inter or Space Grotesk (bold, serious)
Body: Inter or IBM Plex Sans (readable, technical)
Mono: JetBrains Mono or Fira Code (for code, specs)
```

**Imagery:**
- ✅ Actual GhostWire screenshots (from your webui)
- ✅ Network topology diagrams
- ✅ Architecture diagrams
- ✅ Photos of hardware (LoRa nodes, SDR, etc.)
- ✅ Community photos (if available)
- ❌ NO stock photos
- ❌ NO generic "cybersecurity" clipart
- ❌ NO AI-generated people

**Layout Principles:**
- Content-first, not design-first
- Fast loading (>90 Lighthouse score)
- Works with JavaScript disabled (progressive enhancement)
- Accessible (WCAG 2.1 AA minimum)
- Mobile-first (most users on phones)

---

### Animation Guidelines

**DO:**
- ✅ Subtle hover states
- ✅ Smooth page transitions
- ✅ Loading states for async data
- ✅ Collapsible sections (docs, FAQ)
- ✅ Reduced motion support (`prefers-reduced-motion`)

**DO NOT:**
- ❌ Parallax scrolling
- ❌ 3D tilt effects
- ❌ WebGL backgrounds
- ❌ Magnetic buttons
- ❌ Kinetic accordions with spring physics
- ❌ Scroll-triggered text reveals
- ❌ Anything that delays content access

**Animation Budget:**
- Total JS for animations: < 50KB gzipped
- No animation should block content rendering
- All animations must respect `prefers-reduced-motion`

---

## PART 5: TECHNICAL REQUIREMENTS

### Recommended Stack

**Option A: Astro (RECOMMENDED)**
```yaml
Framework: Astro 5.x
Styling: Tailwind CSS 4.x
Interactivity: Alpine.js 3.x (minimal)
Deployment: Cloudflare Pages / Netlify
Build Time: < 30 seconds
Bundle Size: < 100KB total
```

**Why Astro:**
- Static site generation (fast, secure)
- Minimal JavaScript (islands architecture)
- Built-in Markdown support (for docs, blog)
- Easy GitHub API integration
- Best Lighthouse scores

**Option B: Next.js**
```yaml
Framework: Next.js 15.x
Styling: Tailwind CSS 4.x
Interactivity: React 19.x
Deployment: Vercel / Netlify
Build Time: < 60 seconds
Bundle Size: < 200KB total
```

**Why Next.js:**
- If you need dynamic features (user accounts, dashboard)
- SSR/SSG flexibility
- Large ecosystem
- Your team may already know React

**Option C: Your Existing Webui**
```yaml
Framework: React 19.x + Vite 7.x
Styling: Tailwind CSS 3.x
Backend: Rust (GhostWire core)
Deployment: Self-hosted / IPFS
```

**Why Existing Webui:**
- Already integrated with GhostWire
- Already has components
- No new framework to learn

### Required Integrations

**GitHub API (CRITICAL):**
```ts
// Fetch latest release
GET https://api.github.com/repos/phantomojo/GhostWire/releases/latest

// Fetch contributors
GET https://api.github.com/repos/phantomojo/GhostWire/contributors

// Fetch stars
GET https://api.github.com/repos/phantomojo/GhostWire
```

**Display:**
- Latest version number
- Download links
- Release date
- Contributor count
- Star count

**GhostWire API (If Available):**
```ts
// Network stats (you need to implement this in GhostWire core)
GET https://api.ghostwire.net/stats

// Returns:
{
  "active_nodes": 247,
  "messages_today": 12847,
  "countries": 23,
  "uptime_days": 45
}
```

**OpenCollective (For Donations):**
```html
<a href="https://opencollective.com/ghostwire">
  <img src="https://opencollective.com/ghostwire/tiers/backer.svg" />
</a>
```

**Matrix/Chat:**
```html
<a href="https://matrix.to/#/#ghostwire:matrix.org">
  Join Community Chat
</a>
```

---

### Performance Requirements

| Metric | Target | Why |
|--------|--------|-----|
| **Lighthouse Performance** | > 90 | Users on slow connections |
| **First Contentful Paint** | < 1.5s | Crisis zones, 3G networks |
| **Time to Interactive** | < 3s | Old phones, low RAM |
| **Total Bundle Size** | < 500KB | Data caps, expensive bandwidth |
| **Largest Contentful Paint** | < 2.5s | Perceived speed matters |

**Optimization Checklist:**
- [ ] Images optimized (WebP, AVIF)
- [ ] Lazy load below-fold images
- [ ] Preload critical CSS
- [ ] Defer non-critical JS
- [ ] Use CDN for static assets
- [ ] Enable gzip/brotli compression
- [ ] Set proper cache headers
- [ ] Minimize third-party scripts

---

### Accessibility Requirements

**WCAG 2.1 AA Minimum:**

- [ ] All images have alt text
- [ ] All interactive elements keyboard-accessible
- [ ] Focus states visible
- [ ] Color contrast > 4.5:1 (text), > 3:1 (UI)
- [ ] `prefers-reduced-motion` respected
- [ ] Screen reader tested
- [ ] Skip-to-content link
- [ ] Proper heading hierarchy (H1 → H2 → H3)
- [ ] Form labels present
- [ ] Error messages clear and actionable

**Test With:**
- NVDA (Windows, free)
- VoiceOver (macOS, built-in)
- axe DevTools (browser extension)
- WAVE (web accessibility evaluation tool)

---

## PART 6: CONTENT REQUIREMENTS

### What You Need to Gather

**Before Building, Collect:**

| Asset | Format | Where It's Used |
|-------|--------|-----------------|
| **Logo** | SVG, PNG (transparent) | Header, favicon, social |
| **Screenshots** | PNG, WebP (optimized) | Homepage, features, docs |
| **Manifesto** | Markdown | /about/ page |
| **Founder Photo** | JPG (professional) | /about/ page |
| **Architecture Diagram** | SVG | Homepage, docs |
| **Press Kit** | ZIP | /about/ press section |
| **PGP Key** | ASCII | Security page, releases |
| **Social Links** | URLs | Footer, community page |

**If You Don't Have These:**
- Use placeholders marked "TODO"
- Build the site structure anyway
- Document what's missing

---

### Copy Guidelines

**Tone:**
- Serious but not grim
- Technical but accessible
- Urgent but not fear-mongering
- Hopeful but not naive
- Direct, no corporate speak

**Voice:**
- Write like you're explaining to a journalist, activist, or developer
- Assume the reader is intelligent but may not know cryptography
- Use analogies when helpful (Indra's Net, Ubuntu)
- Avoid jargon when plain English works

**Examples:**

❌ **Bad (Marketing):**
> "GhostWire leverages cutting-edge blockchain-adjacent technology to revolutionize peer-to-peer synergies."

✅ **Good (Clear):**
> "GhostWire is a mesh network. Your phone talks directly to other phones. No servers in between."

❌ **Bad (Too Technical):**
> "Implements Noise Protocol Framework with ChaCha20-Poly1305 AEAD construction."

✅ **Good (Accessible):**
> "Messages are encrypted with ChaCha20-Poly1305. Only the recipient can read them. Not even the network can see what you send."

---

## PART 7: WHAT NOT TO BUILD

### Forbidden Patterns

**DO NOT CREATE:**

1. **Pricing Page** — GhostWire is free, full stop
2. **"Get Started" Funnel** — This isn't a SaaS onboarding
3. **Testimonials Section** — Feels fake for infrastructure
4. **Feature Comparison Table** — Not competing with products
5. **Email Capture Form** — Don't collect emails unless necessary
6. **Cookie Banner** — Use no tracking, no cookies
7. **Analytics (or use privacy-respecting)** — Plausible, Fathom, or none
8. **Chat Widget** — Use community chat links instead
9. **Sales Contact Form** — This isn't a business
10. **Demo Request** — Just let them download it

### Design Patterns to Avoid

**DO NOT USE:**

- Gradient backgrounds everywhere
- 3D illustrations of people
- Stock photography
- Animated hero videos
- Floating UI elements
- Excessive white space (wastes screen real estate)
- Hamburger menus on desktop (just use a nav bar)
- Modal popups (for anything)
- Exit-intent overlays
- "Subscribe to our newsletter" banners

---

## PART 8: GHOSTWIRE CONTEXT FOR AI

### Project Background

**What GhostWire Is Building:**

```
GhostWire is a decentralized, peer-to-peer communication mesh.

Technical Stack:
- Core: Rust 1.75+, Tokio async runtime
- Networking: libp2p (Kademlia DHT, GossipSub)
- Cryptography: Noise Protocol, Ed25519, ChaCha20-Poly1305
- Transports: TCP, WebRTC, LoRa, WiFi Direct, Bluetooth LE
- API: Axum (Rust), REST + WebSocket
- Frontend: React + Vite (Tauri for desktop)

Key Features:
- No central servers (fully decentralized)
- End-to-end encryption by default
- Works without internet (RF mesh: LoRa, WiFi Direct)
- Anonymous routing (no identity required)
- Censorship-resistant (no one to subpoena)

Use Cases:
- Journalists in hostile countries
- Activists under surveillance
- Disaster zones (infrastructure collapsed)
- Remote communities (no ISP)
- Healthcare in conflict zones
- Whistleblowers

Philosophy:
- Privacy is a human right, not a feature
- Decentralization is restoration, not ideology
- The core protocol is free forever
- The net cannot choose its users

Founder:
- NGAIRURU, 20 years old, Nairobi, Kenya
- Self-taught, built with AI agents
- Contact: ngairuru@proton.me
- GitHub: github.com/phantomojo
```

### Manifesto Summary

**Key Points (from GHOSTWIRE_MANIFESTO.md):**

1. **God as Foundation** — Connection is a feature of existence, not a product
2. **Decentralization as Restoration** — Pre-colonial Africa had 45,000 distributed polities; Ghostwire restores this pattern
3. **Core Stays Free Forever** — Cannot be sold, locked, or relicensed
4. **Privacy as Dignity** — Not secrecy, but the right to control what you reveal
5. **Net Cannot Choose Users** — Will carry harmful voices; censorship is worse
6. **First Root of Yggdrasil** — Ghostwire is infrastructure, not an application

**Full manifesto:** `/docs/GHOSTWIRE_MANIFESTO.md`

---

### Competitive Landscape

**GhostWire Is NOT Competing With:**

| Company | Why Not Competition |
|---------|---------------------|
| WhatsApp | Centralized, Meta-owned, requires internet |
| Telegram | Centralized servers, can be blocked |
| Signal | Requires internet, phone number |
| Discord | Centralized, corporate-owned |

**GhostWire IS Similar To:**

| Project | Similarity | Difference |
|---------|------------|------------|
| **Tor** | Censorship resistance, anonymity | Tor is for browsing; GhostWire is for messaging |
| **Briar** | P2P messaging, offline-capable | Briar is Android-only; GhostWire is cross-platform + RF |
| **Meshtastic** | LoRa mesh networking | Meshtastic is for sensors; GhostWire is for humans |
| **Cwtch** | Metadata-resistant messaging | Cwtch is Tor-based; GhostWire has multiple transports |

**Unique Value:**
- Only project with **RF mesh** (LoRa, WiFi Direct) + **internet** in one system
- Only project with **manifesto-driven development**
- Only project built from **Global South perspective** (Nairobi, not Silicon Valley)

---

## PART 9: DELIVERABLES

### What the AI Agent Must Produce

**Minimum Viable Site:**

```
[ ] Homepage with:
    [ ] Hero (mission + download CTA)
    [ ] Network stats (even if static)
    [ ] Use cases section
    [ ] Features section
    [ ] Community links

[ ] Download page with:
    [ ] GitHub releases integration
    [ ] Installation guides
    [ ] Verification instructions

[ ] About page with:
    [ ] Mission statement
    [ ] Founder info
    [ ] Manifesto link

[ ] Docs page (can link to external docs)

[ ] Security page with:
    [ ] Cryptography details
    [ ] Audit status

[ ] Footer with:
    [ ] GitHub link
    [ ] Community links
    [ ] Donate link
    [ ] License info
```

**Nice to Have:**

```
[ ] Blog (with Markdown support)
[ ] Community page
[ ] Donate page
[ ] Status page
[ ] Press kit download
[ ] Network visualization (live map of nodes)
```

---

### File Structure to Produce

```
ghostwire-website/
├── public/
│   ├── images/
│   │   ├── logo.svg
│   │   ├── hero-screenshot.webp
│   │   └── architecture-diagram.svg
│   ├── fonts/
│   └── favicon.ico
│
├── src/
│   ├── pages/
│   │   ├── index.astro (or page.tsx)
│   │   ├── download.astro
│   │   ├── about.astro
│   │   ├── docs.astro
│   │   ├── security.astro
│   │   └── community.astro
│   ├── components/
│   │   ├── Header.astro
│   │   ├── Footer.astro
│   │   ├── NetworkStats.astro
│   │   ├── FeatureCard.astro
│   │   └── DownloadButton.astro
│   ├── layouts/
│   │   └── BaseLayout.astro
│   ├── content/
│   │   ├── docs/
│   │   ├── blog/
│   │   └── security-advisories/
│   └── lib/
│       ├── github.ts (GitHub API client)
│       └── ghostwire.ts (GhostWire API client)
│
├── package.json
├── astro.config.mjs (or next.config.js)
├── tailwind.config.js
├── tsconfig.json
└── README.md
```

---

### Quality Checklist

**Before Delivery, Verify:**

```
[ ] All links work (no 404s)
[ ] GitHub API integration works (shows real data)
[ ] Mobile responsive (test on phone)
[ ] Accessibility (run axe DevTools)
[ ] Lighthouse score > 90
[ ] No console errors
[ ] Works with JavaScript disabled (progressive enhancement)
[ ] All images have alt text
[ ] Color contrast passes WCAG AA
[ ] No tracking scripts (or privacy-respecting only)
[ ] No cookies (or essential only)
[ ] Builds without errors
[ ] Deploys successfully
```

---

## PART 10: HOW TO USE THIS BRIEF

### For the AI Agent

**Read in This Order:**
1. Part 1 (What GhostWire Is) — Critical context
2. Part 2 (Website Structure) — What to build
3. Part 3 (Homepage Specs) — Most important page
4. Part 5 (Technical Requirements) — Stack, performance
5. Part 7 (What Not to Build) — Avoid mistakes
6. Part 8 (GhostWire Context) — Background info

**If You Have Questions:**
- Refer to `/docs/GHOSTWIRE_MANIFESTO.md` for philosophy
- Refer to `/docs/ARCHITECTURE.md` for technical details
- Refer to `/ghostwire/docs/API.md` for API documentation
- Ask the user (NGAIRURU) for clarification

**Do NOT:**
- Skip Part 1 (you'll build the wrong thing)
- Copy Kimi's previous output (it was wrong)
- Assume GhostWire is a startup (it's infrastructure)
- Add features not in this brief (ask first)

---

### For the Human (NGAIRURU)

**Before Giving This to an AI:**

1. **Gather Assets:**
   - Logo (SVG)
   - Screenshots (from your webui)
   - Founder photo
   - Any existing docs

2. **Set Up GitHub:**
   - Make sure repo is public
   - Create first release (even if alpha)
   - Enable GitHub API access

3. **Decide on Stack:**
   - Astro (recommended) or
   - Your existing webui or
   - Next.js

4. **Prepare Content:**
   - Manifesto (already done)
   - Basic docs (installation, quick start)
   - Security info (crypto algorithms used)

**After AI Produces Output:**

1. **Review Against This Brief:**
   - Did they build a SaaS site or project site?
   - Are downloads prominent?
   - Is the tone right?
   - Does it work on mobile?

2. **Test:**
   - Deploy to staging (Netlify, Vercel, Cloudflare Pages)
   - Run Lighthouse
   - Test on your phone
   - Ask community for feedback

3. **Iterate:**
   - Fix what's wrong
   - Add missing sections
   - Update content as GhostWire evolves

---

## FINAL NOTES

### This Is Not Optional

The website is **part of the product**. For many users, it will be their first interaction with GhostWire.

A bad website signals:
- Amateur project
- Untrustworthy software
- Abandoned development

A good website signals:
- Serious infrastructure
- Trustworthy team
- Active development

**You don't get a second chance at first impressions.**

### Ship Fast, Iterate Faster

Don't wait for perfection. Ship the minimum viable site, then improve based on feedback.

**Good enough today > perfect in a month.**

### The Goal

When someone visits ghostwire.net, they should think:

> "This is real. These people know what they're doing.
> I can trust this with my safety. I'm downloading it."

**That's the bar. Hit it.**

---

**END OF BRIEF**

---

*For questions or clarifications, contact:*  
**NGAIRURU** — ngairuru@proton.me  
**GitHub:** github.com/phantomojo  
**Location:** Nairobi, Kenya
