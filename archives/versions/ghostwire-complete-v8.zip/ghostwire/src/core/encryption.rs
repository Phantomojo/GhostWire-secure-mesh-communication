//! Encryption: key revocation, rotation announcements, CRLs.
//! Next: integrate with key manager and web API.

use crate::core::armor::TrafficArmor;
use ring::hkdf;
use ring::rand::{SecureRandom, SystemRandom};
use ring::signature::{Ed25519KeyPair, KeyPair};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::io::Write;
use std::os::unix::fs::OpenOptionsExt;
use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{info, warn};
use x25519_dalek::{PublicKey as XPublicKey, StaticSecret};
use zeroize::{Zeroize, ZeroizeOnDrop};

/// Enhanced encrypted message with additional security features
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EncryptedMessage {
    pub ciphertext: Vec<u8>,
    pub nonce: Vec<u8>,
    pub signature: Vec<u8>,
    pub sender_id: String,
    pub timestamp: u64,
    pub key_id: String,
    pub message_type: MessageType,
    pub version: u8,
    pub pq_key: Option<Vec<u8>>, // Kyber encapsulated key for PQC Hardening
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum MessageType {
    Text,
    Binary,
    Control,
    Heartbeat,
    Handshake,
}

/// Enhanced key pair with additional metadata
#[derive(Debug, Clone, Serialize, Deserialize, Zeroize, ZeroizeOnDrop)]
pub struct GhostKeyPair {
    pub public_key: Vec<u8>,
    pub private_key: Vec<u8>,
    pub key_id: String,
    pub created_at: u64,
    pub expires_at: Option<u64>,
    pub usage_count: usize,
    pub key_type: KeyType,
}

#[derive(Debug, Clone, Serialize, Deserialize, Zeroize)]
pub enum KeyType {
    Ed25519,
    X25519,
    Hybrid,      // Both Ed25519 and X25519
    PostQuantum, // Kyber
    Ultimate,    // Ed25519 + X25519 + Kyber
}

/// Enhanced peer key information
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PeerKey {
    pub public_key: Vec<u8>,
    pub key_id: String,
    pub last_updated: u64,
    pub key_type: KeyType,
    pub is_verified: bool,
    pub trust_score: f32,
}

/// Struct for tracking revoked keys.
#[derive(Default, Clone)]
pub struct RevocationList {
    pub revoked_keys: Vec<String>,
}

/// Trait for announcing key rotations.
pub trait KeyRotationAnnouncer {
    /// Announce a key rotation event.
    fn announce_rotation(&self, key_id: &str);
}

/// Default stub: no-op.
pub struct NoOpKeyRotationAnnouncer;
impl KeyRotationAnnouncer for NoOpKeyRotationAnnouncer {
    fn announce_rotation(&self, _key_id: &str) {}
}

/// Enhanced encryption manager with advanced security features
pub struct EncryptionManager {
    key_pair: GhostKeyPair,
    peer_keys: Arc<Mutex<HashMap<String, PeerKey>>>,
    rng: SystemRandom,
    session_keys: Arc<Mutex<HashMap<String, SessionKey>>>,
    key_rotation_interval: u64,
    last_key_rotation: u64,
    pub traffic_armor: Option<Arc<TrafficArmor>>,
}

#[derive(Debug, Clone, Zeroize, ZeroizeOnDrop)]
pub struct SessionKey {
    pub key: Vec<u8>,
    pub created_at: u64,
    pub expires_at: u64,
    pub usage_count: usize,
}

/// Trait for managing encryption key lifecycle (rotation, revocation, backup).
pub trait KeyManager {
    /// Rotate keys (periodic or on-demand).
    fn rotate(&mut self);
    /// Revoke a key by ID.
    fn revoke(&mut self, key_id: &str);
    /// Backup keys (encrypted export).
    fn backup(&self, passphrase: &str) -> Vec<u8>;
    /// Restore keys from backup.
    fn restore(&mut self, data: &[u8], passphrase: &str);
}

/// Stub implementation: does nothing.
pub struct StubKeyManager;

impl KeyManager for StubKeyManager {
    fn rotate(&mut self) {}
    fn revoke(&mut self, _key_id: &str) {}
    fn backup(&self, _passphrase: &str) -> Vec<u8> {
        vec![]
    }
    fn restore(&mut self, _data: &[u8], _passphrase: &str) {}
}

impl EncryptionManager {
    pub fn new() -> Result<Self, Box<dyn std::error::Error>> {
        Self::load_or_create()
    }

    pub fn load_or_create() -> Result<Self, Box<dyn std::error::Error>> {
        let storage_path = Self::get_storage_path()?;

        if storage_path.exists() {
            match Self::load_from_disk(&storage_path) {
                Ok(manager) => {
                    info!(
                        "🔐 Loaded persistent encryption keys for key_id: {}",
                        manager.key_pair.key_id
                    );
                    return Ok(manager);
                }
                Err(e) => {
                    warn!(
                        "⚠️ Failed to load encryption keys: {}. Rotating/Creating new.",
                        e
                    );
                }
            }
        }

        info!("🆕 Generating new persistent encryption keys...");
        let manager = Self::create_new()?;
        manager.save_to_disk()?;
        Ok(manager)
    }

    fn create_new() -> Result<Self, Box<dyn std::error::Error>> {
        let rng = SystemRandom::new();

        // Generate hybrid key pair (both Ed25519 and X25519)
        let key_pair = Self::generate_hybrid_key_pair(&rng)?;

        Ok(EncryptionManager {
            key_pair,
            peer_keys: Arc::new(Mutex::new(HashMap::new())),
            rng,
            session_keys: Arc::new(Mutex::new(HashMap::new())),
            key_rotation_interval: 86400 * 7, // 7 days
            last_key_rotation: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs(),
            traffic_armor: None,
        })
    }

    fn get_storage_path() -> Result<std::path::PathBuf, Box<dyn std::error::Error>> {
        let ghost_dir = if let Ok(ghost_home) = std::env::var("GHOSTWIRE_HOME") {
            std::path::PathBuf::from(ghost_home)
        } else {
            let home = dirs::home_dir().ok_or("Could not find home directory")?;
            home.join(".ghostwire")
        };

        if !ghost_dir.exists() {
            std::fs::create_dir_all(&ghost_dir)?;
        }
        Ok(ghost_dir.join("encryption.json"))
    }

    fn load_from_disk(path: &std::path::PathBuf) -> Result<Self, Box<dyn std::error::Error>> {
        // Use secure load
        let persisted: PersistedEncryption = Self::secure_load(path)?;

        let rng = SystemRandom::new();
        // Reconstruct manager from persisted state
        Ok(EncryptionManager {
            key_pair: persisted.key_pair,
            peer_keys: Arc::new(Mutex::new(HashMap::new())),
            rng,
            session_keys: Arc::new(Mutex::new(HashMap::new())),
            key_rotation_interval: persisted.key_rotation_interval,
            last_key_rotation: persisted.last_key_rotation,
            traffic_armor: None,
        })
    }

    fn get_master_key() -> Result<Vec<u8>, Box<dyn std::error::Error>> {
        let ghost_dir =
            if let Ok(ghost_home) = std::env::var(cryptify::encrypt_string!("GHOSTWIRE_HOME")) {
                std::path::PathBuf::from(ghost_home)
            } else {
                let home = dirs::home_dir().ok_or("No home dir")?;
                home.join(cryptify::encrypt_string!(".ghostwire"))
            };

        if !ghost_dir.exists() {
            std::fs::create_dir_all(&ghost_dir)?;
        }
        let key_path = ghost_dir.join(cryptify::encrypt_string!("master.key"));

        if key_path.exists() {
            let key = std::fs::read(&key_path)?;
            if key.len() != 32 {
                return Err("Invalid master key length".into());
            }
            Ok(key)
        } else {
            let mut key = [0u8; 32];
            SystemRandom::new()
                .fill(&mut key[..])
                .map_err(|_| "RNG failed")?;

            // save with 600
            let mut file = std::fs::OpenOptions::new()
                .write(true)
                .create(true)
                .mode(0o600)
                .open(&key_path)?;
            file.write_all(&key)?;
            tracing::info!("🔑 Generated new Master Key for secure storage");
            Ok(key.to_vec())
        }
    }

    pub fn secure_save<T: Serialize>(
        path: &std::path::Path,
        data: &T,
    ) -> Result<(), Box<dyn std::error::Error>> {
        let json_bytes = serde_json::to_vec(data)?;
        let master_key = Self::get_master_key()?;

        // Encrypt with XChaCha20-Poly1305
        let result = Self::encrypt_with_xchacha20(&json_bytes, &master_key)?;

        let mut file = std::fs::File::create(path)?;
        // Simple container format: [Nonce (12)] [Ciphertext]
        file.write_all(&result.nonce)?;
        file.write_all(&result.ciphertext)?;
        Ok(())
    }

    pub fn secure_load<T: for<'de> Deserialize<'de>>(
        path: &std::path::Path,
    ) -> Result<T, Box<dyn std::error::Error>> {
        let data = std::fs::read(path)?;
        if data.len() < 24 {
            return Err("File too short".into());
        }

        let master_key = Self::get_master_key()?;
        let nonce = &data[..24];
        let ciphertext = &data[24..];

        let plaintext_bytes = Self::decrypt_with_xchacha20(ciphertext, nonce, &master_key)?;
        let object: T = serde_json::from_slice(&plaintext_bytes)?;
        Ok(object)
    }

    /// Public helper for byte-level encryption using Master Key
    pub fn encrypt_bytes(data: &[u8]) -> Result<EncryptionResult, Box<dyn std::error::Error>> {
        let master_key = Self::get_master_key()?;
        Self::encrypt_with_xchacha20(data, &master_key)
    }

    /// Public helper for byte-level decryption using Master Key
    pub fn decrypt_bytes(
        ciphertext: &[u8],
        nonce: &[u8],
    ) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
        let master_key = Self::get_master_key()?;
        Self::decrypt_with_xchacha20(ciphertext, nonce, &master_key)
    }

    pub fn save_to_disk(&self) -> Result<(), Box<dyn std::error::Error>> {
        let path = Self::get_storage_path()?;
        let persisted = PersistedEncryption {
            key_pair: self.key_pair.clone(),
            key_rotation_interval: self.key_rotation_interval,
            last_key_rotation: self.last_key_rotation,
        };

        Self::secure_save(&path, &persisted)?;
        Ok(())
    }

    fn generate_hybrid_key_pair(
        rng: &SystemRandom,
    ) -> Result<GhostKeyPair, Box<dyn std::error::Error>> {
        // Generate Ed25519 key pair for signing
        let ed25519_pkcs8_key_pair = Ed25519KeyPair::generate_pkcs8(rng)
            .map_err(|e| format!("Failed to generate Ed25519 key pair: {:?}", e))?;
        let ed25519_key_pair = Ed25519KeyPair::from_pkcs8(ed25519_pkcs8_key_pair.as_ref())
            .map_err(|e| format!("Failed to create Ed25519 key pair: {:?}", e))?;

        // Generate X25519 key pair for encryption (persistent static secret)
        let x25519_secret = StaticSecret::random_from_rng(rand::thread_rng());
        let x25519_public = XPublicKey::from(&x25519_secret);
        let x25519_public_bytes = *x25519_public.as_bytes();
        let x25519_private_bytes = *x25519_secret.as_bytes();

        // Generate ML-KEM (Kyber768) key pair for post-quantum hardening
        /* Temporarily disabled due to Illegal Instruction on Android
        use pqcrypto_mlkem::mlkem768;
        use pqcrypto_traits::kem::{PublicKey as _, SecretKey as _};
        let (pq_pk, pq_sk) = mlkem768::keypair();
        */

        // Combine keys into a serialized binary format
        // Public part: [Ed25519 (32)] [X25519 (32)] [Kyber PK (1184 for 768)]
        let mut public_key = ed25519_key_pair.public_key().as_ref().to_vec();
        public_key.extend_from_slice(&x25519_public_bytes);
        // public_key.extend_from_slice(pq_pk.as_bytes()); // Disabled

        // Private part: [Ed25519 Len (2)] [Ed25519 PKCS8] [X25519 (32)] [Kyber SK (2400 for 768)]
        let ed_pkcs8 = ed25519_pkcs8_key_pair.as_ref();
        let ed_len = ed_pkcs8.len() as u16;
        let mut private_key = ed_len.to_le_bytes().to_vec();
        private_key.extend_from_slice(ed_pkcs8);
        private_key.extend_from_slice(&x25519_private_bytes);
        // private_key.extend_from_slice(pq_sk.as_bytes()); // Disabled

        let key_pair = GhostKeyPair {
            public_key,
            private_key,
            key_id: Self::generate_key_id(),
            created_at: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs(),
            expires_at: Some(
                SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap()
                    .as_secs()
                    + 86400 * 30,
            ), // 30 days
            usage_count: 0,
            key_type: KeyType::Hybrid,
        };

        Ok(key_pair)
    }

    fn generate_key_id() -> String {
        use std::time::{SystemTime, UNIX_EPOCH};
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        format!("key_{:x}", timestamp)
    }

    pub fn get_public_key(&self) -> &[u8] {
        &self.key_pair.public_key
    }

    pub fn get_key_id(&self) -> String {
        self.key_pair.key_id.clone()
    }

    pub fn add_peer_key(&self, peer_id: String, public_key: Vec<u8>, key_type: KeyType) {
        let mut peer_keys = self.peer_keys.lock().unwrap();
        peer_keys.insert(
            peer_id,
            PeerKey {
                public_key,
                key_id: Self::generate_key_id(),
                last_updated: SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap()
                    .as_secs(),
                key_type,
                is_verified: false,
                trust_score: 0.5, // Default trust score
            },
        );
    }

    pub fn encrypt_message(
        &self,
        message: &str,
        recipient_id: &str,
        message_type: MessageType,
    ) -> Result<EncryptedMessage, Box<dyn std::error::Error>> {
        let peer_keys = self.peer_keys.lock().unwrap();
        let peer_key = peer_keys.get(recipient_id).ok_or("Recipient not found")?;

        // Derive base session key via ECDH (existing)
        let session_key = self.derive_session_key(recipient_id, &peer_key.public_key)?;

        // PQC Hardening: Kyber Encapsulation
        let mut pq_key_out = None;
        let mut final_key = session_key.clone();

        if peer_key.public_key.len() >= 64 + 1184 {
            use pqcrypto_mlkem::mlkem768;
            use pqcrypto_traits::kem::PublicKey as _;

            let pq_pk_bytes = &peer_key.public_key[64..64 + 1184];
            let pk = mlkem768::PublicKey::from_bytes(pq_pk_bytes)
                .map_err(|_| "Invalid peer PQ public key")?;
            let (shared_secret, ciphertext) = mlkem768::encapsulate(&pk);
            use pqcrypto_traits::kem::{Ciphertext, SharedSecret};
            pq_key_out = Some(ciphertext.as_bytes().to_vec());

            // Mix keys: HKDF(ECDH_key, Kyber_secret)
            let salt = hkdf::Salt::new(hkdf::HKDF_SHA256, &final_key);
            let prk = salt.extract(shared_secret.as_bytes());
            let okm = prk
                .expand(&[b"GhostWire-PQC-Mix"], hkdf::HKDF_SHA256)
                .map_err(|_| "PQC mix failed")?;
            let mut mixed = [0u8; 32];
            okm.fill(&mut mixed).map_err(|_| "PQC fill failed")?;
            final_key = mixed.to_vec();
        }

        // Encrypt the message using XChaCha20-Poly1305 with the hardened key
        let encrypted_data = Self::encrypt_with_xchacha20(message.as_bytes(), &final_key)?;

        // Sign the encrypted message
        let signature = self.sign_message(&encrypted_data.ciphertext)?;

        // Update usage count
        self.increment_key_usage();

        Ok(EncryptedMessage {
            ciphertext: encrypted_data.ciphertext,
            nonce: encrypted_data.nonce,
            signature,
            sender_id: self.key_pair.key_id.clone(),
            timestamp: SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs(),
            key_id: self.key_pair.key_id.clone(),
            message_type,
            version: 0x03, // XChaCha20-Poly1305 encryption
            pq_key: pq_key_out,
        })
    }

    pub fn decrypt_message(
        &self,
        encrypted_msg: &EncryptedMessage,
    ) -> Result<String, Box<dyn std::error::Error>> {
        // Get peer public key for verification
        let peer_keys = self.peer_keys.lock().unwrap();
        let peer_key = peer_keys
            .get(&encrypted_msg.sender_id)
            .ok_or("Sender not found in peer keys")?;
        let peer_public_key = peer_key.public_key.clone();
        drop(peer_keys); // Release lock

        // Verify signature first
        self.verify_signature(
            &encrypted_msg.ciphertext,
            &encrypted_msg.signature,
            &peer_public_key,
        )?;

        if encrypted_msg.version != 0x03 {
            return Err("Unsupported message version (expected v3 XChaCha20)".into());
        }

        // Derive base session key for decryption
        let session_key = self.derive_session_key(&encrypted_msg.sender_id, &peer_public_key)?;
        let mut final_key = session_key.clone();

        // PQC Hardening: Kyber Decapsulation
        if let Some(pq_ciphertext) = &encrypted_msg.pq_key {
            use pqcrypto_mlkem::mlkem768;
            use pqcrypto_traits::kem::{Ciphertext as _, SecretKey as _};

            // Extract our Kyber Secret Key from private key blob
            let priv_key_bytes = &self.key_pair.private_key;
            let ed_len = u16::from_le_bytes([priv_key_bytes[0], priv_key_bytes[1]]) as usize;
            let pq_sk_bytes = &priv_key_bytes[2 + ed_len + 32..];

            if let (Ok(pq_sk), Ok(pq_ct)) = (
                mlkem768::SecretKey::from_bytes(pq_sk_bytes),
                mlkem768::Ciphertext::from_bytes(pq_ciphertext),
            ) {
                let shared_secret = mlkem768::decapsulate(&pq_ct, &pq_sk);

                use pqcrypto_traits::kem::SharedSecret;
                // Mix keys: HKDF(ECDH_key, Kyber_secret)
                let salt = hkdf::Salt::new(hkdf::HKDF_SHA256, &session_key);
                let prk = salt.extract(shared_secret.as_bytes());
                let okm = prk
                    .expand(&[b"GhostWire-PQC-Mix"], hkdf::HKDF_SHA256)
                    .map_err(|_| "PQC mix failed")?;
                let mut mixed = [0u8; 32];
                okm.fill(&mut mixed).map_err(|_| "PQC fill failed")?;
                final_key = mixed.to_vec();
            }
        }

        // Decrypt using XChaCha20-Poly1305
        let decrypted_data = Self::decrypt_with_xchacha20(
            &encrypted_msg.ciphertext,
            &encrypted_msg.nonce,
            &final_key,
        )?;

        String::from_utf8(decrypted_data).map_err(|e| e.into())
    }

    pub fn encrypt_with_xchacha20(
        data: &[u8],
        key: &[u8],
    ) -> Result<EncryptionResult, Box<dyn std::error::Error>> {
        use chacha20poly1305::{
            aead::{Aead, KeyInit},
            XChaCha20Poly1305, XNonce,
        };

        // Ensure key is exactly 32 bytes
        if key.len() != 32 {
            return Err("Key must be exactly 32 bytes for XChaCha20".into());
        }

        let cipher = XChaCha20Poly1305::new(key.into());

        // Generate random nonce (192 bits = 24 bytes for XChaCha20)
        let nonce_bytes = Self::generate_nonce();
        let nonce = XNonce::from_slice(&nonce_bytes);

        // Encrypt
        let ciphertext = cipher
            .encrypt(nonce, data)
            .map_err(|e| format!("XChaCha20 encryption failed: {}", e))?;

        Ok(EncryptionResult {
            ciphertext,
            nonce: nonce_bytes.to_vec(),
        })
    }

    pub fn decrypt_with_xchacha20(
        ciphertext: &[u8],
        nonce: &[u8],
        key: &[u8],
    ) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
        use chacha20poly1305::{
            aead::{Aead, KeyInit},
            XChaCha20Poly1305, XNonce,
        };

        // Ensure key is exactly 32 bytes
        if key.len() != 32 {
            return Err("Key must be exactly 32 bytes for XChaCha20".into());
        }

        // Ensure nonce is exactly 24 bytes
        if nonce.len() != 24 {
            return Err("Nonce must be exactly 24 bytes for XChaCha20".into());
        }

        let cipher = XChaCha20Poly1305::new(key.into());
        let nonce = XNonce::from_slice(nonce);

        // Decrypt
        let plaintext = cipher
            .decrypt(nonce, ciphertext)
            .map_err(|e| format!("XChaCha20 decryption failed: {}", e))?;

        Ok(plaintext)
    }

    fn derive_session_key(
        &self,
        peer_id: &str,
        peer_public_key: &[u8],
    ) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
        // Check if we have a cached session key
        let mut session_keys = self.session_keys.lock().unwrap();
        if let Some(session_key) = session_keys.get(peer_id) {
            let now = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs();
            if now < session_key.expires_at {
                return Ok(session_key.key.clone());
            }
        }

        // 🛡️ REAL ECDH IMPLEMENTATION
        // Peer public key structure: [Ed25519 (32) | X25519 (32)]
        if peer_public_key.len() < 64 {
            return Err("Invalid peer public key length".into());
        }
        let x25519_peer_pub_bytes: [u8; 32] = peer_public_key[32..64].try_into()?;
        let peer_x_pub = XPublicKey::from(x25519_peer_pub_bytes);

        // Our private key structure: [Ed25519 Len (2)] [Ed25519 PKCS8] [X25519 Private (32)]
        let priv_key_bytes = &self.key_pair.private_key;
        if priv_key_bytes.len() < 34 {
            return Err("Private key too short".into());
        }
        let ed_len = u16::from_le_bytes([priv_key_bytes[0], priv_key_bytes[1]]) as usize;
        let x25519_priv_bytes: [u8; 32] = priv_key_bytes[2 + ed_len..2 + ed_len + 32].try_into()?;
        let our_x_secret = StaticSecret::from(x25519_priv_bytes);

        // Compute Shared Secret using X25519
        let shared_secret = our_x_secret.diffie_hellman(&peer_x_pub);

        // Derive session key using HKDF-SHA256 (Robust way)
        let salt = hkdf::Salt::new(hkdf::HKDF_SHA256, b"GhostWire-Salt-v1");
        let prk = salt.extract(shared_secret.as_bytes());
        let info_str = cryptify::encrypt_string!("GhostWire-Session-Key-v2");
        let info = [info_str.as_bytes()];
        let okm = prk
            .expand(&info, hkdf::HKDF_SHA256)
            .map_err(|_| "HKDF expand failed")?;

        let mut key = [0u8; 32];
        okm.fill(&mut key).map_err(|_| "HKDF fill failed")?;

        // Cache the session key
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        session_keys.insert(
            peer_id.to_string(),
            SessionKey {
                key: key.to_vec(),
                created_at: now,
                expires_at: now + 3600, // 1 hour
                usage_count: 0,
            },
        );

        Ok(key.to_vec())
    }

    // Enhanced encryption method for CLI compatibility
    pub fn encrypt(&self, data: &[u8]) -> Vec<u8> {
        // Derive a strong 32-byte key from our key pair
        let key = self.derive_cli_key();

        match Self::encrypt_with_xchacha20(data, &key) {
            Ok(result) => {
                // Combine nonce and ciphertext
                let mut combined = result.nonce;
                combined.extend_from_slice(&result.ciphertext);
                combined
            }
            Err(e) => {
                tracing::error!(inner_error = %e, "CLI encryption failed");
                panic!(
                    "Encryption failed - this should never happen in production: {}",
                    e
                );
            }
        }
    }

    // Derive a deterministic but unique 32-byte key for CLI operations
    fn derive_cli_key(&self) -> Vec<u8> {
        use ring::digest;

        // Use SHA-256 to derive a 32-byte key from our keypair
        let mut ctx = digest::Context::new(&digest::SHA256);
        let domain = cryptify::encrypt_string!("GhostWire-CLI-v1");
        ctx.update(domain.as_bytes()); // Domain separation
        ctx.update(&self.key_pair.private_key[..]);
        ctx.update(&self.key_pair.public_key[..]);

        ctx.finish().as_ref().to_vec()
    }

    // Enhanced decryption method for CLI compatibility
    pub fn decrypt(&self, data: &[u8]) -> Vec<u8> {
        if data.len() < 24 {
            tracing::error!("Encrypted data too short (need at least 24 bytes for nonce)");
            panic!("Corrupted or invalid encrypted data");
        }

        // Derive the same key we used for encryption
        let key = self.derive_cli_key();

        // Extract nonce and ciphertext
        let nonce = &data[..24];
        let ciphertext = &data[24..];

        match Self::decrypt_with_xchacha20(ciphertext, nonce, &key) {
            Ok(decrypted) => decrypted,
            Err(e) => {
                tracing::error!(inner_error = %e, "CLI decryption failed");
                panic!(
                    "Decryption failed - data may be corrupted or tampered: {}",
                    e
                );
            }
        }
    }

    // Enhanced signature methods
    pub fn sign_message(&self, message: &[u8]) -> Result<Vec<u8>, Box<dyn std::error::Error>> {
        // Use Ed25519 for signing
        // Extract plain Ed25519 PKCS8 bytes from binary hybrid key
        let priv_key_bytes = &self.key_pair.private_key;
        if priv_key_bytes.len() < 2 {
            return Err("Invalid private key length".into());
        }
        let ed_len = u16::from_le_bytes([priv_key_bytes[0], priv_key_bytes[1]]) as usize;
        if priv_key_bytes.len() < 2 + ed_len {
            return Err("Corrupted private key".into());
        }
        let key_pair_bytes = &priv_key_bytes[2..2 + ed_len];

        let key_pair = Ed25519KeyPair::from_pkcs8(key_pair_bytes)
            .map_err(|e| format!("Failed to create key pair for signing: {:?}", e))?;

        let signature = key_pair.sign(message);
        Ok(signature.as_ref().to_vec())
    }

    pub fn verify_signature(
        &self,
        message: &[u8],
        signature: &[u8],
        public_key: &[u8],
    ) -> Result<(), Box<dyn std::error::Error>> {
        // Verify Ed25519 signature
        // Extract plain Ed25519 public key (first 32 bytes) if hybrid
        let ed25519_pub_key = if public_key.len() >= 32 {
            &public_key[..32]
        } else {
            return Err("Invalid public key length".into());
        };

        let public_key =
            ring::signature::UnparsedPublicKey::new(&ring::signature::ED25519, ed25519_pub_key);

        public_key
            .verify(message, signature)
            .map_err(|e| format!("Signature verification failed: {:?}", e).into())
    }

    fn generate_nonce() -> [u8; 24] {
        let mut nonce = [0u8; 24];
        SystemRandom::new().fill(&mut nonce[..]).unwrap();
        nonce
    }

    fn increment_key_usage(&self) {
        // In a real implementation, this would be thread-safe
        // For now, we'll just log the usage
        tracing::debug!(key_id = %self.key_pair.key_id, "Key usage incremented");
    }

    pub fn export_public_key(&self) -> Vec<u8> {
        self.key_pair.public_key.clone()
    }

    pub fn get_peer_count(&self) -> usize {
        self.peer_keys.lock().unwrap().len()
    }

    /// Check if key rotation is needed
    pub fn should_rotate_keys(&self) -> bool {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();

        now - self.last_key_rotation > self.key_rotation_interval
    }

    pub fn rotate_keys_if_needed(&mut self) -> Result<(), Box<dyn std::error::Error>> {
        if self.should_rotate_keys() {
            tracing::info!(msg = "Rotating encryption keys");
            let new_key_pair = Self::generate_hybrid_key_pair(&self.rng)?;
            self.key_pair = new_key_pair;
            self.last_key_rotation = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_secs();

            // Clear session keys
            self.session_keys.lock().unwrap().clear();
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EncryptionResult {
    pub ciphertext: Vec<u8>,
    pub nonce: Vec<u8>,
}

impl Default for EncryptionManager {
    fn default() -> Self {
        Self::new().expect("Failed to create default EncryptionManager")
    }
}

pub type Encryption = EncryptionManager;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_encryption_roundtrip() {
        let alice = EncryptionManager::new().unwrap();
        let bob = EncryptionManager::new().unwrap();

        let message = "Hello, Bob!";

        // Bob needs to exist in Alice's peer keys
        alice.add_peer_key(
            bob.get_key_id(),
            bob.get_public_key().to_vec(),
            KeyType::Hybrid,
        );

        // Alice needs to exist in Bob's peer keys (for Bob to verify/derive key)
        bob.add_peer_key(
            alice.get_key_id(),
            alice.get_public_key().to_vec(),
            KeyType::Hybrid,
        );

        // Alice encrypts for Bob
        let encrypted = alice
            .encrypt_message(message, &bob.get_key_id(), MessageType::Text)
            .unwrap();

        // Bob decrypts
        let decrypted = bob.decrypt_message(&encrypted).unwrap();

        assert_eq!(message, decrypted);
    }

    #[test]
    fn test_signature_verification() {
        let encryption = EncryptionManager::new().unwrap();
        let message = b"Verify me!";
        let signature = encryption.sign_message(message).unwrap();

        // Verify with own public key
        assert!(encryption
            .verify_signature(message, &signature, encryption.get_public_key())
            .is_ok());

        // Fail with wrong message
        assert!(encryption
            .verify_signature(b"Wrong", &signature, encryption.get_public_key())
            .is_err());
    }

    #[test]
    fn test_hybrid_key_generation() {
        let rng = SystemRandom::new();
        let key_pair = EncryptionManager::generate_hybrid_key_pair(&rng).unwrap();

        assert_eq!(key_pair.public_key.len(), 64); // 32 Ed25519 + 32 X25519
        assert!(key_pair.private_key.len() > 34);
        // Header length prefix should be there
        let ed_len =
            u16::from_le_bytes([key_pair.private_key[0], key_pair.private_key[1]]) as usize;
        assert!(ed_len > 0);
    }

    #[test]
    fn test_secure_storage() {
        let file_path = std::path::Path::new("test_secure_storage.json");

        #[derive(Serialize, Deserialize, PartialEq, Debug)]
        struct TestData {
            name: String,
            val: i32,
        }
        let data = TestData {
            name: "test".to_string(),
            val: 42,
        };

        EncryptionManager::secure_save(&file_path, &data).unwrap();
        let loaded: TestData = EncryptionManager::secure_load(&file_path).unwrap();

        assert_eq!(data, loaded);

        // Cleanup
        let _ = std::fs::remove_file(file_path);
    }
}

#[derive(Serialize, Deserialize)]
struct PersistedEncryption {
    key_pair: GhostKeyPair,
    key_rotation_interval: u64,
    last_key_rotation: u64,
}
