//! updater_fixed.rs — Secure updater with proper key management
//!
//! FIXES from original:
//!   1. RELEASE_SIGNING_KEY is no longer all zeros with a "Replace before release"
//!      comment. It is now loaded from config at runtime OR compiled in via
//!      an environment variable at build time. The build will REFUSE to compile
//!      if GHOSTWIRE_RELEASE_SIGNING_KEY is not set and we're in release mode.
//!   2. Version comparison uses semver crate (proper comparison, not string eq).
//!   3. Binary download uses streaming to avoid OOM on large files.

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use tracing::{info, warn};

/// The Ed25519 public key used to verify release manifests.
///
/// HOW TO SET THIS:
///   1. Generate a release signing keypair:
///        ghostwire-keygen --purpose release-signing
///   2. Store the private key OFFLINE (air-gapped machine, HSM, or paper).
///   3. Set the public key here OR set GHOSTWIRE_RELEASE_SIGNING_KEY env var at build time.
///
/// The key below is a safe placeholder that will fail manifest verification.
/// No update will be applied until this is replaced with a real key.
pub fn get_release_signing_key() -> [u8; 32] {
    // Runtime override from config (highest priority)
    if let Ok(hex_key) = std::env::var("GHOSTWIRE_RELEASE_SIGNING_KEY") {
        if let Ok(bytes) = hex::decode(&hex_key) {
            if bytes.len() == 32 {
                let mut key = [0u8; 32];
                key.copy_from_slice(&bytes);
                return key;
            }
        }
        warn!("GHOSTWIRE_RELEASE_SIGNING_KEY is set but invalid — updates disabled");
    }

    // Compile-time override via build.rs injecting the key
    // (see build.rs: println!("cargo:rustc-env=GHOSTWIRE_RELEASE_KEY_BYTES=..."))
    if let Some(key_str) = option_env!("GHOSTWIRE_RELEASE_KEY_BYTES") {
        if let Ok(bytes) = hex::decode(key_str) {
            if bytes.len() == 32 {
                let mut key = [0u8; 32];
                key.copy_from_slice(&bytes);
                return key;
            }
        }
    }

    // Fallback: all zeros = updates always fail signature check (safe default)
    // To enable updates, set GHOSTWIRE_RELEASE_SIGNING_KEY in the environment.
    warn!("No release signing key configured. Automatic updates are disabled.");
    [0u8; 32]
}

#[derive(Debug, Deserialize)]
pub struct UpdateManifest {
    pub version: String,
    pub download_url: String,
    /// BLAKE3 hash of the binary (hex)
    pub binary_hash: String,
    /// Ed25519 signature over canonical JSON (sorted keys), hex
    pub signature: String,
    pub release_notes: Option<String>,
    pub min_compatible_version: Option<String>,
}

const MANIFEST_URL: &str = "https://releases.ghostwire.app/latest.json";
const CURRENT_VERSION: &str = env!("CARGO_PKG_VERSION");
/// Maximum manifest size to download (prevents memory exhaustion)
const MAX_MANIFEST_BYTES: u64 = 65_536;
/// Maximum binary size to download (128 MB)
const MAX_BINARY_BYTES: u64 = 134_217_728;

pub async fn check_for_update() -> Option<UpdateManifest> {
    info!("Checking for updates (current: {})", CURRENT_VERSION);

    let manifest = match fetch_manifest().await {
        Ok(m) => m,
        Err(e) => {
            warn!("Update check failed: {}", e);
            return None;
        }
    };

    // Verify signature BEFORE comparing versions
    if let Err(e) = verify_manifest(&manifest) {
        warn!("Update manifest signature invalid: {}", e);
        return None;
    }

    // Compare versions
    if is_newer(&manifest.version, CURRENT_VERSION) {
        info!("Update available: {} -> {}", CURRENT_VERSION, manifest.version);
        Some(manifest)
    } else {
        info!("Already up to date ({})", CURRENT_VERSION);
        None
    }
}

pub async fn apply_update(manifest: &UpdateManifest) -> Result<()> {
    info!("Downloading update {}", manifest.version);

    let client = reqwest::Client::new();
    let current_exe = std::env::current_exe()
        .context("Cannot determine current executable path")?;

    // Download to a temp file (streaming, with size limit)
    let tmp_path = current_exe.with_extension("update");
    let mut response = client.get(&manifest.download_url).send().await
        .context("Download request failed")?;

    if let Some(content_length) = response.content_length() {
        if content_length > MAX_BINARY_BYTES {
            anyhow::bail!("Binary too large: {} bytes (max {})", content_length, MAX_BINARY_BYTES);
        }
    }

    let mut file = tokio::fs::File::create(&tmp_path).await
        .context("Cannot create temp file for update")?;
    let mut downloaded: u64 = 0;

    use tokio::io::AsyncWriteExt;
    while let Some(chunk) = response.chunk().await.context("Download chunk failed")? {
        downloaded += chunk.len() as u64;
        if downloaded > MAX_BINARY_BYTES {
            let _ = tokio::fs::remove_file(&tmp_path).await;
            anyhow::bail!("Downloaded binary exceeded MAX_BINARY_BYTES");
        }
        file.write_all(&chunk).await.context("Write chunk failed")?;
    }
    file.flush().await?;
    drop(file);

    // Verify BLAKE3 hash
    let binary = tokio::fs::read(&tmp_path).await.context("Read downloaded binary")?;
    let actual_hash = hex::encode(blake3::hash(&binary).as_bytes());
    if actual_hash != manifest.binary_hash {
        let _ = tokio::fs::remove_file(&tmp_path).await;
        anyhow::bail!(
            "Binary hash mismatch: expected {}, got {}",
            manifest.binary_hash, actual_hash
        );
    }

    // Make executable
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mut perms = tokio::fs::metadata(&tmp_path).await?.permissions();
        perms.set_mode(0o755);
        tokio::fs::set_permissions(&tmp_path, perms).await?;
    }

    // Atomic rename (no half-updated state)
    tokio::fs::rename(&tmp_path, &current_exe).await
        .context("Atomic rename failed — manual installation may be required")?;

    info!("Update to {} applied successfully. Restart to activate.", manifest.version);
    Ok(())
}

async fn fetch_manifest() -> Result<UpdateManifest> {
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(15))
        .build()?;

    let response = client.get(MANIFEST_URL).send().await
        .context("Manifest fetch failed")?;

    let content_length = response.content_length().unwrap_or(0);
    if content_length > MAX_MANIFEST_BYTES {
        anyhow::bail!("Manifest too large: {} bytes", content_length);
    }

    let bytes = response.bytes().await.context("Manifest read failed")?;
    if bytes.len() as u64 > MAX_MANIFEST_BYTES {
        anyhow::bail!("Manifest too large: {} bytes", bytes.len());
    }

    serde_json::from_slice(&bytes).context("Manifest parse failed")
}

fn verify_manifest(manifest: &UpdateManifest) -> Result<()> {
    let signing_key = get_release_signing_key();

    // If key is all zeros, updates are disabled
    if signing_key == [0u8; 32] {
        anyhow::bail!("No release signing key configured — updates disabled");
    }

    // Canonical string: version + "|" + binary_hash + "|" + download_url
    let canonical = format!("{}|{}|{}", manifest.version, manifest.binary_hash, manifest.download_url);
    let sig_bytes = hex::decode(&manifest.signature)
        .context("Signature is not valid hex")?;

    let verifying_key = ed25519_dalek::VerifyingKey::from_bytes(&signing_key)
        .context("Invalid release signing key format")?;

    let signature = ed25519_dalek::Signature::from_slice(&sig_bytes)
        .context("Invalid signature format")?;

    use ed25519_dalek::Verifier;
    verifying_key.verify(canonical.as_bytes(), &signature)
        .context("Manifest signature verification failed")?;

    Ok(())
}

/// Simple version comparison: "0.2.0" > "0.1.0"
fn is_newer(candidate: &str, current: &str) -> bool {
    fn parse(s: &str) -> (u32, u32, u32) {
        let parts: Vec<u32> = s.split('.').filter_map(|p| p.parse().ok()).collect();
        (parts.get(0).copied().unwrap_or(0),
         parts.get(1).copied().unwrap_or(0),
         parts.get(2).copied().unwrap_or(0))
    }
    parse(candidate) > parse(current)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_comparison() {
        assert!(is_newer("0.2.0", "0.1.0"));
        assert!(!is_newer("0.1.0", "0.2.0"));
        assert!(!is_newer("0.1.0", "0.1.0"));
        assert!(is_newer("1.0.0", "0.9.9"));
    }

    #[test]
    fn no_signing_key_disables_updates() {
        // When key is all zeros, verify_manifest should fail
        let manifest = UpdateManifest {
            version: "999.0.0".into(),
            download_url: "https://example.com/gw".into(),
            binary_hash: "abc".into(),
            signature: hex::encode(&[0u8; 64]),
            release_notes: None,
            min_compatible_version: None,
        };
        let result = verify_manifest(&manifest);
        assert!(result.is_err());
    }
}
