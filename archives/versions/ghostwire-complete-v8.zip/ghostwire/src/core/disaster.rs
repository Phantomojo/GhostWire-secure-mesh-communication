//! disaster.rs — Offline-first, infrastructure-collapse resilience
//!
//! This is one of Ghostwire's most unique features.
//! When the internet dies, mesh keeps working.
//!
//! Fallback chain:
//!   Internet mesh (libp2p) → Local WiFi mDNS → Bluetooth LE → QR code exchange
//!
//! The DisasterManager watches network state and automatically switches
//! between transport modes. All transports share the same message format
//! so the switch is transparent to upper layers.

use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::{mpsc, RwLock};
use tracing::{info, warn};

/// Network health assessment
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum NetworkState {
    /// Full internet connectivity — use libp2p mesh
    FullMesh,
    /// Internet unreachable, LAN available — use mDNS local
    LocalOnly,
    /// No IP at all — use Bluetooth LE
    BluetoothOnly,
    /// Everything down — manual QR exchange only
    AirGap,
}

impl std::fmt::Display for NetworkState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::FullMesh => write!(f, "Full Mesh (internet)"),
            Self::LocalOnly => write!(f, "Local Only (LAN/WiFi)"),
            Self::BluetoothOnly => write!(f, "Bluetooth LE"),
            Self::AirGap => write!(f, "Air Gap (QR only)"),
        }
    }
}

/// Events emitted by the DisasterManager
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum DisasterEvent {
    NetworkStateChanged {
        from: NetworkState,
        to: NetworkState,
        timestamp: u64,
    },
    PeerDiscoveredOffline {
        peer_id: String,
        transport: String,
    },
    MessageQueuedForDelivery {
        message_id: String,
        recipient_id: String,
        transport: String,
    },
    DeliveryConfirmed {
        message_id: String,
        transport: String,
    },
}

/// A message queued for delayed delivery when a peer comes back online
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QueuedMessage {
    pub message_id: String,
    pub recipient_id: String,
    /// The encrypted envelope bytes (already sealed by MailboxStore)
    pub payload: Vec<u8>,
    pub queued_at: u64,
    pub max_retry_until: u64,
    pub attempts: u32,
}

/// Health check result for a transport
#[derive(Debug, Clone)]
struct TransportHealth {
    reachable_peers: usize,
    last_checked: Instant,
    latency_ms: Option<u64>,
}

/// Manages network state and disaster fallback
pub struct DisasterManager {
    state: Arc<RwLock<NetworkState>>,
    event_tx: mpsc::Sender<DisasterEvent>,
    message_queue: Arc<RwLock<Vec<QueuedMessage>>>,
    check_interval: Duration,
}

impl DisasterManager {
    pub fn new(event_tx: mpsc::Sender<DisasterEvent>) -> Self {
        Self {
            state: Arc::new(RwLock::new(NetworkState::FullMesh)),
            event_tx,
            message_queue: Arc::new(RwLock::new(Vec::new())),
            check_interval: Duration::from_secs(15),
        }
    }

    /// Get current network state
    pub async fn current_state(&self) -> NetworkState {
        self.state.read().await.clone()
    }

    /// Spawn the network health monitor. Runs continuously.
    pub fn start_monitor(self: Arc<Self>) {
        tokio::spawn(async move {
            loop {
                tokio::time::sleep(self.check_interval).await;
                if let Err(e) = self.check_and_transition().await {
                    warn!("Disaster monitor check failed: {}", e);
                }
            }
        });
    }

    /// Check network health and transition state if needed
    pub async fn check_and_transition(&self) -> Result<()> {
        let new_state = self.assess_network().await;
        let current = self.state.read().await.clone();

        if new_state != current {
            info!(
                "🌐 Network state transition: {} → {}",
                current, new_state
            );

            let event = DisasterEvent::NetworkStateChanged {
                from: current,
                to: new_state.clone(),
                timestamp: now_secs(),
            };

            *self.state.write().await = new_state;

            // Non-blocking emit
            let _ = self.event_tx.try_send(event);

            // Attempt to drain queued messages on state improvement
            self.attempt_queue_flush().await;
        }

        Ok(())
    }

    /// Queue a message for delivery when the recipient comes online
    pub async fn queue_message(
        &self,
        message_id: String,
        recipient_id: String,
        payload: Vec<u8>,
        ttl: Duration,
    ) {
        let queued = QueuedMessage {
            message_id: message_id.clone(),
            recipient_id: recipient_id.clone(),
            payload,
            queued_at: now_secs(),
            max_retry_until: now_secs() + ttl.as_secs(),
            attempts: 0,
        };

        self.message_queue.write().await.push(queued);

        let state = self.state.read().await.clone();
        let _ = self.event_tx.try_send(DisasterEvent::MessageQueuedForDelivery {
            message_id,
            recipient_id,
            transport: state.to_string(),
        });
    }

    /// Get all pending queued messages for a specific peer
    pub async fn get_queued_for_peer(&self, peer_id: &str) -> Vec<QueuedMessage> {
        let queue = self.message_queue.read().await;
        let now = now_secs();
        queue
            .iter()
            .filter(|m| m.recipient_id == peer_id && m.max_retry_until > now)
            .cloned()
            .collect()
    }

    /// Mark a queued message as delivered
    pub async fn mark_delivered(&self, message_id: &str) {
        let mut queue = self.message_queue.write().await;
        queue.retain(|m| m.message_id != message_id);

        let _ = self.event_tx.try_send(DisasterEvent::DeliveryConfirmed {
            message_id: message_id.to_string(),
            transport: "unknown".to_string(),
        });
    }

    /// Purge expired messages from the queue
    pub async fn purge_expired_queue(&self) -> usize {
        let now = now_secs();
        let mut queue = self.message_queue.write().await;
        let before = queue.len();
        queue.retain(|m| m.max_retry_until > now);
        before - queue.len()
    }

    /// Get network state summary for the UI
    pub async fn status_report(&self) -> DisasterStatus {
        let state = self.state.read().await.clone();
        let queue = self.message_queue.read().await;
        let now = now_secs();

        DisasterStatus {
            network_state: state.to_string(),
            queued_messages: queue.len(),
            expired_queued: queue.iter().filter(|m| m.max_retry_until <= now).count(),
        }
    }

    // ── Private ───────────────────────────────────────────────────────────────

    /// Assess actual network reachability
    async fn assess_network(&self) -> NetworkState {
        // Check internet reachability via DNS probe
        let internet_ok = self.probe_internet().await;

        if internet_ok {
            return NetworkState::FullMesh;
        }

        // Check local network
        let local_ok = self.probe_local().await;
        if local_ok {
            return NetworkState::LocalOnly;
        }

        // Check if Bluetooth is available
        let bt_ok = self.probe_bluetooth().await;
        if bt_ok {
            return NetworkState::BluetoothOnly;
        }

        NetworkState::AirGap
    }

    async fn probe_internet(&self) -> bool {
        // Try to resolve a well-known DNS name
        // In production, also check if any libp2p bootstrap node is reachable
        match tokio::net::TcpStream::connect("8.8.8.8:53").await {
            Ok(_) => true,
            Err(_) => {
                // Secondary probe: try bootstrap.libp2p.io
                tokio::time::timeout(
                    Duration::from_secs(3),
                    tokio::net::lookup_host("bootstrap.libp2p.io:4001"),
                )
                .await
                .is_ok()
            }
        }
    }

    async fn probe_local(&self) -> bool {
        // Check if mDNS peers are reachable (any .local addresses in routing table)
        // This is a stub — in production, query the libp2p mDNS peer list
        // For now: check if we have any local IP addresses
        local_ip_address::local_ip().is_ok()
    }

    async fn probe_bluetooth(&self) -> bool {
        // Stub: in production, check btleplug adapter availability
        // btleplug::api::Manager::new() → check if any adapters exist
        // Returning false until Bluetooth phase is complete
        false
    }

    async fn attempt_queue_flush(&self) {
        // Triggered when network improves. In production:
        //   - For each queued message, attempt delivery via new transport
        //   - On success, call mark_delivered()
        //   - On failure, increment attempts counter
        let _queue = self.message_queue.read().await;
        // TODO: wire into mesh.send_message() for each pending message
    }
}

/// Summary for API/UI
#[derive(Debug, Serialize)]
pub struct DisasterStatus {
    pub network_state: String,
    pub queued_messages: usize,
    pub expired_queued: usize,
}

// ── QR code key exchange (AirGap mode) ───────────────────────────────────────

/// Encode a public key + peer ID as a QR-scannable payload
///
/// Format: "gw1:" + base58(peer_id_bytes || x25519_pub_bytes)
/// The "gw1:" prefix makes it recognisable as a Ghostwire contact QR.
pub fn encode_contact_qr(peer_id: &str, x25519_pub: &[u8; 32]) -> Result<String> {
    let mut payload = peer_id.as_bytes().to_vec();
    payload.push(0x00); // separator
    payload.extend_from_slice(x25519_pub);

    let encoded = bs58::encode(&payload).into_string();
    Ok(format!("gw1:{}", encoded))
}

/// Decode a QR payload back into (peer_id, x25519_pub)
pub fn decode_contact_qr(qr_string: &str) -> Result<(String, [u8; 32])> {
    let stripped = qr_string
        .strip_prefix("gw1:")
        .ok_or_else(|| anyhow::anyhow!("Not a Ghostwire QR code (missing gw1: prefix)"))?;

    let bytes = bs58::decode(stripped)
        .into_vec()
        .map_err(|e| anyhow::anyhow!("QR base58 decode failed: {}", e))?;

    // Find separator
    let sep_pos = bytes
        .iter()
        .position(|&b| b == 0x00)
        .ok_or_else(|| anyhow::anyhow!("Malformed QR: no separator"))?;

    let peer_id = String::from_utf8(bytes[..sep_pos].to_vec())
        .map_err(|_| anyhow::anyhow!("Invalid peer ID in QR"))?;

    let key_bytes = &bytes[sep_pos + 1..];
    if key_bytes.len() != 32 {
        anyhow::bail!("Invalid X25519 key in QR: expected 32 bytes, got {}", key_bytes.len());
    }

    let mut key = [0u8; 32];
    key.copy_from_slice(key_bytes);
    Ok((peer_id, key))
}

fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn qr_encode_decode_roundtrip() {
        let peer_id = "12D3KooWExamplePeerID123";
        let pub_key = [0x42u8; 32];

        let qr = encode_contact_qr(peer_id, &pub_key).unwrap();
        assert!(qr.starts_with("gw1:"));

        let (recovered_peer, recovered_key) = decode_contact_qr(&qr).unwrap();
        assert_eq!(recovered_peer, peer_id);
        assert_eq!(recovered_key, pub_key);
    }

    #[test]
    fn qr_rejects_bad_prefix() {
        let result = decode_contact_qr("notgw:somedata");
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn queue_and_purge() {
        let (tx, _rx) = mpsc::channel(10);
        let manager = DisasterManager::new(tx);

        manager
            .queue_message(
                "msg1".to_string(),
                "peer1".to_string(),
                b"hello".to_vec(),
                Duration::from_secs(3600),
            )
            .await;

        let queued = manager.get_queued_for_peer("peer1").await;
        assert_eq!(queued.len(), 1);

        manager.mark_delivered("msg1").await;
        let queued = manager.get_queued_for_peer("peer1").await;
        assert_eq!(queued.len(), 0);
    }
}
