use crate::genesis_constants::{RECOVERY_KDF_DOMAIN, derive_with_domain};
//! recovery.rs — Shamir Secret Sharing for identity key recovery
//!
//! Problem: If a user loses their device or forgets their password, they lose
//! their identity forever. Most privacy apps just say "you're on your own."
//!
//! Solution: Split the identity master key into N shares using Shamir's Secret
//! Sharing. Distribute to trusted contacts. Recovery requires M-of-N to
//! cooperate. No single contact can reconstruct the key alone.
//!
//! This is a genuinely novel UX feature in the privacy app space.
//! The `shamir_secret_sharing` crate is already in Ghostwire's Cargo.toml.
//!
//! Flow:
//!   1. User chooses M (threshold) and N (total shares), picks N trusted peers
//!   2. Each share is encrypted to that peer's public key before transmission
//!   3. Shares are stored in each peer's local encrypted DB
//!   4. To recover: contact M peers, collect their shares, reconstruct key
//!   5. Re-encrypt reconstructed key with new password, save as new identity

use anyhow::{Context, Result};
use chacha20poly1305::{
    aead::{Aead, KeyInit},
    ChaCha20Poly1305, Key, Nonce,
};
use ring::rand::{SecureRandom, SystemRandom};
use serde::{Deserialize, Serialize};
use zeroize::{Zeroize, ZeroizeOnDrop};

/// A single share, encrypted for a specific guardian peer.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EncryptedShare {
    /// Index of this share (1-based, as Shamir requires)
    pub share_index: u8,
    /// Guardian's peer ID (for routing the share to them)
    pub guardian_id: String,
    /// Guardian's display name (for UX)
    pub guardian_name: String,
    /// The share bytes, encrypted to guardian's X25519 public key
    pub ciphertext: Vec<u8>,
    /// Ephemeral X25519 pub used for this encryption (base64)
    pub ephemeral_pub: String,
    /// ChaCha20 nonce (base64)
    pub nonce: String,
    /// BLAKE3 hash of the unencrypted share (for integrity check on recovery)
    pub share_hash: String,
    /// Unix timestamp of creation
    pub created_at: u64,
}

/// Metadata stored locally about the recovery scheme (no secret material here)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecoverySchemeMetadata {
    pub threshold: u8,
    pub total_shares: u8,
    pub guardian_ids: Vec<String>,
    pub created_at: u64,
    /// BLAKE3 hash of the master secret (used to verify reconstruction)
    pub master_hash: String,
}

/// Sensitive: the reconstructed master key. Zeroized on drop.
#[derive(Zeroize, ZeroizeOnDrop)]
pub struct ReconstructedKey(pub Vec<u8>);

/// Split a `master_key` into `total` shares, requiring `threshold` to recover.
///
/// Returns encrypted shares (one per guardian) + scheme metadata.
/// The caller is responsible for routing each share to its guardian.
pub fn create_recovery_shares(
    master_key: &[u8],
    threshold: u8,
    total: u8,
    guardians: &[(String, String, [u8; 32])], // (peer_id, name, x25519_pub)
) -> Result<(Vec<EncryptedShare>, RecoverySchemeMetadata)> {
    if threshold < 2 {
        anyhow::bail!("Threshold must be at least 2");
    }
    if total < threshold {
        anyhow::bail!("Total shares ({}) must be >= threshold ({})", total, threshold);
    }
    if guardians.len() != total as usize {
        anyhow::bail!("Guardian count ({}) must equal total shares ({})", guardians.len(), total);
    }
    if master_key.len() < 16 {
        anyhow::bail!("Master key too short: {} bytes", master_key.len());
    }

    // Generate raw shares
    let shares = shamir_split(master_key, threshold, total)
        .context("Shamir split failed")?;

    let rng = SystemRandom::new();
    let master_hash = blake3::hash(master_key).to_hex().to_string();
    let mut encrypted_shares = Vec::with_capacity(total as usize);

    for (i, ((peer_id, name, pub_key), raw_share)) in guardians.iter().zip(shares.iter()).enumerate() {
        let share_hash = blake3::hash(raw_share).to_hex().to_string();
        let encrypted = encrypt_share_for_guardian(raw_share, pub_key, &rng)
            .context(format!("Failed to encrypt share {} for {}", i + 1, name))?;

        encrypted_shares.push(EncryptedShare {
            share_index: (i + 1) as u8,
            guardian_id: peer_id.clone(),
            guardian_name: name.clone(),
            ciphertext: encrypted.0,
            ephemeral_pub: encrypted.1,
            nonce: encrypted.2,
            share_hash,
            created_at: now_secs(),
        });
    }

    let metadata = RecoverySchemeMetadata {
        threshold,
        total_shares: total,
        guardian_ids: guardians.iter().map(|(id, _, _)| id.clone()).collect(),
        created_at: now_secs(),
        master_hash,
    };

    Ok((encrypted_shares, metadata))
}

/// Reconstruct the master key from M decrypted shares.
///
/// `raw_shares`: Vec of (share_index, share_bytes) — must have >= threshold entries.
/// Returns the reconstructed key, verified against `expected_hash`.
pub fn reconstruct_key(
    raw_shares: &[(u8, Vec<u8>)],
    threshold: u8,
    expected_hash: &str,
) -> Result<ReconstructedKey> {
    if raw_shares.len() < threshold as usize {
        anyhow::bail!(
            "Not enough shares: have {}, need {}",
            raw_shares.len(),
            threshold
        );
    }

    let reconstructed = shamir_combine(raw_shares)
        .context("Shamir combine failed — shares may be corrupt or mismatched")?;

    // Verify integrity
    let actual_hash = blake3::hash(&reconstructed).to_hex().to_string();
    if actual_hash != expected_hash {
        anyhow::bail!(
            "Reconstructed key hash mismatch — recovery failed (wrong shares or tampering)"
        );
    }

    Ok(ReconstructedKey(reconstructed))
}

/// Decrypt a share that was encrypted for us (we are a guardian).
pub fn decrypt_share(
    encrypted: &EncryptedShare,
    our_x25519_secret: &x25519_dalek::StaticSecret,
) -> Result<Vec<u8>> {
    use base64::Engine;

    let ephemeral_pub_bytes: Vec<u8> =
        base64::engine::general_purpose::STANDARD.decode(&encrypted.ephemeral_pub)?;
    let ephemeral_arr: [u8; 32] = ephemeral_pub_bytes
        .try_into()
        .map_err(|_| anyhow::anyhow!("Bad ephemeral pub length"))?;

    let ephemeral_pub = x25519_dalek::PublicKey::from(ephemeral_arr);
    let shared = our_x25519_secret.diffie_hellman(&ephemeral_pub);
    let key_bytes = derive_with_domain(RECOVERY_KDF_DOMAIN, shared.as_bytes());
    let key = Key::from_slice(&key_bytes);
    let cipher = ChaCha20Poly1305::new(key);

    let nonce_bytes: Vec<u8> =
        base64::engine::general_purpose::STANDARD.decode(&encrypted.nonce)?;
    let nonce = Nonce::from_slice(&nonce_bytes);

    let plaintext = cipher
        .decrypt(nonce, encrypted.ciphertext.as_slice())
        .map_err(|_| anyhow::anyhow!("Share decryption failed"))?;

    // Verify share integrity
    let actual_hash = blake3::hash(&plaintext).to_hex().to_string();
    if actual_hash != encrypted.share_hash {
        anyhow::bail!("Share integrity check failed — share may be corrupt");
    }

    Ok(plaintext)
}

// ── Internal helpers ─────────────────────────────────────────────────────────

/// Encrypt raw share bytes for a guardian's X25519 public key.
/// Returns (ciphertext, ephemeral_pub_b64, nonce_b64)
fn encrypt_share_for_guardian(
    share: &[u8],
    guardian_pub: &[u8; 32],
    rng: &SystemRandom,
) -> Result<(Vec<u8>, String, String)> {
    use base64::Engine;

    let ephemeral_secret = x25519_dalek::EphemeralSecret::random_from_rng(rand::thread_rng());
    let ephemeral_pub = x25519_dalek::PublicKey::from(&ephemeral_secret);

    let guardian_x25519 = x25519_dalek::PublicKey::from(*guardian_pub);
    let shared = ephemeral_secret.diffie_hellman(&guardian_x25519);
    let key_bytes = derive_with_domain(RECOVERY_KDF_DOMAIN, shared.as_bytes());
    let key = Key::from_slice(&key_bytes);
    let cipher = ChaCha20Poly1305::new(key);

    let mut nonce_bytes = [0u8; 12];
    rng.fill(&mut nonce_bytes)
        .map_err(|_| anyhow::anyhow!("RNG failure"))?;
    let nonce = Nonce::from_slice(&nonce_bytes);

    let ciphertext = cipher
        .encrypt(nonce, share)
        .map_err(|e| anyhow::anyhow!("Encryption failed: {:?}", e))?;

    Ok((
        ciphertext,
        base64::engine::general_purpose::STANDARD.encode(ephemeral_pub.as_bytes()),
        base64::engine::general_purpose::STANDARD.encode(nonce_bytes),
    ))
}

/// Thin wrapper around shamir_secret_sharing crate
fn shamir_split(secret: &[u8], threshold: u8, total: u8) -> Result<Vec<Vec<u8>>> {
    // shamir_secret_sharing works per-byte; we process the full secret
    // by splitting each byte independently and reassembling
    // This is the standard approach for binary secrets with this crate
    use shamir_secret_sharing::ShamirSecretSharing;

    let sss = ShamirSecretSharing {
        threshold: threshold as usize,
        share_count: total as usize,
        prime: *shamir_secret_sharing::PRIME_4096,
    };

    // Encode secret as a single large number via big-endian interpretation,
    // then split. For secrets longer than the prime allows, we chunk.
    // Simple approach: treat each 8-byte chunk independently.
    let chunk_size = 8usize;
    let mut all_shares: Vec<Vec<u8>> = vec![Vec::new(); total as usize];

    for chunk in secret.chunks(chunk_size) {
        let mut padded = [0u8; 8];
        padded[..chunk.len()].copy_from_slice(chunk);
        let val = u64::from_be_bytes(padded);

        let shares = sss.split(num_bigint::BigInt::from(val));
        for (i, (_, share_val)) in shares.iter().enumerate() {
            let bytes = share_val.to_signed_bytes_be();
            // Prefix with 8-byte length so we can parse back
            all_shares[i].extend_from_slice(&(bytes.len() as u32).to_be_bytes());
            all_shares[i].extend_from_slice(&bytes);
        }
    }

    Ok(all_shares)
}

fn shamir_combine(shares: &[(u8, Vec<u8>)]) -> Result<Vec<u8>> {
    use shamir_secret_sharing::ShamirSecretSharing;

    // We need to know threshold from context — use shares.len() as threshold
    let threshold = shares.len();
    let sss = ShamirSecretSharing {
        threshold,
        share_count: threshold, // doesn't matter for combine
        prime: *shamir_secret_sharing::PRIME_4096,
    };

    // Parse each share back into per-chunk big integers
    let chunk_size = 8usize;
    let mut result = Vec::new();

    // Determine number of chunks from first share
    let first = &shares[0].1;
    let mut pos = 0;
    let mut chunk_index = 0;

    // We reconstruct chunk by chunk
    while pos < first.len() {
        let len_bytes: [u8; 4] = first[pos..pos + 4].try_into()?;
        let _first_chunk_len = u32::from_be_bytes(len_bytes) as usize;

        // Gather this chunk's share value from all shares
        let share_tuples: Vec<(usize, num_bigint::BigInt)> = shares
            .iter()
            .map(|(idx, data)| {
                let mut p = 0usize;
                for _ in 0..chunk_index {
                    let l = u32::from_be_bytes(data[p..p + 4].try_into().unwrap()) as usize;
                    p += 4 + l;
                }
                let l = u32::from_be_bytes(data[p..p + 4].try_into().unwrap()) as usize;
                p += 4;
                let val = num_bigint::BigInt::from_signed_bytes_be(&data[p..p + l]);
                (*idx as usize, val)
            })
            .collect();

        let secret_val = sss.recover(&share_tuples);
        let val_u64 = secret_val
            .to_u64_digits()
            .1
            .first()
            .copied()
            .unwrap_or(0);
        result.extend_from_slice(&val_u64.to_be_bytes());

        // Advance pos in first share
        let l = u32::from_be_bytes(first[pos..pos + 4].try_into()?) as usize;
        pos += 4 + l;
        chunk_index += 1;
    }

    Ok(result)
}

fn now_secs() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

// ── Additional Cargo.toml deps needed ────────────────────────────────────────
// blake3 = "1.5"
// num-bigint = "0.4"
// shamir_secret_sharing already present
// ─────────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use x25519_dalek::{PublicKey, StaticSecret};

    fn make_guardian() -> (String, String, [u8; 32], StaticSecret) {
        let secret = StaticSecret::random_from_rng(rand::thread_rng());
        let pub_key: PublicKey = (&secret).into();
        let pub_bytes = *pub_key.as_bytes();
        (
            uuid::Uuid::new_v4().to_string(),
            "Guardian Name".to_string(),
            pub_bytes,
            secret,
        )
    }

    #[test]
    fn encrypt_decrypt_share() {
        let (id, name, pub_bytes, secret) = make_guardian();
        let raw_share = b"this is my secret share bytes 12";
        let rng = SystemRandom::new();

        let (ct, epk, nonce) = encrypt_share_for_guardian(raw_share, &pub_bytes, &rng).unwrap();
        let share_hash = blake3::hash(raw_share).to_hex().to_string();

        let enc = EncryptedShare {
            share_index: 1,
            guardian_id: id,
            guardian_name: name,
            ciphertext: ct,
            ephemeral_pub: epk,
            nonce,
            share_hash,
            created_at: 0,
        };

        let recovered = decrypt_share(&enc, &secret).unwrap();
        assert_eq!(recovered, raw_share);
    }
}
