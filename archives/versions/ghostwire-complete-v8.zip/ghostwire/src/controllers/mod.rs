//! controllers/mod.rs — HTTP controller modules

pub mod auth;
pub mod identity;
pub mod messaging;
pub mod peer;
pub mod peer_controller;
pub mod profiles;
pub mod system;
pub mod ws_handler;

// Wave 2-6 controllers (all in all_controllers.rs, split out here for clarity)
pub mod all_controllers;
pub use all_controllers::{
    ArkController,
    ChannelController,
    NetworkController,
    PairingController,
    RecoveryController,
    TrustController,
};

// Re-export WS handler
pub use ws_handler::{ws_handler, handle_socket};

// Re-export peer controller
pub use peer_controller::PeerController;
