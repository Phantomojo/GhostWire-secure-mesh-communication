// jwt_and_headers.rs
// ─────────────────────────────────────────────────────────────────────────────
// 1. Persistent JWT secret (survives daemon restarts)
// 2. Security headers middleware for Axum
// ─────────────────────────────────────────────────────────────────────────────

use axum::http::Request;
use axum::middleware::Next;
use axum::response::Response;
use std::path::Path;

// ── 1. Persistent JWT secret ─────────────────────────────────────────────────

/// Load a 64-byte JWT secret from disk, or generate and persist a new one.
///
/// File is stored at `data_dir/.jwt_seed` with mode 0o600 (owner-only).
/// The secret is hex-encoded so it can be used directly as a string key.
///
/// # Usage in start_web_server()
/// ```rust
/// let jwt_secret = load_or_create_jwt_secret(&config.data_dir);
/// // Store in AppState, use in encode/decode instead of JWT_SECRET lazy_static
/// ```
pub fn load_or_create_jwt_secret(data_dir: &Path) -> String {
    let path = data_dir.join(".jwt_seed");

    // Try to load existing seed
    if let Ok(bytes) = std::fs::read(&path) {
        if bytes.len() == 64 {
            tracing::info!("JWT secret loaded from disk");
            return hex::encode(bytes);
        }
        tracing::warn!("JWT seed file corrupt — regenerating");
    }

    // Generate fresh 64-byte seed
    use ring::rand::{SecureRandom, SystemRandom};
    let rng = SystemRandom::new();
    let mut seed = [0u8; 64];
    rng.fill(&mut seed).expect("RNG failed generating JWT seed");

    // Write with restricted permissions
    #[cfg(unix)]
    {
        use std::io::Write;
        use std::os::unix::fs::OpenOptionsExt;
        match std::fs::OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(true)
            .mode(0o600)
            .open(&path)
        {
            Ok(mut f) => {
                if let Err(e) = f.write_all(&seed) {
                    tracing::warn!("Could not persist JWT seed: {}", e);
                } else {
                    tracing::info!("JWT secret generated and persisted to {:?}", path);
                }
            }
            Err(e) => tracing::warn!("Could not open JWT seed path {:?}: {}", path, e),
        }
    }

    #[cfg(not(unix))]
    {
        use std::io::Write;
        match std::fs::OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(true)
            .open(&path)
        {
            Ok(mut f) => {
                let _ = f.write_all(&seed);
            }
            Err(e) => tracing::warn!("Could not persist JWT seed: {}", e),
        }
    }

    hex::encode(seed)
}

// ── 2. Security headers middleware ───────────────────────────────────────────

/// Axum middleware that adds security headers to every response.
///
/// # Usage
/// ```rust
/// use axum::middleware;
/// let app = Router::new()
///     ...
///     .layer(middleware::from_fn(security_headers));
/// ```
pub async fn security_headers<B>(req: Request<B>, next: Next<B>) -> Response {
    let mut res = next.run(req).await;
    let headers = res.headers_mut();

    macro_rules! hdr {
        ($k:expr, $v:expr) => {
            if let (Ok(k), Ok(v)) = (
                axum::http::HeaderName::from_bytes($k.as_bytes()),
                axum::http::HeaderValue::from_str($v),
            ) {
                headers.insert(k, v);
            }
        };
    }

    // Prevent MIME sniffing
    hdr!("X-Content-Type-Options", "nosniff");

    // Prevent clickjacking
    hdr!("X-Frame-Options", "DENY");

    // XSS protection (legacy browsers)
    hdr!("X-XSS-Protection", "1; mode=block");

    // No referrer leakage
    hdr!("Referrer-Policy", "no-referrer");

    // Disable unnecessary browser features
    hdr!("Permissions-Policy", "geolocation=(), microphone=(), camera=(), payment=()");

    // CSP: restrict sources — adjust if you load external fonts/scripts
    hdr!(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' ws: wss:; frame-ancestors 'none'"
    );

    res
}

// ─────────────────────────────────────────────────────────────────────────────
// INTEGRATION CHECKLIST
// ─────────────────────────────────────────────────────────────────────────────
//
// In web.rs / start_web_server():
//
//   1. Remove lazy_static! JWT_SECRET block.
//
//   2. Call at the top of start_web_server():
//        let jwt_secret = load_or_create_jwt_secret(&config.data_dir);
//
//   3. Add jwt_secret to AppState:
//        pub jwt_secret: String,
//      And pass it in:
//        jwt_secret: jwt_secret.clone(),
//
//   4. Replace JWT_SECRET.as_bytes() usages with:
//        state.jwt_secret.as_bytes()
//
//   5. Add middleware to Router:
//        use axum::middleware;
//        let app = Router::new()
//            ...
//            .layer(middleware::from_fn(security_headers));
//
//   6. Change axum::serve to use connect_info (needed for IP tracking):
//        axum::serve(
//            listener,
//            app.into_make_service_with_connect_info::<std::net::SocketAddr>()
//        ).await?;
// ─────────────────────────────────────────────────────────────────────────────
