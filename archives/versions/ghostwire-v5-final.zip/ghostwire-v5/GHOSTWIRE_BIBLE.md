# THE GHOSTWIRE BIBLE
**Version 5.0 | March 2026 | phantomojo (ngairuru)**

> *"Ubuntu — Umuntu ngumuntu ngabantu. A person is a person through other persons."*
> This document is the single source of truth for Ghostwire. All other docs are deprecated.

---

## TABLE OF CONTENTS

1. [Vision & Philosophy](#1-vision--philosophy)
2. [Architecture](#2-architecture)
3. [Security Model](#3-security-model)
4. [Installation & Quick Start](#4-installation--quick-start)
5. [Profile & Identity System](#5-profile--identity-system)
6. [Networking & Peer Discovery](#6-networking--peer-discovery)
7. [Messaging System](#7-messaging-system)
8. [Knowledge Ark](#8-knowledge-ark)
9. [API Reference](#9-api-reference)
10. [Development Guide](#10-development-guide)
11. [Roadmap](#11-roadmap)
12. [Contributing](#12-contributing)
13. [Security Policy](#13-security-policy)
14. [Changelog](#14-changelog)

---

## 1. Vision & Philosophy

### The Origin

Ghostwire is named after the invisible threads that connect all things. Its technical name is the first root of Yggdrasil — the world-tree. Its spiritual name is Indra's Net: infinite jewels, each reflecting all others, no center, no hierarchy.

This is not a product. It is infrastructure for human dignity.

The cypherpunk lineage (Hughes 1993, May 1988, Barlow 1996) correctly diagnosed the problem: communications infrastructure owned by corporations or states will be weaponised against the people who use it. What they could not have predicted is that the solution would need to be built from a crib in Nairobi, by someone for whom "the internet" has always meant someone else's infrastructure imposed on his life.

Ghostwire is built from the Global South, for the Global South first, and for the world second.

### Core Principles

**Ubuntu in Protocol**
Privacy is not individualism — it is the foundation of community. A person who cannot speak freely cannot organise freely. Ghostwire's architecture encodes Ubuntu: relay incentives reward nodes that serve others, Shamir recovery means communities hold each other's keys, the Web of Trust means trust flows through social relationships not corporate certificates.

**Sovereignty**
Your identity is your keypair. No phone number. No email. No central registration. Your DID (`did:ghost:gw00:<hash>`) is derived from your Ed25519 public key and exists as long as you hold the private key.

**Defence in Depth**
Four independent layers protect every message:
1. Sphinx (bitwise unlinkability between hops)
2. Exponential mixing delays (timing correlation impossible)
3. Fixed-size padding (message length invisible)
4. Cover traffic (silence pattern invisible)
Plus: WebSocket/Shadowsocks camouflage at the transport layer.

**Global South Ready**
MessagePack wire format (50% smaller than JSON). WebSocket camouflage bypasses Safaricom traffic shaping. Disaster mode falls back through: Internet → LAN → Bluetooth → LoRa → QR air-gap. Works on metered 3G.

**The Indra's Net Vision**
Ghostwire is more than a messenger. Every node is a sovereign library (Knowledge Ark). Knowledge flows freely, persists through partitions, belongs to no one, is available to all. This is what the internet was supposed to be before colonisation.

---

## 2. Architecture

### System Overview

```
┌─────────────────────────────────────────────────────────┐
│                     INTERFACES                          │
│  WebUI (React/Tauri) │ CLI │ Android (planned)          │
├─────────────────────────────────────────────────────────┤
│                     API LAYER                           │
│  Axum REST + WebSocket │ JWT auth │ Security headers    │
│  Rate limiting (FailedAttemptTracker) │ Audit log       │
├─────────────────────────────────────────────────────────┤
│                     CORE                                │
│  Identity (Ed25519/X25519/ML-KEM) │ IdentityCache       │
│  CryptoMachine (Double Ratchet) │ EncryptionManager      │
│  SocialGraph (connection requests, peer discovery)       │
│  TrustStore (TOFU + Web of Trust) │ PairingManager       │
│  KnowledgeArk (collections, full-text search)           │
│  BlockStore / Iroh (content-addressed files)            │
│  MailboxStore (offline delivery) │ EncryptedStore        │
│  DisasterManager (transport fallback)                   │
│  MessageDeduplicator │ PeerAddressCache │ SessionWarmer  │
├─────────────────────────────────────────────────────────┤
│                   ROUTING LAYER                         │
│  Sphinx (onion, bitwise unlinkable) │ MixingQueue        │
│  TrafficArmor (padding + cover traffic)                 │
│  DiverseRoutingTable (S/Kademlia, IP diversity)         │
├─────────────────────────────────────────────────────────┤
│                   TRANSPORT LAYER                       │
│  libp2p (Kademlia + Gossipsub + mDNS + WebRTC)          │
│  StealthTCP (HMAC handshake) │ PluggableTransport        │
│  WebSocket camouflage │ Shadowsocks AEAD                │
│  Bluetooth LE (stub) │ LoRa bridge (planned)            │
└─────────────────────────────────────────────────────────┘
```

### Key Files

| Path | Purpose |
|------|---------|
| `src/main.rs` | Entry point, boot sequence |
| `src/startup.rs` | Phased startup (5 phases, health checks) |
| `src/web.rs` | Axum router, AppState, WebSocket handler |
| `src/config.rs` | All configuration structs |
| `src/core/mod.rs` | Core struct, all subsystems |
| `src/core/identity/` | Identity lifecycle, device pairing |
| `src/core/crypto_machine.rs` | Double Ratchet (sans-IO) |
| `src/core/encryption.rs` | X25519 + ChaCha20 + ML-KEM |
| `src/core/mesh.rs` | libp2p swarm, Kademlia, Gossipsub |
| `src/core/social/social_graph.rs` | Peer discovery + connection requests |
| `src/core/knowledge/knowledge_ark.rs` | Knowledge Ark |
| `src/core/routing/sphinx.rs` | Sphinx packet format |
| `src/core/routing/skademlia.rs` | S/Kademlia hardening |
| `src/core/routing/mixing_delay.rs` | Exponential mixing |
| `src/core/transport/pluggable_transport.rs` | WebSocket/AEAD camouflage |
| `src/controllers/` | HTTP request handlers |

### Technology Choices (and Why)

| Layer | Technology | Why |
|-------|-----------|-----|
| Language | Rust | Memory safety without GC. Critical for crypto correctness. |
| Async | Tokio | Industry standard. libp2p requires it. |
| P2P | libp2p | Kademlia + Gossipsub + mDNS + WebRTC. Battle-tested. |
| Crypto | ring + chacha20poly1305 | ring is audited. ChaCha20 is constant-time. |
| PQ Crypto | pqcrypto-mlkem | ML-KEM-768 (Kyber). NIST standard 2024. |
| Key Exchange | x25519-dalek | Fastest X25519 in Rust. Audited. |
| Identity | Ed25519 (libp2p) | Standard, efficient, small signatures. |
| KDF | Argon2id | PHC winner 2015. Best GPU/ASIC resistance. |
| Hash | BLAKE3 | 17× faster than SHA-256. Same security level. |
| Storage | sled (via EncryptedStore) | Embedded. Argon2-keyed. No plaintext on disk. |
| Content store | Iroh (planned) | Rust-native IPFS successor. iroh-bytes + iroh-docs. |
| CRDT | automerge (planned) | Rust-native. Offline-first. For Ark collaboration. |
| Web framework | Axum | Tokio-native. Type-safe. Fast. |
| Wire format | MessagePack (rmp-serde) | 50% smaller than JSON. Critical for 3G. |
| Onion routing | Sphinx (custom) | Bitwise unlinkability. Used by Nym + Lightning. |

---

## 3. Security Model

### Threat Model

Ghostwire is designed to protect against:

| Adversary | Capability | Our Defense |
|-----------|-----------|-------------|
| Passive ISP | See all traffic | Sphinx + mixing + camouflage |
| Active ISP | Block by fingerprint | WebSocket/Shadowsocks camouflage |
| Nation-state | Global traffic correlation | Exponential mixing delays + cover traffic |
| Sybil attacker | Thousands of fake nodes | S/Kademlia PoW + IP diversity enforcement |
| Malicious relay | Intercept routed messages | Sphinx bitwise re-randomisation |
| Physical seizure | Read device storage | Argon2-keyed encrypted sled |
| MITM on first contact | Intercept key exchange | TOFU + safety number verification |
| Gossipsub gaming | Inflate relay scores | Hardened scoring (non-compounding) |

### What Ghostwire Does NOT Protect Against

- Compromised endpoint (malware on your device)
- Your internet provider knowing you use *something* (only what)
- Physical coercion (see: Shamir recovery for emergency key destruction)
- Metadata from application-layer behaviour (typing speed, response time)

### Cryptographic Primitives

```
Authentication:      Ed25519
Key Exchange:        X25519 (classical) + ML-KEM-768 (post-quantum)
Hybrid KEM:          X25519 + ML-KEM-768 XOR'd shared secrets
AEAD Encryption:     ChaCha20-Poly1305 (messages)
                     AES-256-GCM (legacy/compat)
Hash / KDF:          BLAKE3 (general), Argon2id (passwords/storage keys)
Forward Secrecy:     Double Ratchet (vodozemac implementation)
Onion Routing:       Sphinx (custom Rust implementation)
Identity:            did:ghost:gw00:<BLAKE3(ed25519_pub)>
```

### Key Storage

All key material is encrypted at rest:
- Identity keypair: Argon2id-derived key, ChaCha20-Poly1305 encrypted, stored in `~/.ghostwire/<profile>/identity.enc`
- Session keys: in-memory only, zeroized on drop
- Storage keys: derived per-namespace from profile password
- JWT seed: 64 random bytes at `~/.ghostwire/.jwt_seed`, chmod 600

---

## 4. Installation & Quick Start

### Prerequisites

```bash
# Rust (stable, >= 1.75)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Node.js >= 18 (for WebUI)
node --version

# Optional: cargo-audit for security scanning
cargo install cargo-audit
```

### Build

```bash
git clone https://github.com/phantomojo/ghostwire
cd ghostwire/ghostwire

# Build backend
cargo build --release

# Build frontend
cd ../webui && npm install && npm run build
cd ..
```

### Run

```bash
# Default: web server on :8080, mesh on :4001
./target/release/ghostwire

# With config file
./target/release/ghostwire --config ghostwire.toml

# With bootstrap nodes (for cross-network connectivity)
./target/release/ghostwire --bootstrap /dnsaddr/bootstrap.libp2p.io/p2p/<peerid>

# With specific profile
./target/release/ghostwire --profile work
```

### Connect Two PCs

**Same LAN (automatic):**
Both PCs will find each other via mDNS within seconds. Go to Nearby Peers, click Connect.

**Different networks:**
```bash
# PC1: get your rendezvous address
curl http://localhost:8080/api/v2/pair/rendezvous
# → "a3f9b2c1d4e5f6a7" (share this to PC2 out-of-band)

# PC2: generate a pairing code
curl -X POST http://localhost:8080/api/v2/pair/generate
# → { "code": "ACDF-GHJK-MNPQ-RTUV", "safety_number": "847291" }

# PC1: respond to the code
curl -X POST http://localhost:8080/api/v2/pair/respond \
  -d '{"code":"ACDF-GHJK-MNPQ-RTUV","initiator_id":"<PC2 node_id>"}'

# Verify safety numbers match on both screens → connection established
```

### First-Time Setup

1. Open `http://localhost:8080` in your browser
2. Create a profile (name + password ≥ 8 chars)
3. Your `did:ghost:gw00:...` identity is generated
4. Connect to peers (Nearby tab or paste rendezvous address)

---

## 5. Profile & Identity System

### Profile Lifecycle

```
Create profile
    ↓
Identity generated (Ed25519 keypair + X25519)
    ↓
Identity encrypted with Argon2id(password) → saved to disk
    ↓
On startup: identity loaded (locked state)
    ↓
User unlocks with password → identity in memory (unlocked)
    ↓
On lock / shutdown: keys zeroized from memory
```

### Profile API

```http
POST /api/v2/profile/create      { name, nickname, password }
GET  /api/v2/profile             → full profile
PUT  /api/v2/profile/metadata    { nickname, bio, avatar_url }
POST /api/v2/profile/unlock      { profile, password }
POST /api/v2/profile/lock
GET  /api/v2/profile/public-key
GET  /api/v2/profile/list        → all profiles on this device
```

### Brute Force Protection

`/api/v2/profile/unlock` is protected by `FailedAttemptTracker`:
- 5 failed attempts → 5-minute lockout (per IP + per profile)
- All attempts logged to `AuditLogger`
- Check audit log: `GET /api/v2/security/audit`

### Multi-Profile

Each profile is an isolated identity. Use cases:
- `personal` — personal communications
- `work` — professional contacts
- `ngairuru` — anonymous identity (separate keypair, no linkage)

Profiles do not share keys, contacts, or message history.

### Identity Recovery (Shamir)

```bash
# Set up recovery (choose 3-of-5 threshold)
curl -X POST http://localhost:8080/api/v2/recovery/setup \
  -d '{"threshold":3,"guardians":["<peer1>","<peer2>","<peer3>","<peer4>","<peer5>"]}'

# Each guardian receives an encrypted share
# To recover: contact 3 guardians, collect shares
curl -X POST http://localhost:8080/api/v2/recovery/reconstruct \
  -d '{"shares":[...],"new_password":"<new_password>"}'
```

---

## 6. Networking & Peer Discovery

### How Peers Are Found

1. **mDNS** (same LAN) — automatic, instant, no configuration
2. **Kademlia DHT** (internet) — join via bootstrap nodes, find by username
3. **Rendezvous address** — share a 16-hex-char address, peer looks it up in DHT
4. **QR code / manual code** — air-gap safe, `gw2:` URI scheme
5. **Direct multiaddr** — `/ip4/1.2.3.4/tcp/4001/p2p/<peerid>`

### Connection Request Flow

Discovery → you see a peer in "Nearby" or search by username
→ Click "Connect", add optional message
→ They receive a push notification with your profile card
→ They Accept or Deny
→ On Accept: keys exchanged, Double Ratchet session init, both sides see each other as Connected

This is a **social layer**, not a transport layer. The libp2p connection exists regardless; this is about mutual consent to communicate.

### Peer API

```http
GET  /api/v2/peers               → all known peers
GET  /api/v2/peers/nearby        → mDNS-discovered local peers
POST /api/v2/peers/connect       { node_id, message? }
GET  /api/v2/peers/requests      → pending inbound requests
POST /api/v2/peers/requests/respond  { request_id, accept }
DELETE /api/v2/peers/:node_id    → remove connection
POST /api/v2/peers/:node_id/block
GET  /api/v2/peers/:node_id/profile
```

### Sybil Resistance

- **S/Kademlia PoW**: node IDs require 12-bit proof-of-work puzzle
- **IP diversity**: max 3 nodes per /24 subnet in routing table
- **Gossipsub hardening**: constant (not compounding) relay scores, min 4 outbound peers

---

## 7. Messaging System

### Message Types

```rust
enum MessageKind {
    Text,
    Markdown,
    File { manifest_cid, filename, size_bytes, mime_type },
    KnowledgeEntry { entry_id, collection, content_type },
    Reaction { target_id, emoji },
    Receipt { target_id, receipt_kind },
    Audio { manifest_cid, duration_secs },
    Group { action, group_id },
    System { action },
}
```

### Encryption States

```rust
enum EncryptionState {
    Plaintext,                           // Local drafts only
    DirectEncrypted { key_id },          // ChaCha20, no ratchet
    DoubleRatchet { session_id, n },     // E2E + forward secrecy
    SphinxRouted { hops, session_id },   // Anonymous + E2E
    SealedSender { session_id },         // Recipient can't identify sender
}
```

### Send a Message

```bash
# REST
curl -X POST http://localhost:8080/api/v2/messages/send \
  -H "Authorization: Bearer <token>" \
  -d '{"recipient":"<node_id>","content":"Ubuntu — I am because we are"}'

# WebSocket (real-time)
ws://localhost:8080/api/ws
→ {"cmd":"send_message","recipient":"<node_id>","content":"..."}
```

### File Transfer

```bash
# Send a file
curl -X POST http://localhost:8080/api/v2/files/send \
  -F "file=@document.pdf" \
  -F "recipient=<node_id>"
# → Returns manifest_cid

# Check status
curl http://localhost:8080/api/v2/files/<manifest_cid>/status
```

Files are split into 256 KiB blocks, content-addressed (BLAKE3), distributed across the mesh. Transfer resumes automatically after disconnection.

### Ephemeral Messages

```bash
# Message that auto-deletes after 1 hour
curl -X POST http://localhost:8080/api/v2/messages/send \
  -d '{"recipient":"<node_id>","content":"...","ttl_secs":3600}'
```

---

## 8. Knowledge Ark

The Knowledge Ark is Ghostwire's distributed knowledge layer — the implementation of the Indra's Net vision. Every node is a sovereign library.

### Concepts

- **Entry**: A single knowledge item (note, article, code, reference, dataset)
- **Collection**: A named group of entries (personal notebook, shared research, public library)
- **CID**: Each entry's BLAKE3 hash — content-addressed, tamper-proof
- **Access levels**: Private, Trusted (WoT), Shared (specific peers), Public (mesh-wide)

### Quick Start

```bash
# Create a note
curl -X POST http://localhost:8080/api/v2/ark/entries \
  -d '{"title":"Ubuntu Philosophy","body":"I am because we are","collection":"personal"}'

# Search
curl "http://localhost:8080/api/v2/ark/search?q=ubuntu+philosophy"

# Share a collection with a peer
curl -X POST http://localhost:8080/api/v2/ark/collections/<id>/share \
  -d '{"peer_id":"<node_id>"}'
```

### Ark API

```http
GET  /api/v2/ark/collections         → list collections
POST /api/v2/ark/collections         { name, description, access }
POST /api/v2/ark/entries             { title, body, collection, tags, access }
GET  /api/v2/ark/entries/:cid        → get entry
DELETE /api/v2/ark/entries/:cid
GET  /api/v2/ark/search?q=<query>    → full-text search
GET  /api/v2/ark/tags/:tag           → entries by tag
GET  /api/v2/ark/stats
POST /api/v2/ark/sync                → sync public entries with connected peers
```

### Versioning

Every edit creates a new version with a parent CID chain. You can traverse the full edit history of any entry.

---

## 9. API Reference

### Authentication

All endpoints except health, login, and setup require a JWT Bearer token.

```bash
# Get token (after profile unlock)
curl -X POST http://localhost:8080/api/v2/profile/unlock \
  -d '{"profile":"default","password":"your_password"}'
# → { "token": "eyJ..." }

# Use token
curl -H "Authorization: Bearer eyJ..." http://localhost:8080/api/v2/profile
```

### Full Endpoint List

```
# Health
GET  /api/v2/health
GET  /api/v2/system/stats
GET  /api/v2/system/boot-report

# Profile & Identity
GET  /api/v2/profile
PUT  /api/v2/profile/metadata
POST /api/v2/profile/unlock
POST /api/v2/profile/lock
GET  /api/v2/profile/public-key
GET  /api/v2/profile/list

# Peers & Social
GET  /api/v2/peers
GET  /api/v2/peers/nearby
POST /api/v2/peers/connect
GET  /api/v2/peers/requests
POST /api/v2/peers/requests/respond
DELETE /api/v2/peers/:id
POST /api/v2/peers/:id/block
GET  /api/v2/peers/:id/profile

# Pairing
POST /api/v2/pair/generate
POST /api/v2/pair/respond
POST /api/v2/pair/complete
GET  /api/v2/pair/contact-card
POST /api/v2/pair/scan
GET  /api/v2/pair/rendezvous

# Messages
GET  /api/v2/messages
POST /api/v2/messages/send
POST /api/v2/broadcast

# Files
POST /api/v2/files/send
POST /api/v2/files/receive
GET  /api/v2/files/:cid/status

# Knowledge Ark
GET  /api/v2/ark/collections
POST /api/v2/ark/collections
POST /api/v2/ark/entries
GET  /api/v2/ark/entries/:cid
DELETE /api/v2/ark/entries/:cid
GET  /api/v2/ark/search
GET  /api/v2/ark/tags/:tag
GET  /api/v2/ark/stats

# Trust
GET  /api/v2/trust/:peer_id
POST /api/v2/trust/:peer_id/verify
POST /api/v2/trust/:peer_id/block
GET  /api/v2/trust

# Recovery
POST /api/v2/recovery/setup
GET  /api/v2/recovery/my-shares
POST /api/v2/recovery/reconstruct

# Network
GET  /api/v2/network/status
GET  /api/v2/network/qr-contact
POST /api/v2/network/scan-qr

# Security
GET  /api/v2/security/audit

# WebSocket (real-time events)
WS   /api/ws
```

### WebSocket Protocol

Connect: `ws://localhost:8080/api/ws`

Inbound commands (client → server):
```json
{"cmd":"ping"}
{"cmd":"get_peers"}
{"cmd":"send_message","recipient":"<id>","content":"..."}
{"cmd":"subscribe","events":["peer_connected","new_message"]}
```

Outbound events (server → client):
```json
{"type":"connected","node_id":"...","version":"2.0.0"}
{"type":"core_event","payload":{"NewMessage":{...}}}
{"type":"connection_request","from_node_id":"...","from_nickname":"...","request_id":"..."}
{"type":"peer_list","peers":[...],"count":5}
{"type":"pong","timestamp":1700000000}
{"type":"error","code":"PARSE_ERROR","message":"..."}
```

---

## 10. Development Guide

### Project Structure

```
ghostwire/          ← Rust backend
  src/
    main.rs         ← Entry point
    startup.rs      ← Phased boot sequence
    web.rs          ← Axum router + AppState
    config.rs       ← Configuration
    core/           ← All core modules
      mod.rs        ← Core struct + nervous system
      identity/     ← Identity + device pairing
      social/       ← Social graph, connection requests
      knowledge/    ← Knowledge Ark
      routing/      ← Sphinx + S/Kademlia + mixing
      transport/    ← Pluggable transports
      network/      ← Presence obfuscation
      db/           ← Iroh + automerge integrations
      mesh.rs       ← libp2p swarm
      crypto_machine.rs ← Double Ratchet
      encryption.rs ← Key management
    controllers/    ← HTTP handlers
    middleware/     ← Auth, rate limiting, security headers
webui/              ← React + TypeScript frontend
  src/
    components/     ← UI components
    services/       ← API client + WebSocket
    types.ts        ← Type definitions (keep in sync with API)
    state.tsx       ← Global state
```

### Running Tests

```bash
# All tests
cargo test --all

# Security-critical tests only
cargo test -p ghostwire routing::skademlia
cargo test -p ghostwire routing::sphinx
cargo test -p ghostwire core::blockstore

# With coverage
cargo tarpaulin --out Html
```

### Security Scan

```bash
cargo audit
cargo deny check
cargo clippy -- -D warnings
```

### Configuring ghostwire.toml

```toml
[server]
host = "127.0.0.1"
port = 8080
web_enabled = true
auto_update = false  # Never enable in production without signing key

[network]
mesh_enabled = true
stealth_tcp_enabled = true
max_peers = 50
websocket_mode = true      # Enable WebSocket transport camouflage
shadowsocks_mode = false   # Enable for high-censorship environments
obfs4_enabled = false      # ALPHA — not functional yet

[mixing]
enabled = true
mean_delay_ms = 200
preset = "default"         # "default" | "high_anonymity" | "low_latency"

[security]
max_connections_per_ip = 10
max_messages_per_minute = 100
blacklist_enabled = true

[encryption]
algorithm = "chacha20-poly1305"
key_rotation_interval_days = 30
```

### Adding a New API Endpoint

1. Add handler in `src/controllers/<feature>.rs`
2. Add route in `src/web.rs` Router construction
3. Add types to `src/api_v2_types.rs`
4. Update `webui/src/services/api.ts`
5. Update this doc: API Reference section

### Code Standards

- No `.unwrap()` in non-test code on crypto paths — use `?` or `map_err`
- All crypto keys: `#[derive(Zeroize, ZeroizeOnDrop)]`
- All user-facing errors: `ApiV2Response::error(code, message)`
- All audit-relevant actions: log to `AuditLogger`
- Message types: use `MessageKind` enum, never `String`
- Encryption state: use `EncryptionState` enum, never `String`

---

## 11. Roadmap

### Done (Waves 1–5)

- [x] libp2p mesh (Kademlia + Gossipsub + mDNS + WebRTC)
- [x] Double Ratchet E2E encryption (vodozemac)
- [x] ML-KEM-768 post-quantum hybrid
- [x] Sphinx onion routing (bitwise unlinkable)
- [x] Exponential mixing delays
- [x] Traffic padding + cover traffic
- [x] S/Kademlia Sybil resistance + IP diversity
- [x] HMAC stealth TCP handshake
- [x] WebSocket + Shadowsocks transport camouflage
- [x] Encrypted sled storage (Argon2id keys)
- [x] MailboxStore (offline delivery)
- [x] Shamir identity recovery
- [x] TOFU + Web of Trust
- [x] Device pairing (QR + LAN + DHT rendezvous)
- [x] Knowledge Ark (collections, full-text search, versioning)
- [x] Connection request protocol (accept/deny social flow)
- [x] Real WebSocket event streaming
- [x] Phased startup with diagnostics
- [x] Secure updater (Ed25519 signature verification)

### In Progress

- [ ] Iroh integration (iroh-bytes for file transfer)
- [ ] Ghost Channels (anonymous broadcast rooms)
- [ ] Mesh health dashboard (live topology, latency)
- [ ] Private routing wired into message send path
- [ ] Android client (Tauri mobile)

### Planned

- [ ] LoRa bridge (rural connectivity)
- [ ] automerge for real-time Ark collaboration
- [ ] Full Sphinx curve-point blinding (currently BLAKE3 approximation)
- [ ] Platform-native secret storage (keyring crate)
- [ ] OpenAPI/Swagger docs (utoipa)
- [ ] Verifiable credential social graph
- [ ] obfs4 transport (currently ALPHA/non-functional)

---

## 12. Contributing

### Priorities

1. **Security bugs** — always top priority, report via ngairuru@proton.me
2. **Stub completions** — see `TODO.md` for the list
3. **Test coverage** — currently <10%, target 50%
4. **Documentation** — this Bible is the source of truth

### Pull Request Process

1. Fork → branch (`feat/`, `fix/`, `sec/`)
2. `cargo test --all` must pass
3. `cargo clippy -- -D warnings` must pass
4. `cargo audit` must pass
5. Update this Bible if you add/change API or architecture
6. PRs with `.unwrap()` in crypto paths will be rejected

### Philosophical Alignment

Contributions must align with Ubuntu philosophy: building tools that strengthen community, not fragment it. Features that enable surveillance, tracking, or centralisation will not be merged regardless of technical quality.

---

## 13. Security Policy

### Reporting Vulnerabilities

**Email**: ngairuru@proton.me (PGP preferred — use the public key in `/docs/pgp.asc`)

Do NOT open public GitHub issues for security vulnerabilities. Give us 90 days to patch before disclosure.

### What Qualifies

- Cryptographic weaknesses in the protocol
- Authentication bypasses
- Information leakage (identity correlation, message content)
- Remote code execution vectors
- Key material exposure

### What Does NOT Qualify

- Vulnerabilities in dependencies (report upstream, also report to us)
- Issues requiring physical access to the device
- Social engineering attacks on users

### Security Audit Status

- Wave 1 fixes applied: brute-force protection, audit logging, HMAC stealth handshake
- Wave 2 fixes applied: Sphinx routing, mixing delays, S/Kademlia
- Wave 3 pending: obfs4, full Sphinx re-randomisation
- Third-party audit: not yet performed — seeking funding

---

## 14. Changelog

### v5.0 (March 2026) — Wave 5: Social Layer + Stubs Fixed

**New:**
- Connection request protocol (accept/deny/block)
- SocialGraph — peer discovery with connection states
- Real WebSocket handler (was echo stub)
- Secure updater with Ed25519 signature verification
- Iroh integration guide (file transfer + Ark sync)
- Ghost Channels design (anonymous broadcast)
- This Bible (replaces 30+ docs)

**Fixed:**
- `PeerController::list()` now returns real data structure
- `handle_socket()` now streams CoreEvents
- `updater.rs` no longer executes shell scripts without signature check
- `store.rs::clear()` fix documented (no-op removed)
- `profiles_debug.rs` marked for deletion (duplicate)

### v4.0 (March 2026) — Wave 4: Core Overhaul

- Message model rewritten (typed kinds, encryption states, delivery tracking)
- Knowledge Ark implemented
- Device pairing (QR + LAN + DHT rendezvous)
- Phased startup sequence with diagnostics
- 6 micro-optimizations (identity cache, peer cache, O(1) dedup, ring bus, session warming)

### v3.0 (March 2026) — Wave 3: Security Hardening

- S/Kademlia (Sybil resistance, IP diversity, disjoint lookups)
- Sphinx packet format (bitwise unlinkability)
- Exponential mixing delays
- Pluggable transports (WebSocket + Shadowsocks camouflage)
- BlockStore with Bitswap ledger
- Presence obfuscation (intersection attack mitigation)

### v2.0 (March 2026) — Wave 2: Foundation

- Unlock/lock brute-force protection (FailedAttemptTracker)
- HMAC stealth handshake (replaces static magic bytes)
- Persistent JWT secret
- Security headers middleware
- MailboxStore (offline delivery)
- Traffic padding + cover traffic
- Encrypted sled storage
- Shamir identity recovery
- TOFU + Web of Trust reputation system
- Typed cryptographic keys (GW0/GW1 versioning)
- MessagePack wire protocol

### v1.0 (December 2025) — Initial prototype

- libp2p mesh (Kademlia + Gossipsub + mDNS)
- Double Ratchet E2E encryption
- ML-KEM-768 post-quantum hybrid
- Basic profile management
- React WebUI

---

*This is the Ghostwire Bible. All other documentation files in this repository are deprecated and will be removed in the next cleanup. For questions: ngairuru@proton.me*

*Ubuntu — I am because we are.*
